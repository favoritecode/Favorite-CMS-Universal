<?php
/**
 * Authentication shell (login, registration, verification screens).
 *
 * @var \Closure $e       HTML escaper
 * @var \Closure $url     Base-path aware URL builder
 * @var string   $siteName
 * @var string   $content Rendered screen body
 * @var string   $pageTitle
 */
?>
<!DOCTYPE html>
<html lang="en" data-admin-theme="<?php echo \FavoriteCMS\Services\Appearance::resolve(); ?>">
<head>
<?php include __DIR__ . '/../partials/standalone/head.php'; ?>
</head>
<body>
<main class="fc-auth">
    <div class="fc-auth__inner fc-auth__inner--account">
        <header class="fc-auth__header">
            <a class="fc-brand" href="<?php echo $e($url('/')); ?>">
                <img src="<?php echo $e($url('/assets/images/Favorite_Web_Icon.png')); ?>" alt="" aria-hidden="true" width="36" height="36" style="width:36px;height:36px;object-fit:contain;display:block;flex-shrink:0;">
                <span class="fc-brand__name"><?php echo $e($siteName); ?></span>
            </a>
            <div class="fc-auth__header-actions">
                <button type="button" class="fc-theme-toggle" id="fc-theme-toggle" aria-label="Toggle dark mode" title="Toggle dark mode">
                    <span class="fc-theme-icon-sun" aria-hidden="true">☀️</span>
                    <span class="fc-theme-icon-moon" aria-hidden="true">🌙</span>
                </button>
                <span class="fc-auth__header-label">Account access</span>
            </div>
        </header>

        <div class="fc-auth__frame">
            <aside class="fc-auth__intro" aria-label="Welcome">
                <div class="fc-auth__intro-copy">
                    <span class="fc-auth__eyebrow">A space to connect</span>
                    <h2>Good to have<br>you here.</h2>
                    <p>Manage your profile, join the conversation, and make yourself at home.</p>
                </div>
                <div class="fc-auth__art" aria-hidden="true">
                    <span class="fc-auth__art-orbit"></span>
                    <span class="fc-auth__art-card"><span></span><span></span><span></span></span>
                    <span class="fc-auth__art-dot"></span>
                </div>
                <p class="fc-auth__intro-note">Your connection to <?php echo $e($siteName); ?>.</p>
            </aside>
            <?php echo $content; ?>
        </div>

        <p class="fc-auth__footer"><a href="<?php echo $e($url('/')); ?>">&larr; Back to <?php echo $e($siteName); ?></a></p>
    </div>
</main>
<?php include __DIR__ . '/../partials/standalone/scripts.php'; ?>
</body>
</html>
