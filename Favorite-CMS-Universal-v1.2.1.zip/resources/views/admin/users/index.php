<div class="page-header">
    <h1 class="page-title">Users</h1>
    <a href="<?php echo htmlspecialchars(site_path('/admin/users/new'), ENT_QUOTES, 'UTF-8'); ?>" class="btn btn-primary">Add New User</a>
</div>

<form method="POST" action="<?php echo htmlspecialchars(site_path('/admin/users/bulk'), ENT_QUOTES, 'UTF-8'); ?>" id="users-bulk-form">
    <input type="hidden" name="_token" value="<?php echo htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8'); ?>">

    <div class="bulk-actions-wrap">
        <select name="bulk_action" class="form-control" style="width: auto; max-width: 200px; display: inline-block;">
            <option value="">Bulk Actions</option>
            <option value="activate">Activate / Restore</option>
            <option value="suspend">Suspend</option>
            <option value="ban">Ban</option>
            <option value="verify">Mark as Verified</option>
            <option value="delete">Delete Selected</option>
        </select>
        <button type="submit" class="btn btn-secondary">Apply</button>
        <span class="bulk-count-badge">0 selected</span>
    </div>

    <div class="wp-table-wrap">
        <table class="wp-table">
            <thead>
                <tr>
                    <th style="width: 32px; text-align: center;">
                        <input type="checkbox" id="select-all-users" data-select-all>
                    </th>
                    <th>Username</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Status</th>
                    <th>Verified</th>
                    <th style="text-align: center;">Posts</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $activeSuperAdminCount = \FavoriteCMS\Models\User::getActiveSuperAdminCount();
                ?>
                <?php foreach ($users as $u): ?>
                    <?php
                    $userRoles = $u->getRoles();
                    $primaryRole = !empty($userRoles) ? $userRoles[0] : null;
                    $roleName = $primaryRole ? $primaryRole->name : 'Subscriber';
                    $isSelf = ((int)$u->id === (int)($_SESSION['auth_user_id'] ?? 0));
                    $isSoleActiveSuperAdmin = $u->hasRole('super-admin') && $u->isActive() && ($activeSuperAdminCount <= 1);
                    $postCount = $u->getPostCount();
                    $userStatus = $u->status ?? 'active';

                    $statusBadgeStyle = match ($userStatus) {
                        'active'    => 'background: var(--admin-success-bg); color: var(--admin-success-text);',
                        'suspended' => 'background: var(--admin-warning-bg); color: var(--admin-warning-text); font-weight: 700;',
                        'banned'    => 'background: var(--admin-danger-bg); color: var(--admin-danger-text); font-weight: 700;',
                        default     => 'background: var(--admin-surface-subtle); color: var(--admin-text-muted);',
                    };
                    ?>
                    <tr>
                        <td style="text-align: center;">
                            <?php if ($isSelf): ?>
                                <input type="checkbox" disabled title="You cannot bulk-edit your own account">
                            <?php elseif ($isSoleActiveSuperAdmin): ?>
                                <input type="checkbox" disabled title="Protected sole Super Admin account">
                            <?php else: ?>
                                <input type="checkbox" name="ids[]" value="<?php echo (int)$u->id; ?>" class="bulk-cb">
                            <?php endif; ?>
                        </td>
                        <td>
                            <strong>
                                <a href="<?php echo htmlspecialchars(site_path('/admin/users/edit?id='), ENT_QUOTES, 'UTF-8'); ?><?php echo (int)$u->id; ?>" class="row-title">
                                    <?php echo htmlspecialchars($u->username ?? $u->name, ENT_QUOTES, 'UTF-8'); ?>
                                </a>
                            </strong>
                            <?php if ($isSelf): ?>
                                <span style="font-size: 11px; background: var(--admin-info-bg); color: var(--admin-info-text); padding: 1px 6px; border-radius: 3px; margin-left: 4px;">You</span>
                            <?php endif; ?>
                            <div class="row-actions">
                                <a href="<?php echo htmlspecialchars(site_path('/admin/users/edit?id='), ENT_QUOTES, 'UTF-8'); ?><?php echo (int)$u->id; ?>">Edit Profile</a>
                                <?php if (!$u->isEmailVerified()): ?>
                                    | <button type="submit" form="core-action-form" formmethod="POST" formnovalidate formaction="<?php echo htmlspecialchars(site_base_path(), ENT_QUOTES, 'UTF-8'); ?>/admin/users/verify?id=<?php echo (int)$u->id; ?>" class="core-action-link" style="color: var(--admin-success-text);">Verify</button>
                                <?php endif; ?>
                                <?php if (!$isSelf && !$isSoleActiveSuperAdmin): ?>
                                    | <button type="submit" form="core-action-form" formmethod="POST" formnovalidate formaction="<?php echo htmlspecialchars(site_base_path(), ENT_QUOTES, 'UTF-8'); ?>/admin/users/delete?id=<?php echo (int)$u->id; ?>" class="core-action-link" onclick="return confirm('Permanently delete user &quot;<?php echo htmlspecialchars($u->username); ?>&quot;?');" style="color: var(--wp-danger);">Delete</button>
                                <?php elseif (!$isSelf && $isSoleActiveSuperAdmin): ?>
                                    | <span style="color: var(--wp-text-muted); font-size: 11.5px;" title="Sole active Super Admin cannot be deleted">Protected</span>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td><?php echo htmlspecialchars($u->name ?? '', ENT_QUOTES, 'UTF-8'); ?></td>
                        <td><a href="mailto:<?php echo htmlspecialchars($u->email, ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($u->email, ENT_QUOTES, 'UTF-8'); ?></a></td>
                        <td>
                            <?php if ($isSoleActiveSuperAdmin): ?>
                                <span style="font-weight: 600; color: var(--admin-info-text); background: var(--admin-info-bg); padding: 2px 8px; border-radius: 3px; font-size: 11px;">Super Admin (Protected)</span>
                            <?php elseif (!$isSelf && !empty($roles)): ?>
                                <form method="POST" action="<?php echo htmlspecialchars(site_path('/admin/users/role'), ENT_QUOTES, 'UTF-8'); ?>" style="display: inline-block;">
                                    <input type="hidden" name="_token" value="<?php echo htmlspecialchars($_SESSION['_token'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
                                    <input type="hidden" name="id" value="<?php echo (int)$u->id; ?>">
                                    <select name="role_id" onchange="this.form.submit()" style="font-size: 12px; padding: 3px 6px; border: 1px solid var(--admin-border); border-radius: 3px; background: var(--admin-surface);">
                                        <?php foreach ($roles as $r): ?>
                                            <option value="<?php echo (int)$r->id; ?>" <?php echo ($primaryRole && (int)$primaryRole->id === (int)$r->id) ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($r->name, ENT_QUOTES, 'UTF-8'); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </form>
                            <?php else: ?>
                                <span style="font-weight: 500;"><?php echo htmlspecialchars($roleName, ENT_QUOTES, 'UTF-8'); ?></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span style="display: inline-block; padding: 2px 8px; border-radius: 3px; font-size: 11px; text-transform: uppercase; <?php echo $statusBadgeStyle; ?>">
                                <?php echo htmlspecialchars(ucfirst($userStatus), ENT_QUOTES, 'UTF-8'); ?>
                            </span>
                        </td>
                        <td>
                            <?php if ($u->isEmailVerified()): ?>
                                <span style="display: inline-block; padding: 2px 8px; border-radius: 3px; font-size: 11px; font-weight: 600; background: var(--admin-success-bg); color: var(--admin-success-text);" title="Email verified at <?php echo htmlspecialchars($u->email_verified_at ?? '', ENT_QUOTES, 'UTF-8'); ?>">
                                    Verified
                                </span>
                            <?php else: ?>
                                <div style="display: inline-flex; align-items: center; gap: 5px;">
                                    <span style="display: inline-block; padding: 2px 8px; border-radius: 3px; font-size: 11px; font-weight: 600; background: var(--admin-warning-bg); color: var(--admin-warning-text);" title="Email verification pending">
                                        Unverified
                                    </span>
                                    <button type="submit" form="core-action-form" formmethod="POST" formnovalidate formaction="<?php echo htmlspecialchars(site_base_path(), ENT_QUOTES, 'UTF-8'); ?>/admin/users/verify?id=<?php echo (int)$u->id; ?>" class="btn btn-secondary" style="padding: 1px 6px; font-size: 11px; line-height: 1.2;" title="Manually verify this user">Verify</button>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td style="text-align: center;">
                            <a href="<?php echo htmlspecialchars(site_path('/admin/posts?s='), ENT_QUOTES, 'UTF-8'); ?><?php echo urlencode($u->username); ?>" style="font-weight: 600; color: var(--admin-info-text);" title="View Posts by <?php echo htmlspecialchars($u->username); ?>">
                                <?php echo $postCount; ?>
                            </a>
                        </td>
                        <td>
                            <?php if (!$isSelf): ?>
                                <?php if ($isSoleActiveSuperAdmin): ?>
                                    <span style="color: var(--admin-info-text); font-size: 11px; background: var(--admin-info-bg); padding: 2px 6px; border-radius: 3px; font-weight: 600;">Protected Super Admin</span>
                                <?php else: ?>
                                    <div style="display: flex; gap: 6px; align-items: center;">
                                        <?php if ($userStatus === 'active'): ?>
                                            <a href="<?php echo htmlspecialchars(site_path('/admin/users/status?id='), ENT_QUOTES, 'UTF-8'); ?><?php echo (int)$u->id; ?>&status=suspended" class="btn btn-secondary" style="padding: 2px 7px; font-size: 11px; color: var(--admin-warning-text);" title="Suspend user">
                                                Suspend
                                            </a>
                                            <a href="<?php echo htmlspecialchars(site_path('/admin/users/status?id='), ENT_QUOTES, 'UTF-8'); ?><?php echo (int)$u->id; ?>&status=banned" class="btn btn-secondary" style="padding: 2px 7px; font-size: 11px; color: var(--admin-danger-text);" title="Ban user" onclick="return confirm('Ban user &quot;<?php echo htmlspecialchars($u->username); ?>&quot;? They will not be able to log in.');">
                                                Ban
                                            </a>
                                        <?php elseif ($userStatus === 'suspended'): ?>
                                            <a href="<?php echo htmlspecialchars(site_path('/admin/users/status?id='), ENT_QUOTES, 'UTF-8'); ?><?php echo (int)$u->id; ?>&status=active" class="btn btn-secondary" style="padding: 2px 7px; font-size: 11px; color: var(--admin-success-text); font-weight: 600;" title="Reactivate user">
                                                Activate
                                            </a>
                                            <a href="<?php echo htmlspecialchars(site_path('/admin/users/status?id='), ENT_QUOTES, 'UTF-8'); ?><?php echo (int)$u->id; ?>&status=banned" class="btn btn-secondary" style="padding: 2px 7px; font-size: 11px; color: var(--admin-danger-text);" title="Ban user">
                                                Ban
                                            </a>
                                        <?php elseif ($userStatus === 'banned'): ?>
                                            <a href="<?php echo htmlspecialchars(site_path('/admin/users/status?id='), ENT_QUOTES, 'UTF-8'); ?><?php echo (int)$u->id; ?>&status=active" class="btn btn-secondary" style="padding: 2px 7px; font-size: 11px; color: var(--admin-success-text); font-weight: 600;" title="Restore user">
                                                Restore
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            <?php else: ?>
                                <span style="color: var(--wp-text-muted); font-size: 12px;">Active Account</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</form>

<script>
document.addEventListener('DOMContentLoaded', function() {
    initAdminMultiSelect('users-bulk-form', { itemType: 'user' });
});
</script>

<?php $paginationBase = '/admin/users'; include APP_ROOT . '/resources/views/admin/partials/pagination.php'; ?>

