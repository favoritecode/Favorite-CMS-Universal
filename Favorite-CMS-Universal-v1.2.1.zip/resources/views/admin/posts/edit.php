<?php
$postBase = \FavoriteCMS\Models\Setting::get('permalinks', 'post_base', 'post');
$isEdit = !empty($post);
$action = site_path($isEdit ? '/admin/posts/update' : '/admin/posts/store');
$revision = \FavoriteCMS\Services\ContentRevision::prepare($post ?? null, 'post', \FavoriteCMS\Models\User::find((int)($_SESSION['auth_user_id'] ?? 0)));
$builderState = \FavoriteCMS\Services\BuilderContent::state('post', (int)($post->id ?? 0));
$builderBackup = !$builderState ? \FavoriteCMS\Services\BuilderContent::backup('post', (int)($post->id ?? 0)) : [];
$editorContent = $revision['content'];
$currentFeatImg = $post?->getFeaturedImage();
$postId = (int)($post->id ?? 0);
?>
<div class="page-header" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
    <h1 class="page-title"><?php echo $isEdit ? 'Edit Post' : 'Add New Post'; ?></h1>
    <div class="editor-page-actions">
        <button type="button" id="preview-post-btn" class="btn btn-secondary" title="Preview post with active theme">
            &#128065; Preview Post
        </button>
        <?php if ($isEdit): ?>
            <a href="<?php echo htmlspecialchars(site_path('/admin/posts/new'), ENT_QUOTES, 'UTF-8'); ?>" class="btn btn-secondary">Add New</a>
            <a href="<?php echo htmlspecialchars(site_path($post->url()), ENT_QUOTES, 'UTF-8'); ?>" target="_blank" class="btn btn-secondary">
                View Post &#8599;
            </a>
        <?php endif; ?>
    </div>
</div>

<!-- Autosave Restore Banner -->
<div id="autosave-banner" style="display: none; background: var(--admin-info-bg); border: 1px solid var(--admin-info-border); border-left: 4px solid var(--wp-blue); padding: 10px 16px; border-radius: 4px; margin-bottom: 16px; justify-content: space-between; align-items: center;">
    <div style="font-size: 13px; color: var(--admin-info-text);">
        &#9888; <strong>Unsaved local draft found:</strong> A newer draft was saved in your browser from an earlier session.
    </div>
    <div style="display: flex; gap: 8px;">
        <select id="draft-recovery-select" aria-label="Unsaved draft" style="max-width: 220px;"></select>
        <button type="button" id="restore-draft-btn" class="btn btn-primary" style="padding: 3px 10px; font-size: 12px;">Restore Draft</button>
        <button type="button" id="dismiss-draft-btn" class="btn btn-secondary" style="padding: 3px 10px; font-size: 12px;">Dismiss</button>
    </div>
</div>

<form id="post-editor-form" method="POST" action="<?php echo $action; ?>">
    <input type="hidden" name="_token" value="<?php echo htmlspecialchars($_SESSION['_token'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
    <input type="hidden" id="action_type" name="action_type" value="">
    <input type="hidden" name="_content_revision" value="<?php echo htmlspecialchars($revision['token'], ENT_QUOTES, 'UTF-8'); ?>">
    <?php if ($isEdit): ?>
        <input type="hidden" name="id" value="<?php echo $postId; ?>">
    <?php endif; ?>

    <div class="editor-layout-grid">
        <!-- Left Main Column -->
        <div>
            <!-- Post Title -->
            <div class="form-group" style="margin-bottom: 8px;">
                <input type="text" 
                       id="post-title" 
                       name="title" 
                       class="form-control" 
                       style="font-size: 20px; padding: 12px 14px; font-weight: 700; border-radius: 4px;" 
                       placeholder="Add post title..." 
                       value="<?php echo htmlspecialchars($post->title ?? '', ENT_QUOTES, 'UTF-8'); ?>" 
                       required 
                       autofocus>
            </div>

            <!-- Permalink / Slug Section -->
            <div style="margin-bottom: 18px; font-size: 13px; color: var(--wp-text-muted); display: flex; align-items: center; gap: 6px; flex-wrap: wrap;">
                <span><strong>Permalink:</strong> <?php echo htmlspecialchars(app_url('/' . (in_array($postBase, ['post','blog'], true) ? $postBase : 'post') . '/'), ENT_QUOTES, 'UTF-8'); ?></span>
                <span id="slug-display" style="color: var(--admin-text-heading); font-weight: 600; background: var(--admin-surface-elevated); padding: 2px 6px; border-radius: 3px;">
                    <?php echo htmlspecialchars($post->slug ?? 'auto-generated'); ?>
                </span>
                <button type="button" id="edit-slug-btn" class="btn btn-secondary" style="padding: 2px 8px; font-size: 11px;">Edit</button>
                <div id="slug-edit-wrap" style="display: none; align-items: center; gap: 4px;">
                    <input type="text" 
                           id="slug-input" 
                           name="slug" 
                           value="<?php echo htmlspecialchars($post->slug ?? '', ENT_QUOTES, 'UTF-8'); ?>" 
                           class="form-control" 
                           style="padding: 2px 8px; font-size: 12px; width: 180px;">
                    <button type="button" id="save-slug-btn" class="btn btn-secondary" style="padding: 2px 8px; font-size: 11px;">OK</button>
                </div>
            </div>

            <?php include APP_ROOT . '/resources/views/admin/partials/builder-backup.php'; ?>
            <!-- Professional Dual-Mode Post Editor -->
            <div class="editor-wrapper cms-simple-editor<?php echo $builderState ? ' cms-has-builder cms-builder-mode' : ''; ?>" style="background: var(--admin-surface); border: 1px solid var(--wp-border); border-radius: 6px; overflow: hidden; margin-bottom: 24px; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                <!-- Top Bar: Mode Switcher & Word Count -->
                <div style="background: var(--admin-surface-subtle); border-bottom: 1px solid var(--wp-border); padding: 8px 12px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
                    <!-- Mode Switcher -->
                    <div style="display: flex; gap: 4px; background: var(--admin-surface-elevated); padding: 3px; border-radius: 6px;">
                        <button type="button" id="mode-visual-btn" class="mode-tab-btn<?php echo $builderState ? '' : ' active'; ?>" style="padding: 5px 14px; font-size: 12px; font-weight: 600; border: none; border-radius: 4px; cursor: pointer; background: var(--admin-surface); color: var(--wp-blue); box-shadow: 0 1px 2px rgba(0,0,0,0.08);">
                            &#9998; Visual Mode
                        </button>
                        <button type="button" id="mode-code-btn" class="mode-tab-btn" style="padding: 5px 14px; font-size: 12px; font-weight: 600; border: none; border-radius: 4px; cursor: pointer; background: transparent; color: var(--wp-text-muted);">
                            &lt;/&gt; Code Mode
                        </button>
                        <?php
                        $fpbEditorUrl = $isEdit ? \FavoriteCMS\Core\Hook::applyFilters('favorite_page_builder_post_edit_url', '', $postId) : '';
                        $fpbEditorUrl = is_string($fpbEditorUrl) && str_starts_with($fpbEditorUrl, '/') && !str_starts_with($fpbEditorUrl, '//') ? $fpbEditorUrl : '';
                        if ($fpbEditorUrl !== ''):
                        ?>
                            <a href="<?php echo htmlspecialchars($fpbEditorUrl, ENT_QUOTES, 'UTF-8'); ?>" class="mode-tab-btn<?php echo $builderState ? ' active' : ''; ?>" data-fpb-link style="padding:5px 10px;font-size:12px;font-weight:600;border-radius:4px;color:var(--wp-text-muted);text-decoration:none;white-space:nowrap;" onclick="return confirm('Save any unsaved changes in Simple Edit before opening Favorite Page Builder. Continue?');">▦ Favorite Page Builder</a>
                        <?php elseif ($builderState): ?>
                            <button type="button" class="mode-tab-btn active" data-fpb-link style="padding:5px 10px;font-size:12px;font-weight:600;border:0;border-radius:4px;">▦ Favorite Page Builder</button>
                        <?php elseif (!$isEdit && \FavoriteCMS\Core\Hook::applyFilters('favorite_page_builder_available', false)): ?>
                            <button type="button" class="mode-tab-btn" title="Save the new post first" style="padding:5px 10px;font-size:12px;border-radius:4px;opacity:.75;" onclick="alert('Save this new post as a Draft first. Then open it with Favorite Page Builder.');">▦ Favorite Page Builder</button>
                        <?php endif; ?>
                    </div>

                    <!-- Right helpers -->
                    <div style="display: flex; align-items: center; gap: 12px; font-size: 12px; color: var(--wp-text-muted);">
                        <span id="editor-word-count">Words: 0</span>
                        <span id="editor-char-count">Chars: 0</span>
                        <span id="autosave-status" style="color: var(--admin-text-muted); font-style: italic;"></span>
                    </div>
                </div>

                <?php include APP_ROOT . '/resources/views/admin/partials/builder-content.php'; ?>
                <!-- Visual Mode Formatting Toolbar -->
                <div id="visual-toolbar" style="background: var(--admin-surface); border-bottom: 1px solid var(--wp-border); padding: 6px 10px; display: flex; gap: 4px; flex-wrap: wrap; align-items: center;">
                    <!-- Style block dropdown -->
                    <select id="format-block-select" class="toolbar-select" title="Paragraph Format">
                        <option value="p">Paragraph</option>
                        <option value="h1">Heading 1</option>
                        <option value="h2">Heading 2</option>
                        <option value="h3">Heading 3</option>
                        <option value="h4">Heading 4</option>
                        <option value="pre">Preformatted</option>
                    </select>

                    <span class="toolbar-sep"></span>

                    <!-- Font styling buttons -->
                    <button type="button" class="rich-btn" data-cmd="bold" title="Bold (Ctrl+B)"><strong>B</strong></button>
                    <button type="button" class="rich-btn" data-cmd="italic" title="Italic (Ctrl+I)"><em>I</em></button>
                    <button type="button" class="rich-btn" data-cmd="underline" title="Underline (Ctrl+U)"><u>U</u></button>
                    <button type="button" class="rich-btn" data-cmd="strikeThrough" title="Strikethrough"><s>S</s></button>

                    <span class="toolbar-sep"></span>

                    <!-- Alignment buttons -->
                    <button type="button" class="rich-btn" data-cmd="justifyLeft" title="Align Left">&#9776;</button>
                    <button type="button" class="rich-btn" data-cmd="justifyCenter" title="Align Center">&#9868;</button>
                    <button type="button" class="rich-btn" data-cmd="justifyRight" title="Align Right">&#9777;</button>
                    <button type="button" class="rich-btn" data-cmd="justifyFull" title="Justify">&#9778;</button>

                    <span class="toolbar-sep"></span>

                    <!-- Lists & Indent -->
                    <button type="button" class="rich-btn" data-cmd="insertUnorderedList" title="Bullet List">&bull; List</button>
                    <button type="button" class="rich-btn" data-cmd="insertOrderedList" title="Numbered List">1. List</button>
                    <button type="button" class="rich-btn" data-cmd="outdent" title="Decrease Indent">&larr;</button>
                    <button type="button" class="rich-btn" data-cmd="indent" title="Increase Indent">&rarr;</button>

                    <span class="toolbar-sep"></span>

                    <!-- Inserts -->
                    <button type="button" class="rich-btn" data-cmd="formatBlock" data-val="blockquote" title="Quote Block">&ldquo;&rdquo;</button>
                    <button type="button" class="rich-btn" data-cmd="insertHorizontalRule" title="Horizontal Line">&mdash;</button>
                    <button type="button" class="rich-btn" id="insert-link-btn" title="Insert / Edit Link">&#128279; Link</button>
                    <button type="button" class="rich-btn" data-cmd="unlink" title="Remove Link">&#10060;</button>

                    <span class="toolbar-sep"></span>

                    <!-- Table button -->
                    <button type="button" class="rich-btn" id="insert-table-btn" title="Insert Table">&#128392; Table</button>

                    <!-- Media button -->
                    <button type="button" class="rich-btn" id="open-media-modal-btn" style="background: var(--admin-success-bg); border-color: var(--admin-success-border); color: var(--admin-success-text); font-weight: 600;" title="Insert Media Image or File">
                        &#128247; Add Media
                    </button>

                    <span class="toolbar-sep"></span>

                    <!-- Undo, Redo, Clear -->
                    <button type="button" class="rich-btn" data-cmd="undo" title="Undo (Ctrl+Z)">&#8617;</button>
                    <button type="button" class="rich-btn" data-cmd="redo" title="Redo (Ctrl+Y)">&#8618;</button>
                    <button type="button" class="rich-btn" data-cmd="removeFormat" title="Clear Formatting">&#129529;</button>
                </div>

                <!-- Code Mode Secondary Bar (Quick Tag Inserts) -->
                <div id="code-toolbar" style="display: none; background: var(--admin-surface); border-bottom: 1px solid var(--wp-border); padding: 6px 10px; gap: 4px; flex-wrap: wrap; align-items: center;">
                    <span style="font-size: 11px; font-weight: 600; color: var(--admin-text-muted); margin-right: 4px;">HTML Inserts:</span>
                    <button type="button" class="code-insert-btn" data-snip="<h2>", data-endsnip="</h2>">H2</button>
                    <button type="button" class="code-insert-btn" data-snip="<h3>", data-endsnip="</h3>">H3</button>
                    <button type="button" class="code-insert-btn" data-snip="<p>", data-endsnip="</p>">&lt;p&gt;</button>
                    <button type="button" class="code-insert-btn" data-snip="<strong>", data-endsnip="</strong>">&lt;strong&gt;</button>
                    <button type="button" class="code-insert-btn" data-snip="<em>", data-endsnip="</em>">&lt;em&gt;</button>
                    <button type="button" class="code-insert-btn" data-snip="<a href=&quot;https://&quot;>", data-endsnip="</a>">&lt;a&gt;</button>
                    <button type="button" class="code-insert-btn" data-snip="<blockquote>\n  ", data-endsnip="\n</blockquote>">&lt;quote&gt;</button>
                    <button type="button" class="code-insert-btn" data-snip="<ul>\n  <li>", data-endsnip="</li>\n</ul>">&lt;ul&gt;</button>
                    <button type="button" class="code-insert-btn" data-snip="<ol>\n  <li>", data-endsnip="</li>\n</ol>">&lt;ol&gt;</button>
                    <button type="button" class="code-insert-btn" data-snip="<pre><code>", data-endsnip="</code></pre>">&lt;code&gt;</button>
                    <button type="button" class="code-insert-btn" id="code-wrap-toggle" aria-pressed="false" title="Toggle code wrapping">↔ Wrap: Off</button>
                    <button type="button" class="code-insert-btn" id="open-media-code-btn" style="background: var(--admin-success-bg); border-color: var(--admin-success-border); color: var(--admin-success-text); font-weight: 600;">&#128247; Add Media</button>
                </div>

                <!-- 1. Visual Mode Content Container (contenteditable) -->
                <div id="visual-mode-container" style="display: block; height: 500px; min-height: 500px; padding: 20px 24px; background: var(--admin-surface); cursor: text; box-sizing: border-box; overflow-x: auto; overflow-y: auto;">
                    <div id="visual-editor" 
                         contenteditable="true" 
                         class="entry-content" 
                         style="outline: none; min-height: 440px; font-size: 15px; line-height: 1.7; color: var(--admin-text-heading);">
                        <?php echo $revision['visual'] ?? $editorContent; ?>
                    </div>
                </div>

                <!-- 2. Code Mode Container (with synchronized Line Numbers Gutter) -->
                <div id="code-mode-container" style="display: none; height: 500px; min-height: 500px; background: var(--admin-code-bg); position: relative; overflow: hidden; box-sizing: border-box;">
                    <div style="display: flex; width: 100%; height: 100%; min-height: 0; overflow: hidden;">
                        <!-- Gutter for Line Numbers -->
                        <div id="code-gutter" style="flex: 0 0 48px; width: 48px; height: 100%; box-sizing: border-box; background: var(--admin-code-bg); color: var(--admin-text-muted); font-family: Consolas, Monaco, monospace; font-size: 13px; line-height: 1.6; padding: 14px 6px; text-align: right; user-select: none; border-right: 1px solid var(--admin-border); overflow: hidden;">
                            1
                        </div>
                        <!-- Source Textarea -->
                        <textarea id="code-editor" 
                                  class="code-editor-textarea" 
                                  wrap="off"
                                  style="flex: 1 1 auto; width: 0; min-width: 0; height: 100%; min-height: 0; box-sizing: border-box; background: var(--admin-code-bg); color: var(--admin-code-text); font-family: Consolas, Monaco, 'Courier New', monospace; font-size: 13px; line-height: 1.6; border: none; padding: 14px; outline: none; resize: none; tab-size: 2; white-space: pre; overflow: auto;" 
                                  placeholder="Write your post HTML content here..."><?php echo htmlspecialchars($editorContent, ENT_QUOTES, 'UTF-8'); ?></textarea>
                    </div>
                </div>

                <!-- Canonical Single Form Field -->
                <textarea id="post-content" name="content" style="display: none;"><?php echo htmlspecialchars($editorContent, ENT_QUOTES, 'UTF-8'); ?></textarea>
            </div>

            <!-- Excerpt Box -->
            <div class="form-card" style="margin-bottom: 24px;">
                <h3 style="font-size: 14px; font-weight: 600; margin-bottom: 8px;">Excerpt</h3>
                <textarea id="excerpt" 
                          name="excerpt" 
                          class="form-control" 
                          style="min-height: 80px;" 
                          placeholder="Write an optional short summary of this post for post cards and search feeds..."><?php echo htmlspecialchars($post->excerpt ?? '', ENT_QUOTES, 'UTF-8'); ?></textarea>
                <span class="description">Excerpts are optional hand-crafted summaries that appear on the homepage, archives, and social cards.</span>
            </div>

            <!-- SEO Settings Box -->
            <?php if ($currentUser && $currentUser->canEditContentSeo($post)): ?>
            <div class="form-card">
                <h3 style="font-size: 14px; margin-bottom: 14px; font-weight: 600; border-bottom: 1px solid var(--wp-border); padding-bottom: 8px;">
                    Search Engine Optimization (SEO) & Social Meta
                </h3>
                <div class="form-group">
                    <label for="meta_title">SEO Title</label>
                    <input type="text" id="meta_title" name="meta_title" class="form-control" value="<?php echo htmlspecialchars($seo->meta_title ?? '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="Custom title for Google search results">
                </div>
                <div class="form-group">
                    <label for="meta_description">Meta Description</label>
                    <textarea id="meta_description" name="meta_description" class="form-control" style="min-height: 60px;" placeholder="Brief description displayed in search snippets..."><?php echo htmlspecialchars($seo->meta_description ?? '', ENT_QUOTES, 'UTF-8'); ?></textarea>
                </div>
                <div class="form-group">
                    <label for="og_image_url">Social image URL (optional)</label>
                    <input type="text" inputmode="url" id="og_image_url" name="og_image_url" class="form-control" value="<?php echo htmlspecialchars($seo->og_image_url ?? '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="Auto: featured image or first content image">
                </div>
                <?php $seoEditorItem = $post ?? null; include APP_ROOT . '/resources/views/partials/seo-editor.php'; ?>
                <div class="form-row">
                    <div class="form-group">
                        <label for="og_title">Social (Open Graph) Title</label>
                        <input type="text" id="og_title" name="og_title" class="form-control" value="<?php echo htmlspecialchars($seo->og_title ?? '', ENT_QUOTES, 'UTF-8'); ?>">
                    </div>
                    <div class="form-group">
                        <label for="og_description">Social Description</label>
                        <input type="text" id="og_description" name="og_description" class="form-control" value="<?php echo htmlspecialchars($seo->og_description ?? '', ENT_QUOTES, 'UTF-8'); ?>">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="canonical_url">Canonical URL Override</label>
                        <input type="url" id="canonical_url" name="canonical_url" class="form-control" value="<?php echo htmlspecialchars($seo->canonical_url ?? '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="Leave blank to use default post URL">
                    </div>
                    <div class="form-group">
                        <label for="robots">Robots Meta Directive</label>
                        <select id="robots" name="robots" class="form-control">
                            <?php $currentRobots = $seo->robots ?? 'index,follow'; ?>
                            <option value="index,follow" <?php echo ($currentRobots === 'index,follow') ? 'selected' : ''; ?>>Index, Follow (Default)</option>
                            <option value="noindex,follow" <?php echo ($currentRobots === 'noindex,follow') ? 'selected' : ''; ?>>Noindex, Follow</option>
                            <option value="noindex,nofollow" <?php echo ($currentRobots === 'noindex,nofollow') ? 'selected' : ''; ?>>Noindex, Nofollow</option>
                            <option value="index,nofollow" <?php echo ($currentRobots === 'index,nofollow') ? 'selected' : ''; ?>>Index, Nofollow</option>
                        </select>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <!-- Right Sidebar Column -->
        <div class="editor-sidebar-sticky">
            <!-- Publish Controls Card -->
            <div class="form-card" style="margin-bottom: 20px;">
                <h3 style="font-size: 14px; font-weight: 600; margin-bottom: 14px; border-bottom: 1px solid var(--wp-border); padding-bottom: 8px;">
                    Publish
                </h3>

                <?php if ($post?->status === 'pending'): ?>
                    <div style="background: var(--admin-warning-bg); color: var(--admin-warning-text); padding: 10px; border-radius: 4px; font-size: 12px; margin-bottom: 12px; border-left: 3px solid var(--admin-warning-border);">
                        &#9888; <strong>Pending Moderation:</strong> This post is awaiting review and approval by a moderator.
                    </div>
                <?php elseif ($post?->status === 'rejected'): ?>
                    <div style="background: var(--admin-danger-bg); color: var(--admin-danger-text); padding: 10px; border-radius: 4px; font-size: 12px; margin-bottom: 12px; border-left: 3px solid var(--admin-danger-border);">
                        &#10007; <strong>Rejected:</strong> This post was rejected during moderation. You may update and resubmit it.
                    </div>
                <?php endif; ?>

                <?php $publicationType='post';require APP_ROOT.'/resources/views/admin/partials/publication-controls.php'; ?>

                <?php if ($isEdit && $post?->status === 'pending' && $currentUser && $currentUser->canModeratePosts()): ?>
                    <div style="display: flex; gap: 8px; margin-top: 12px; padding-top: 10px; border-top: 1px solid var(--wp-border);">
                        <button type="submit" form="core-action-form" formmethod="POST" formnovalidate formaction="<?php echo htmlspecialchars(site_base_path(), ENT_QUOTES, 'UTF-8'); ?>/admin/posts/approve?id=<?php echo $postId; ?>" class="btn btn-primary" style="flex: 1; text-align: center; background: var(--admin-success-solid); border-color: var(--admin-success-border); font-weight: 600;">&#10003; Approve Post</button>
                        <button type="submit" form="core-action-form" formmethod="POST" formnovalidate formaction="<?php echo htmlspecialchars(site_base_path(), ENT_QUOTES, 'UTF-8'); ?>/admin/posts/reject?id=<?php echo $postId; ?>" class="btn btn-secondary" style="color: var(--admin-danger-text); font-weight: 600;">&#10007; Reject</button>
                    </div>
                <?php endif; ?>

                <?php if ($isEdit): ?>
                    <div style="margin-top: 14px; text-align: right;">
                        <button type="submit" form="core-action-form" formmethod="POST" formnovalidate formaction="<?php echo htmlspecialchars(site_base_path(), ENT_QUOTES, 'UTF-8'); ?>/admin/posts/trash?id=<?php echo $postId; ?>" class="core-action-link"
                            onclick="return confirm('Move this post to trash?');" 
                            style="color: var(--wp-danger); font-size: 12px;">
                            Move to Trash
                        </button>
                    </div>
                <?php endif; ?>
            </div>

            <?php $contentType = 'post'; $contentRecord = $post ?? null; include APP_ROOT . '/resources/views/admin/partials/content-layout.php'; ?>

            <!-- Featured Image Card connected to Media Library, Local Upload & URL Import -->
            <div class="form-card feat-img-card" style="margin-bottom: 20px;">
                <h3 style="font-size: 14px; font-weight: 600; margin-bottom: 10px; border-bottom: 1px solid var(--wp-border); padding-bottom: 8px;">
                    Featured Image
                </h3>
                <input type="hidden" id="featured_image_id" name="featured_image_id" value="<?php echo (int)($post?->featured_image_id ?? 0); ?>">

                <!-- Error Box -->
                <div id="feat-img-error" class="feat-img-error" style="display: none;"></div>

                <!-- Preview container -->
                <div id="featured-image-preview" style="<?php echo $currentFeatImg ? '' : 'display: none;'; ?> margin-bottom: 12px;">
                    <div class="feat-img-preview-box">
                        <img id="feat-img-display" 
                             src="<?php echo htmlspecialchars($currentFeatImg->url ?? '', ENT_QUOTES, 'UTF-8'); ?>" 
                             alt="Featured Image" 
                             style="width: 100%; max-height: 180px; object-fit: cover; display: block;">
                    </div>
                    <div style="margin-top: 8px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 6px;">
                        <button type="button" id="change-feat-img-btn" class="btn btn-secondary" style="font-size: 11px; padding: 2px 8px;">Change Image</button>
                        <button type="button" id="remove-feat-img-btn" style="background: none; border: none; color: var(--wp-danger); font-size: 11px; cursor: pointer; text-decoration: underline;">Remove Image</button>
                    </div>
                </div>

                <!-- Empty / Input state container -->
                <div id="featured-image-actions" style="<?php echo $currentFeatImg ? 'display: none;' : ''; ?>">
                    <div style="display: flex; flex-direction: column; gap: 8px; margin-bottom: 8px;">
                        <button type="button" id="set-feat-img-btn" class="btn btn-secondary" style="width: 100%; font-size: 12px; display: flex; align-items: center; justify-content: center; gap: 6px;">
                            &#128193; Choose from Media Library
                        </button>
                        <div style="display: flex; gap: 6px;">
                            <input type="file" id="feat-img-file-input" accept="image/*" style="display: none;">
                            <button type="button" id="upload-feat-img-btn" class="btn btn-secondary" style="flex: 1; font-size: 12px; display: flex; align-items: center; justify-content: center; gap: 6px;">
                                &#128229; Upload Image
                            </button>
                            <button type="button" id="toggle-url-import-btn" class="btn btn-secondary" style="flex: 1; font-size: 12px; display: flex; align-items: center; justify-content: center; gap: 6px;">
                                &#127760; Import URL
                            </button>
                        </div>
                    </div>

                    <!-- URL Import Row (toggleable) -->
                    <div id="feat-img-url-box" style="display: none; margin-top: 8px; padding: 10px; background: var(--admin-surface-subtle); border: 1px solid var(--wp-border); border-radius: 4px;">
                        <label style="display: block; font-size: 11px; font-weight: 600; margin-bottom: 4px; color: var(--admin-text-heading);">Image URL (HTTP/HTTPS):</label>
                        <div style="display: flex; gap: 6px;">
                            <input type="url" id="feat-img-url-input" class="form-control" placeholder="https://example.com/image.jpg" style="font-size: 12px; padding: 4px 8px; flex: 1;">
                            <button type="button" id="feat-img-url-submit-btn" class="btn btn-primary" style="font-size: 11px; padding: 4px 10px; white-space: nowrap;">Import</button>
                        </div>
                        <span id="feat-img-url-loading" style="display: none; font-size: 11px; color: var(--wp-blue); margin-top: 4px;">Downloading &amp; verifying...</span>
                    </div>
                </div>
                <span class="description" style="margin-top: 8px; display: block;">Upload directly, import from URL, or choose from your media library.</span>
            </div>

            <!-- Categories Card -->
            <div class="form-card" style="margin-bottom: 20px;">
                <h3 style="font-size: 14px; font-weight: 600; margin-bottom: 10px; border-bottom: 1px solid var(--wp-border); padding-bottom: 8px;">
                    Categories
                </h3>
                <div style="max-height: 190px; overflow-y: auto; padding: 2px 0;">
                    <?php if (empty($categories)): ?>
                        <p style="color: var(--wp-text-muted); font-size: 12px;">No categories created yet.</p>
                    <?php else: ?>
                        <?php foreach ($categories as $cat): ?>
                            <label style="display: flex; align-items: center; gap: 8px; font-weight: 400; font-size: 13px; margin-bottom: 6px; cursor: pointer;">
                                <input type="checkbox" name="categories[]" value="<?php echo (int)$cat->id; ?>" <?php echo in_array((int)$cat->id, $selectedCats ?? [], true) ? 'checked' : ''; ?>>
                                <?php echo htmlspecialchars($cat->name, ENT_QUOTES, 'UTF-8'); ?>
                            </label>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                <div style="margin-top: 8px; border-top: 1px solid var(--wp-border); padding-top: 8px;">
                    <a href="<?php echo htmlspecialchars(site_path('/admin/taxonomies/categories'), ENT_QUOTES, 'UTF-8'); ?>" target="_blank" style="font-size: 12px;">+ Manage Categories</a>
                </div>
            </div>

            <!-- Tags Card -->
            <div class="form-card">
                <h3 style="font-size: 14px; font-weight: 600; margin-bottom: 10px; border-bottom: 1px solid var(--wp-border); padding-bottom: 8px;">
                    Tags
                </h3>
                <input type="text" name="tags" class="form-control" placeholder="news, tech, episodes" value="<?php echo htmlspecialchars($tagsString ?? '', ENT_QUOTES, 'UTF-8'); ?>">
                <span class="description" style="margin-top: 4px; display: block;">Separate tags with commas.</span>
            </div>
        </div>
    </div>
</form>

<!-- Live Post Preview Modal -->
<div id="preview-modal" style="display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.65); z-index: 100000; align-items: center; justify-content: center;">
    <div style="background: var(--admin-surface); width: 95%; max-width: 960px; height: 90vh; border-radius: 8px; display: flex; flex-direction: column; overflow: hidden; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25);">
        <div style="padding: 12px 20px; border-bottom: 1px solid var(--wp-border); display: flex; justify-content: space-between; align-items: center; background: var(--admin-surface-subtle);">
            <div style="font-weight: 700; font-size: 14px; color: var(--admin-text-heading); display: flex; align-items: center; gap: 8px;">
                <span>&#128065; Live Post Preview</span>
                <span style="font-weight: normal; font-size: 11px; color: var(--wp-text-muted);">(Rendered with Theme Styling)</span>
            </div>
            <button type="button" id="close-preview-modal" style="background: none; border: none; font-size: 22px; cursor: pointer; color: var(--admin-text-muted);">&times;</button>
        </div>
        <div style="flex: 1; overflow: hidden; background: var(--admin-surface-subtle);">
            <iframe id="preview-iframe" name="preview-iframe" style="width: 100%; height: 100%; border: none; background: var(--admin-surface);"></iframe>
        </div>
    </div>
</div>

<!-- Enhanced Media Library & Direct Upload Modal -->
<?php include APP_ROOT . '/resources/views/admin/partials/media-modal.php'; ?>

<style>
.mode-tab-btn {
    transition: all 0.15s ease;
}
.mode-tab-btn.active {
    background: var(--admin-surface) !important;
    color: var(--wp-blue) !important;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}
.toolbar-select {
    border: 1px solid var(--wp-border);
    border-radius: 4px;
    padding: 3px 6px;
    font-size: 12px;
    background: var(--admin-surface);
    color: var(--admin-text-heading);
    cursor: pointer;
}
.toolbar-sep {
    display: inline-block;
    width: 1px;
    height: 18px;
    background: var(--wp-border);
    margin: 0 4px;
}
.rich-btn {
    background: var(--admin-surface);
    border: 1px solid var(--wp-border);
    border-radius: 3px;
    padding: 3px 8px;
    font-size: 12px;
    color: var(--admin-text-heading);
    cursor: pointer;
    line-height: 1.4;
    transition: background 0.1s ease;
}
.rich-btn:hover {
    background: var(--admin-surface-subtle);
    border-color: var(--wp-blue);
    color: var(--wp-blue);
}
.rich-btn.active {
    background: var(--admin-info-bg);
    border-color: var(--wp-blue);
    color: var(--wp-blue);
}
.code-insert-btn {
    background: var(--admin-surface-subtle);
    border: 1px solid var(--admin-border);
    border-radius: 3px;
    padding: 2px 6px;
    font-size: 11px;
    font-family: monospace;
    color: var(--admin-text);
    cursor: pointer;
}
.code-insert-btn:hover {
    background: var(--admin-surface-elevated);
    color: var(--wp-blue);
}
.media-filter-btn {
    background: var(--admin-surface);
    border: 1px solid var(--wp-border);
    border-radius: 3px;
    padding: 2px 8px;
    font-size: 11px;
    cursor: pointer;
    color: var(--admin-text-muted);
}
.media-filter-btn.active {
    background: var(--wp-blue);
    border-color: var(--wp-blue);
    color: #ffffff;
}
.media-picker-card {
    border: 2px solid transparent;
    border-radius: 6px;
    cursor: pointer;
    overflow: hidden;
    background: var(--admin-surface);
    box-shadow: 0 1px 2px rgba(0,0,0,0.05);
    text-align: center;
    padding: 4px;
    transition: all 0.15s ease;
}
.media-picker-card img {
    width: 100%;
    height: 80px;
    object-fit: cover;
    border-radius: 4px;
    display: block;
}
.media-picker-card .card-name {
    font-size: 11px;
    margin-top: 4px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    color: var(--admin-text-muted);
}
.media-picker-card:hover {
    border-color: var(--wp-blue) !important;
    background: var(--admin-info-bg) !important;
}
.media-picker-card.selected {
    border-color: var(--wp-blue) !important;
    box-shadow: 0 0 0 2px var(--wp-blue);
    background: var(--admin-info-bg) !important;
}
/* Visual Editor Styling matching Theme Content */
#visual-editor p { margin-bottom: 1em; }
#visual-editor h1, #visual-editor h2, #visual-editor h3, #visual-editor h4 { margin-top: 1.2em; margin-bottom: 0.5em; font-weight: 700; color: var(--admin-text-heading); }
#visual-editor blockquote { border-left: 4px solid var(--wp-blue); margin: 1em 0; padding: 8px 16px; background: var(--admin-surface-subtle); font-style: italic; color: var(--admin-text-muted); }
#visual-editor ul, #visual-editor ol { margin: 1em 0 1em 24px; }
#visual-editor li { margin-bottom: 0.3em; }
#visual-editor table { border-collapse: collapse; width: 100%; margin: 1em 0; }
#visual-editor th, #visual-editor td { border: 1px solid var(--admin-border); padding: 8px 12px; text-align: left; }
#visual-editor th { background: var(--admin-surface-subtle); font-weight: 600; }
#visual-editor img { max-width: 100%; height: auto; border-radius: 4px; }
#visual-editor img.align-center { display: block; margin: 1em auto; }
#visual-editor img.align-left { float: left; margin: 0 1em 1em 0; }
#visual-editor img.align-right { float: right; margin: 0 0 1em 1em; }
#visual-editor pre { background: var(--admin-code-bg); color: var(--admin-code-text); padding: 12px 16px; border-radius: 6px; overflow-x: auto; font-family: monospace; font-size: 13px; }

/* Post editor only: clean two-axis scrollbars. */
#visual-mode-container,
#code-editor {
    scrollbar-width: thin;
    scrollbar-color: #64748b transparent;
}
#visual-mode-container::-webkit-scrollbar,
#code-editor::-webkit-scrollbar {
    width: 8px;
    height: 8px;
}
#visual-mode-container::-webkit-scrollbar-track,
#code-editor::-webkit-scrollbar-track {
    background: transparent;
}
#visual-mode-container::-webkit-scrollbar-thumb,
#code-editor::-webkit-scrollbar-thumb {
    background: var(--admin-text-muted);
    border-radius: 999px;
    border: 2px solid transparent;
    background-clip: padding-box;
}
#visual-mode-container::-webkit-scrollbar-thumb:hover,
#code-editor::-webkit-scrollbar-thumb:hover {
    background: var(--admin-text-muted);
    background-clip: padding-box;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var postId         = <?php echo $postId; ?>;
    var titleInput     = document.getElementById('post-title');
    var slugDisplay    = document.getElementById('slug-display');
    var slugInput      = document.getElementById('slug-input');
    var editSlugBtn    = document.getElementById('edit-slug-btn');
    var saveSlugBtn    = document.getElementById('save-slug-btn');
    var slugEditWrap   = document.getElementById('slug-edit-wrap');

    var canonicalContent = document.getElementById('post-content');
    var visualEditor   = document.getElementById('visual-editor');
    var codeEditor     = document.getElementById('code-editor');
    var codeGutter     = document.getElementById('code-gutter');

    var modeVisualBtn  = document.getElementById('mode-visual-btn');
    var modeCodeBtn    = document.getElementById('mode-code-btn');
    var visualContainer= document.getElementById('visual-mode-container');
    var codeContainer  = document.getElementById('code-mode-container');
    var visualToolbar  = document.getElementById('visual-toolbar');
    var codeToolbar    = document.getElementById('code-toolbar');

    var form           = document.getElementById('post-editor-form');
    var actionType     = document.getElementById('action_type');
    var statusSelect   = document.getElementById('status');
    var formatSelect   = document.getElementById('format-block-select');

    var wordCountEl    = document.getElementById('editor-word-count');
    var charCountEl    = document.getElementById('editor-char-count');
    var autosaveStatus = document.getElementById('autosave-status');

    var editorStorage = { get: function(k) { try { return localStorage.getItem(k); } catch(e) { return null; } }, set: function(k,v) { try { localStorage.setItem(k,v); } catch(e) {} } };
    var editorModeKey = <?php echo json_encode('favorite_post_editor_mode:' . (int)($_SESSION['auth_user_id'] ?? 0) . ':' . $postId); ?>;
    var currentMode = editorStorage.get(editorModeKey) || editorStorage.get('favorite_post_editor_mode') || 'visual';
    if (currentMode !== 'visual' && currentMode !== 'code') currentMode = 'visual';
    var codeWrapEnabled = editorStorage.get('favorite_post_editor_code_wrap') === '1';
    var isUserEditedSlug = <?php echo ($isEdit && !empty($post->slug)) ? 'true' : 'false'; ?>;

    // ==========================================
    // 1. Slug Management
    // ==========================================
    function slugify(text) {
        return text.toString().toLowerCase().trim()
            .replace(/\s+/g, '-')
            .replace(/[^\w\-]+/g, '')
            .replace(/\-\-+/g, '-');
    }

    titleInput.addEventListener('input', function() {
        if (!isUserEditedSlug) {
            var s = slugify(this.value);
            slugDisplay.textContent = s || 'auto-generated';
            slugInput.value = s;
        }
    });

    editSlugBtn.addEventListener('click', function() {
        slugDisplay.style.display = 'none';
        editSlugBtn.style.display = 'none';
        slugEditWrap.style.display = 'inline-flex';
        slugInput.focus();
    });

    saveSlugBtn.addEventListener('click', function() {
        var s = slugify(slugInput.value);
        slugInput.value = s;
        slugDisplay.textContent = s || 'auto-generated';
        slugDisplay.style.display = 'inline-block';
        editSlugBtn.style.display = 'inline-block';
        slugEditWrap.style.display = 'none';
        isUserEditedSlug = true;
    });

    // ==========================================
    // 2. Metrics & Line Numbers Calculation
    // ==========================================
    function updateMetrics() {
        var text = (currentMode === 'visual') ? (visualEditor.innerText || '') : (codeEditor.value || '');
        var words = text.trim() ? text.trim().split(/\s+/).length : 0;
        var chars = text.length;
        wordCountEl.textContent = 'Words: ' + words;
        charCountEl.textContent = 'Chars: ' + chars;
    }

    function updateCodeGutter() {
        var lines = (codeEditor.value.match(/\n/g) || []).length + 1;
        var numbers = [];
        for (var i = 1; i <= lines; i++) {
            numbers.push(i);
        }
        codeGutter.innerHTML = numbers.join('<br>');
    }

    function applyCodeWrap(enabled) {
        codeWrapEnabled = !!enabled;
        codeEditor.setAttribute('wrap', codeWrapEnabled ? 'soft' : 'off');
        codeEditor.style.whiteSpace = codeWrapEnabled ? 'pre-wrap' : 'pre';
        codeEditor.style.overflowX = codeWrapEnabled ? 'hidden' : 'auto';
        var wrapBtn = document.getElementById('code-wrap-toggle');
        if (wrapBtn) {
            wrapBtn.textContent = codeWrapEnabled ? '↔ Wrap: On' : '↔ Wrap: Off';
            wrapBtn.setAttribute('aria-pressed', codeWrapEnabled ? 'true' : 'false');
            wrapBtn.classList.toggle('active', codeWrapEnabled);
        }
        editorStorage.set('favorite_post_editor_code_wrap', codeWrapEnabled ? '1' : '0');
    }

    var codeWrapToggle = document.getElementById('code-wrap-toggle');
    if (codeWrapToggle) {
        codeWrapToggle.addEventListener('click', function() {
            applyCodeWrap(!codeWrapEnabled);
            codeEditor.focus();
        });
    }
    applyCodeWrap(codeWrapEnabled);

    codeEditor.addEventListener('input', function() {
        updateCodeGutter();
        updateMetrics();
        triggerAutosave();
    });

    codeEditor.addEventListener('scroll', function() {
        codeGutter.scrollTop = codeEditor.scrollTop;
    });

    // Support Tab key in Code Mode for clean indentation
    codeEditor.addEventListener('keydown', function(e) {
        if (e.key === 'Tab') {
            e.preventDefault();
            var start = this.selectionStart;
            var end = this.selectionEnd;
            this.value = this.value.substring(0, start) + '  ' + this.value.substring(end);
            this.selectionStart = this.selectionEnd = start + 2;
            updateCodeGutter();
        }
    });

    visualEditor.addEventListener('input', function() {
        updateMetrics();
        triggerAutosave();
    });

    // ==========================================
    // 3. Bidirectional Mode Synchronization
    // ==========================================
    function setEditorMode(mode, initializing) {
        if (mode === 'code') {
            // Visual -> Code sync
            var html = visualEditor.innerHTML;
            if (!initializing) codeEditor.value = html;
            updateCodeGutter();

            visualContainer.style.display = 'none';
            visualToolbar.style.display = 'none';
            codeContainer.style.display = 'block';
            codeToolbar.style.display = 'flex';

            modeCodeBtn.classList.add('active');
            modeVisualBtn.classList.remove('active');
            currentMode = 'code';
            if (!initializing) { editorStorage.set(editorModeKey, 'code'); editorStorage.set('favorite_post_editor_mode', 'code'); }
        } else {
            // Code -> Visual sync
            var code = codeEditor.value;
            if (!initializing) visualEditor.innerHTML = code || '<p></p>';

            codeContainer.style.display = 'none';
            codeToolbar.style.display = 'none';
            visualContainer.style.display = 'block';
            visualToolbar.style.display = 'flex';

            modeVisualBtn.classList.add('active');
            modeCodeBtn.classList.remove('active');
            currentMode = 'visual';
            if (!initializing) { editorStorage.set(editorModeKey, 'visual'); editorStorage.set('favorite_post_editor_mode', 'visual'); }
        }
        modeVisualBtn.setAttribute('aria-selected', String(mode !== 'code'));
        modeCodeBtn.setAttribute('aria-selected', String(mode === 'code'));
        var builderTab = form.querySelector('[data-fpb-link]');
        if (builderTab) { builderTab.classList.remove('active'); builderTab.setAttribute('aria-selected', 'false'); }
        updateMetrics();
    }

    modeVisualBtn.addEventListener('click', function() { setEditorMode('visual'); });
    modeCodeBtn.addEventListener('click', function() { setEditorMode('code'); });

    // Initialize mode
    setEditorMode(currentMode, true);

    // ==========================================
    // 4. Visual Mode Rich-Text Toolbar Commands
    // ==========================================
    document.querySelectorAll('.rich-btn[data-cmd]').forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            var cmd = this.getAttribute('data-cmd');
            var val = this.getAttribute('data-val') || null;

            visualEditor.focus();
            document.execCommand(cmd, false, val);
            updateMetrics();
        });
    });

    // Paragraph format block selector
    formatSelect.addEventListener('change', function() {
        var val = this.value;
        visualEditor.focus();
        if (val === 'pre') {
            document.execCommand('formatBlock', false, 'pre');
        } else {
            document.execCommand('formatBlock', false, '<' + val + '>');
        }
    });

    // Link insertion
    document.getElementById('insert-link-btn').addEventListener('click', function() {
        var currentUrl = 'https://';
        var url = prompt('Enter link URL:', currentUrl);
        if (url && url.trim() !== '') {
            visualEditor.focus();
            document.execCommand('createLink', false, url.trim());
        }
    });

    // Table insertion
    document.getElementById('insert-table-btn').addEventListener('click', function() {
        var rows = parseInt(prompt('Number of rows:', '3') || '0', 10);
        var cols = parseInt(prompt('Number of columns:', '3') || '0', 10);
        if (rows > 0 && cols > 0) {
            var tableHtml = '<table><thead><tr>';
            for (var c = 1; c <= cols; c++) {
                tableHtml += '<th>Header ' + c + '</th>';
            }
            tableHtml += '</tr></thead><tbody>';
            for (var r = 1; r <= rows; r++) {
                tableHtml += '<tr>';
                for (var c = 1; c <= cols; c++) {
                    tableHtml += '<td>Cell ' + r + '-' + c + '</td>';
                }
                tableHtml += '</tr>';
            }
            tableHtml += '</tbody></table><p></p>';

            visualEditor.focus();
            document.execCommand('insertHTML', false, tableHtml);
            updateMetrics();
        }
    });

    // Paste Cleanup Handler: strips Word/Docs MSO junk
    visualEditor.addEventListener('paste', function(e) {
        var clipboardData = e.clipboardData || window.clipboardData;
        if (!clipboardData) return;

        var pastedHtml = clipboardData.getData('text/html');
        if (pastedHtml) {
            e.preventDefault();
            // Clean MSO tags and excessive styles
            var cleaned = pastedHtml
                .replace(/<!--[\s\S]*?-->/g, '')
                .replace(/<\/?o:[^>]*>/gi, '')
                .replace(/class="mso[^"]*"/gi, '')
                .replace(/style="[^"]*mso-[^"]*"/gi, '');
            document.execCommand('insertHTML', false, cleaned);
            updateMetrics();
        }
    });

    // Quick tag insert in Code Mode
    document.querySelectorAll('.code-insert-btn[data-snip]').forEach(function(btn) {
        btn.addEventListener('click', function() {
            var snip = this.getAttribute('data-snip');
            var endsnip = this.getAttribute('data-endsnip') || '';
            var start = codeEditor.selectionStart;
            var end = codeEditor.selectionEnd;
            var val = codeEditor.value;
            var selected = val.substring(start, end);

            var insertion = snip + selected + endsnip;
            codeEditor.value = val.substring(0, start) + insertion + val.substring(end);
            codeEditor.focus();
            codeEditor.selectionStart = start + snip.length;
            codeEditor.selectionEnd = start + snip.length + selected.length;
            updateCodeGutter();
            updateMetrics();
        });
    });

    // ==========================================
    // 5. Canonical Form Submission Sync
    // ==========================================
    form.favoriteEditor = {
        read: function() { syncContentToCanonical(); return canonicalContent.value; },
        set: function(value) { codeEditor.value = value; setEditorMode('code', true); canonicalContent.value = value; updateCodeGutter(); updateMetrics(); }
    };
    function syncContentToCanonical() {
        if (currentMode === 'visual') {
            canonicalContent.value = visualEditor.innerHTML;
        } else {
            canonicalContent.value = codeEditor.value;
        }
    }

    // ==========================================
    // 6. Live Theme Preview
    // ==========================================
    var previewBtn   = document.getElementById('preview-post-btn');
    var previewModal = document.getElementById('preview-modal');
    var previewIframe= document.getElementById('preview-iframe');
    var closePreview = document.getElementById('close-preview-modal');

    previewBtn.addEventListener('click', function() {
        syncContentToCanonical();

        // Create temporary form to POST to /admin/posts/preview with iframe target
        var tempForm = document.createElement('form');
        tempForm.method = 'POST';
        tempForm.action = <?php echo json_encode(site_path('/admin/posts/preview'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
        tempForm.target = 'preview-iframe';
        tempForm.style.display = 'none';

        var titleField = document.createElement('input');
        titleField.name = 'title';
        titleField.value = titleInput.value || 'Untitled Preview';
        tempForm.appendChild(titleField);

        var contentField = document.createElement('input');
        contentField.name = 'content';
        contentField.value = canonicalContent.value;
        tempForm.appendChild(contentField);

        var featField = document.createElement('input');
        featField.name = 'featured_image_id';
        featField.value = document.getElementById('featured_image_id').value;
        tempForm.appendChild(featField);

        var tokenField = document.createElement('input');
        tokenField.name = '_token';
        tokenField.value = '<?php echo htmlspecialchars($_SESSION['_token'] ?? '', ENT_QUOTES, 'UTF-8'); ?>';
        tempForm.appendChild(tokenField);
        ['id', '_content_revision', 'sidebar_layout'].forEach(function(name) {
            var source = form.querySelector('[name="' + name + '"]');
            if (source) { var field = document.createElement('input'); field.name = name; field.value = source.value; tempForm.appendChild(field); }
        });

        document.body.appendChild(tempForm);
        previewModal.style.display = 'flex';
        tempForm.submit();
        document.body.removeChild(tempForm);
    });

    closePreview.addEventListener('click', function() {
        previewModal.style.display = 'none';
        previewIframe.src = 'about:blank';
    });

    // ==========================================
    // 7. LocalStorage Autosave Disaster Recovery
    // ==========================================
    var autosaveTimer = null;
    var contentBaseline = <?php echo json_encode(hash('sha256', (string)($post->content ?? ''))); ?>;
    var freshRevisionToken = form.querySelector('[name="_content_revision"]').value;
    var draftPrefix = <?php echo json_encode(\FavoriteCMS\Services\DraftReceipt::prefix($currentUser), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    function draftId() {
        var bytes = new Uint8Array(16); window.crypto.getRandomValues(bytes);
        return Array.from(bytes, function(b) { return b.toString(16).padStart(2, '0'); }).join('');
    }
    var newDraftId = '';
    if (!postId) {
        try {
            newDraftId = sessionStorage.getItem(draftPrefix + 'new-tab') || draftId();
            sessionStorage.setItem(draftPrefix + 'new-tab', newDraftId);
        } catch(e) { newDraftId = draftId(); }
    }
    var draftStorageKey = draftPrefix + (postId || ('new-' + newDraftId));
    var draftReceipts = <?php echo json_encode($_SESSION['draft_receipts'] ?? [], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); unset($_SESSION['draft_receipts']); ?>;
    draftReceipts.forEach(function(receipt) {
        try {
            var snapshot = JSON.parse(localStorage.getItem(receipt.key) || 'null');
            if (receipt.key.indexOf(draftPrefix) === 0 && snapshot && snapshot.revision === receipt.revision) localStorage.removeItem(receipt.key);
        } catch(e) {}
    });
    function draftField(name, value) {
        var field = form.querySelector('[name="' + name + '"]');
        if (!field) { field = document.createElement('input'); field.type = 'hidden'; field.name = name; form.appendChild(field); }
        field.value = value;
    }
    function saveDraftSnapshot() {
        clearTimeout(autosaveTimer);
        var payload = {
            title: titleInput.value,
            content: (currentMode === 'visual') ? visualEditor.innerHTML : codeEditor.value,
            slug: slugInput.value,
            baseline: contentBaseline,
            revisionToken: form.querySelector('[name="_content_revision"]').value,
            revision: draftId(), time: new Date().toISOString()
        };
        draftField('_draft_key', draftStorageKey);
        draftField('_draft_snapshot', payload.revision);
        try {
            localStorage.setItem(draftStorageKey, JSON.stringify(payload));
            autosaveStatus.textContent = 'Draft autosaved locally (' + new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) + ')';
        } catch(e) { autosaveStatus.textContent = 'Browser draft storage is unavailable. Keep a copy until the server confirms saving.'; }
    }
    function triggerAutosave() {
        clearTimeout(autosaveTimer);
        autosaveTimer = setTimeout(saveDraftSnapshot, 2000);
    }
    form.addEventListener('submit', function() { syncContentToCanonical(); saveDraftSnapshot(); });
    function clearDraftSnapshot() {
        clearTimeout(autosaveTimer);
        try { localStorage.removeItem(draftStorageKey); } catch(e) {}
    }

    // Persistent discovery also finds new-post drafts from closed tabs/sessions.
    try {
        var recoverySelect = document.getElementById('draft-recovery-select');
        var recoveryDrafts = [];
        for (var draftIndex = 0; draftIndex < localStorage.length; draftIndex++) {
            var storedKey = localStorage.key(draftIndex);
            if (storedKey !== draftStorageKey && (postId || storedKey.indexOf(draftPrefix + 'new-') !== 0)) continue;
            try {
                var storedDraft = JSON.parse(localStorage.getItem(storedKey));
                if (storedDraft && typeof storedDraft.content === 'string' && (storedDraft.content.trim() !== canonicalContent.value.trim() || storedDraft.title !== titleInput.value || storedDraft.slug !== slugInput.value)) {
                    recoveryDrafts.push({key: storedKey, draft: storedDraft});
                }
            } catch(e) {}
        }
        recoveryDrafts.sort(function(a,b) { return (b.draft.time || '').localeCompare(a.draft.time || ''); });
        recoveryDrafts.forEach(function(item, index) {
            var option = document.createElement('option'); option.value = index;
            option.textContent = (item.draft.title || 'Untitled') + ' — ' + (item.draft.time || '');
            recoverySelect.appendChild(option);
        });
        var banner = document.getElementById('autosave-banner');
        if (recoveryDrafts.length) banner.style.display = 'flex';
        recoverySelect.style.display = recoveryDrafts.length > 1 ? '' : 'none';
        document.getElementById('restore-draft-btn').addEventListener('click', function() {
            var selected = recoveryDrafts[Number(recoverySelect.value)];
            if (!selected) return;
            var savedDraft = selected.draft;
            draftStorageKey = selected.key;
            if (typeof savedDraft.title === 'string') titleInput.value = savedDraft.title;
            if (typeof savedDraft.slug === 'string') slugInput.value = savedDraft.slug;
            var restoredContent = savedDraft.content;
            var restoredToken = savedDraft.revisionToken || '';
            if (restoredToken && freshRevisionToken && savedDraft.baseline === contentBaseline) {
                restoredContent = restoredContent.split('data-favorite-protected="' + restoredToken + '-').join('data-favorite-protected="' + freshRevisionToken + '-');
                restoredToken = freshRevisionToken;
            }
            form.querySelector('[name="_content_revision"]').value = restoredToken;
            // Restore into code mode so browser-local content is never executed on restore.
            codeEditor.value = restoredContent;
            setEditorMode('code', true);
            canonicalContent.value = restoredContent;
            updateCodeGutter(); updateMetrics();
            banner.style.display = 'none';
        });
        document.getElementById('dismiss-draft-btn').addEventListener('click', function() {
            var selected = recoveryDrafts[Number(recoverySelect.value)];
            if (selected) localStorage.removeItem(selected.key);
            recoverySelect.remove(recoverySelect.selectedIndex);
            if (!recoverySelect.options.length) banner.style.display = 'none';
        });
    } catch(e) {}

    // ==========================================
    // 8. Media Library Modal with Upload & Progress
    // ==========================================
    var mediaModal      = document.getElementById('media-modal');
    var closeMediaModalBtn = document.getElementById('close-media-modal');
    var cancelMediaBtn  = document.getElementById('cancel-media-selection');
    var confirmMediaBtn = document.getElementById('confirm-media-selection');

    var tabBrowseBtn    = document.getElementById('tab-browse-media');
    var tabUploadBtn    = document.getElementById('tab-upload-media');
    var viewBrowse      = document.getElementById('modal-view-browse');
    var viewUpload      = document.getElementById('modal-view-upload');

    var featIdInput     = document.getElementById('featured_image_id');
    var featPreview     = document.getElementById('featured-image-preview');
    var featActions     = document.getElementById('featured-image-actions');
    var featDisplay     = document.getElementById('feat-img-display');
    var featFileInput   = document.getElementById('feat-img-file-input');
    var uploadFeatBtn   = document.getElementById('upload-feat-img-btn');
    var toggleUrlBtn    = document.getElementById('toggle-url-import-btn');
    var featUrlBox      = document.getElementById('feat-img-url-box');
    var featUrlInput    = document.getElementById('feat-img-url-input');
    var featUrlSubmit   = document.getElementById('feat-img-url-submit-btn');
    var featUrlLoading  = document.getElementById('feat-img-url-loading');
    var featErrorBox    = document.getElementById('feat-img-error');

    function showFeatImgError(msg) {
        if (featErrorBox) {
            featErrorBox.textContent = msg;
            featErrorBox.style.display = 'block';
        }
    }

    function clearFeatImgError() {
        if (featErrorBox) {
            featErrorBox.textContent = '';
            featErrorBox.style.display = 'none';
        }
    }

    function setFeaturedImage(id, url, name) {
        clearFeatImgError();
        featIdInput.value = id;
        featDisplay.src   = url;
        featPreview.style.display = 'block';
        if (featActions) featActions.style.display = 'none';
        if (featUrlBox) featUrlBox.style.display = 'none';
        if (featUrlInput) featUrlInput.value = '';
    }

    function removeFeaturedImage() {
        clearFeatImgError();
        featIdInput.value = '0';
        featDisplay.src   = '';
        featPreview.style.display = 'none';
        if (featActions) featActions.style.display = 'block';
    }

    var selectedMedia   = null;
    var modalTarget     = 'content'; // 'content' or 'featured'

    function openMediaModal(target) {
        modalTarget = target;
        confirmMediaBtn.textContent = (target === 'featured') ? 'Set Featured Image' : 'Insert Into Post';
        document.getElementById('content-insert-options').style.display = (target === 'featured') ? 'none' : 'block';
        mediaModal.style.display = 'flex';
        switchModalTab('browse');
    }

    function closeMediaModal() {
        mediaModal.style.display = 'none';
    }

    function switchModalTab(tab) {
        if (tab === 'browse') {
            tabBrowseBtn.classList.add('active');
            tabUploadBtn.classList.remove('active');
            tabBrowseBtn.style.background = 'var(--admin-surface)';
            tabBrowseBtn.style.color = 'var(--wp-blue)';
            tabBrowseBtn.style.borderColor = 'var(--wp-blue)';
            tabUploadBtn.style.background = 'var(--admin-surface-subtle)';
            tabUploadBtn.style.color = 'var(--admin-text-muted)';
            tabUploadBtn.style.borderColor = 'var(--wp-border)';
            viewBrowse.style.display = 'flex';
            viewUpload.style.display = 'none';
        } else {
            tabUploadBtn.classList.add('active');
            tabBrowseBtn.classList.remove('active');
            tabUploadBtn.style.background = 'var(--admin-surface)';
            tabUploadBtn.style.color = 'var(--wp-blue)';
            tabUploadBtn.style.borderColor = 'var(--wp-blue)';
            tabBrowseBtn.style.background = 'var(--admin-surface-subtle)';
            tabBrowseBtn.style.color = 'var(--admin-text-muted)';
            tabBrowseBtn.style.borderColor = 'var(--wp-border)';
            viewBrowse.style.display = 'none';
            viewUpload.style.display = 'block';
        }
    }

    tabBrowseBtn.addEventListener('click', function() { switchModalTab('browse'); });
    tabUploadBtn.addEventListener('click', function() { switchModalTab('upload'); });
    var emptyUploadBtn = document.getElementById('empty-go-upload-btn');
    if (emptyUploadBtn) emptyUploadBtn.addEventListener('click', function() { switchModalTab('upload'); });

    document.getElementById('open-media-modal-btn').addEventListener('click', function() { openMediaModal('content'); });
    document.getElementById('open-media-code-btn').addEventListener('click', function() { openMediaModal('content'); });
    document.getElementById('set-feat-img-btn').addEventListener('click', function() { openMediaModal('featured'); });
    document.getElementById('change-feat-img-btn').addEventListener('click', function() { openMediaModal('featured'); });
    closeMediaModalBtn.addEventListener('click', closeMediaModal);
    cancelMediaBtn.addEventListener('click', closeMediaModal);

    // Media library browsing: bounded batches from the server for filters, search and "Load more"
    var mediaGrid     = document.getElementById('modal-media-grid');
    var mediaMoreBtn  = document.getElementById('modal-media-more-btn');
    var mediaStatus   = document.getElementById('modal-media-status');
    var mediaState    = {
        page: 1,
        perPage: <?php echo (int)($mediaBatchSize ?? 24); ?>,
        category: 'all',
        search: '',
        hasMore: <?php echo count($mediaItems ?? []) < (int)($mediaTotal ?? 0) ? 'true' : 'false'; ?>,
        loading: false,
        requestId: 0
    };

    function escapeMediaHtml(value) {
        return String(value === null || value === undefined ? '' : value).replace(/[&<>"']/g, function(ch) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch];
        });
    }

    function buildMediaCard(m) {
        var card = document.createElement('div');
        card.className = 'media-picker-card';
        card.setAttribute('data-id', m.id);
        card.setAttribute('data-url', m.url);
        card.setAttribute('data-name', m.filename);
        card.setAttribute('data-cat', m.category);
        card.setAttribute('data-mime', m.mime_type || '');
        card.setAttribute('data-size', m.formatted_size || '');

        var inner;
        if (m.is_image) {
            inner = '<img src="' + escapeMediaHtml(m.thumbnail_url || m.url) + '" data-original-src="' + escapeMediaHtml(m.url) + '" alt="' + escapeMediaHtml(m.filename) + '" loading="lazy" onerror="if(this.dataset.originalSrc && this.src!==this.dataset.originalSrc){this.src=this.dataset.originalSrc;}else{this.style.display=\'none\';}">';
        } else if (m.is_video) {
            inner = '<div style="height: 80px; display: flex; align-items: center; justify-content: center; background: var(--admin-code-bg); color: var(--admin-code-text); font-size: 24px;">&#127916;</div>';
        } else if (m.is_audio) {
            inner = '<div style="height: 80px; display: flex; align-items: center; justify-content: center; background: var(--admin-code-bg); color: var(--admin-code-text); font-size: 24px;">&#127925;</div>';
        } else {
            inner = '<div style="height: 80px; display: flex; align-items: center; justify-content: center; background: var(--admin-surface-elevated); font-size: 24px;">&#128196;</div>';
        }
        inner += '<div class="card-name">' + escapeMediaHtml(m.filename) + '</div>';
        card.innerHTML = inner;
        card.addEventListener('click', function() { selectCard(this); });
        return card;
    }

    function loadMediaBatch(reset) {
        if (mediaState.loading && !reset) return;
        var requestId = ++mediaState.requestId;
        var page = reset ? 1 : mediaState.page + 1;
        mediaState.loading = true;
        if (mediaStatus) mediaStatus.textContent = 'Loading media...';

        var xhr = new XMLHttpRequest();
        xhr.open('GET', <?php echo json_encode(site_path('/admin/media/library?page='), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?> + page + '&per_page=' + mediaState.perPage + '&category=' + encodeURIComponent(mediaState.category) + '&s=' + encodeURIComponent(mediaState.search), true);
        xhr.onload = function() {
            if (requestId !== mediaState.requestId) return;
            mediaState.loading = false;
            var res = null;
            try { res = JSON.parse(xhr.responseText); } catch (e) {}
            if (xhr.status !== 200 || !res || !res.success) {
                if (mediaStatus) mediaStatus.textContent = 'Could not load media. Please try again.';
                return;
            }
            if (reset) mediaGrid.innerHTML = '';
            res.items.forEach(function(m) {
                if (mediaGrid.querySelector('.media-picker-card[data-id="' + m.id + '"]')) return;
                mediaGrid.appendChild(buildMediaCard(m));
            });
            mediaState.page = res.page;
            mediaState.hasMore = !!res.has_more;
            var shown = mediaGrid.querySelectorAll('.media-picker-card').length;
            if (mediaStatus) mediaStatus.textContent = res.total === 0 ? 'No media files match this filter.' : 'Showing ' + shown + ' of ' + res.total;
            if (mediaMoreBtn) mediaMoreBtn.style.display = mediaState.hasMore ? '' : 'none';
        };
        xhr.onerror = function() {
            if (requestId !== mediaState.requestId) return;
            mediaState.loading = false;
            if (mediaStatus) mediaStatus.textContent = 'Network error while loading media.';
        };
        xhr.send();
    }

    // Filter media items in modal
    document.querySelectorAll('.media-filter-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.media-filter-btn').forEach(function(b) { b.classList.remove('active'); });
            this.classList.add('active');
            mediaState.category = this.getAttribute('data-cat') || 'all';
            loadMediaBatch(true);
        });
    });

    // Search media items in modal
    var mediaSearchTimer = null;
    document.getElementById('modal-search-input').addEventListener('input', function() {
        var value = this.value.trim();
        clearTimeout(mediaSearchTimer);
        mediaSearchTimer = setTimeout(function() {
            mediaState.search = value;
            loadMediaBatch(true);
        }, 300);
    });

    if (mediaMoreBtn) {
        mediaMoreBtn.addEventListener('click', function() { loadMediaBatch(false); });
    }

    // Card selection in modal
    function selectCard(card) {
        document.querySelectorAll('.media-picker-card').forEach(function(c) { c.classList.remove('selected'); });
        card.classList.add('selected');

        selectedMedia = {
            id: card.getAttribute('data-id'),
            url: card.getAttribute('data-url'),
            name: card.getAttribute('data-name'),
            cat: card.getAttribute('data-cat'),
            mime: card.getAttribute('data-mime'),
            size: card.getAttribute('data-size')
        };

        document.getElementById('attachment-details-empty').style.display = 'none';
        document.getElementById('attachment-details-wrap').style.display = 'block';
        document.getElementById('attachment-filename').textContent = selectedMedia.name;
        document.getElementById('attachment-meta').textContent = selectedMedia.size + ' • ' + selectedMedia.mime;
        document.getElementById('insert-alt-text').value = selectedMedia.name.replace(/\.[^/.]+$/, "");

        var thumbEl = document.getElementById('attachment-thumb');
        if (selectedMedia.cat === 'image') {
            thumbEl.innerHTML = '<img src="' + escapeMediaHtml(selectedMedia.url) + '" style="max-width: 100%; max-height: 120px; object-fit: contain;" onerror="this.style.display=\'none\';">';
        } else {
            thumbEl.innerHTML = '<div style="padding: 24px; font-size: 32px;">&#128196;</div>';
        }

        var selectedMediaSummary = document.getElementById('selected-media-summary');
        if (selectedMediaSummary) selectedMediaSummary.textContent = 'Selected: ' + selectedMedia.name;
        confirmMediaBtn.disabled = false;
    }

    document.querySelectorAll('.media-picker-card').forEach(function(card) {
        card.addEventListener('click', function() { selectCard(this); });
    });

    // Modal File Upload with Progress
    var modalFileInput = document.getElementById('modal-file-input');
    var modalSelectBtn = document.getElementById('modal-select-file-btn');
    var modalUploadZone = document.getElementById('modal-upload-zone');
    var modalProgWrap  = document.getElementById('modal-progress-wrap');
    var modalProgBar   = document.getElementById('modal-progress-bar');
    var modalProgPct   = document.getElementById('modal-progress-percent');
    var modalProgName  = document.getElementById('modal-progress-filename');
    var modalStatusMsg = document.getElementById('modal-upload-status');

    modalSelectBtn.addEventListener('click', function() { modalFileInput.click(); });

    function handleModalUpload(file) {
        if (!file) return;

        var formData = new FormData();
        formData.append('file', file);
        formData.append('_token', '<?php echo htmlspecialchars($_SESSION['_token'] ?? '', ENT_QUOTES, 'UTF-8'); ?>');

        modalProgWrap.style.display = 'block';
        modalProgBar.style.width = '0%';
        modalProgPct.textContent = '0%';
        modalProgName.textContent = file.name;
        modalStatusMsg.style.color = 'var(--admin-text)';
        modalStatusMsg.textContent = 'Uploading file...';

        var xhr = new XMLHttpRequest();
        xhr.open('POST', <?php echo json_encode(site_path('/admin/media/upload-ajax'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>, true);

        xhr.upload.onprogress = function(e) {
            if (e.lengthComputable) {
                var pct = Math.round((e.loaded / e.total) * 100);
                modalProgBar.style.width = pct + '%';
                modalProgPct.textContent = pct + '%';
            }
        };

        xhr.onload = function() {
            if (xhr.status === 200) {
                try {
                    var res = JSON.parse(xhr.responseText);
                    if (res.success && res.media) {
                        modalProgBar.style.width = '100%';
                        modalProgPct.textContent = '100%';
                        modalStatusMsg.style.color = 'var(--admin-success-text)';
                        modalStatusMsg.textContent = 'Upload successful!';

                        // Add new card to grid
                        var m = res.media;
                        var grid = document.getElementById('modal-media-grid');
                        var card = document.createElement('div');
                        card.className = 'media-picker-card';
                        card.setAttribute('data-id', m.id);
                        card.setAttribute('data-url', m.url);
                        card.setAttribute('data-name', m.filename);
                        card.setAttribute('data-cat', m.category);
                        card.setAttribute('data-mime', m.mime_type);
                        card.setAttribute('data-size', m.formatted_size);

                        var innerHtml = '';
                        if (m.is_image) {
                            innerHtml = '<img src="' + escapeMediaHtml(m.thumbnail_url || m.url) + '" data-original-src="' + escapeMediaHtml(m.url) + '" alt="' + escapeMediaHtml(m.filename) + '" onerror="if(this.dataset.originalSrc && this.src!==this.dataset.originalSrc){this.src=this.dataset.originalSrc;}else{this.style.display=\'none\';}">';
                        } else {
                            innerHtml = '<div style="height: 80px; display: flex; align-items: center; justify-content: center; background: var(--admin-surface-elevated); font-size: 24px;">&#128196;</div>';
                        }
                        innerHtml += '<div class="card-name">' + m.filename + '</div>';
                        card.innerHTML = innerHtml;

                        card.addEventListener('click', function() { selectCard(this); });
                        grid.insertBefore(card, grid.firstChild);

                        setTimeout(function() {
                            switchModalTab('browse');
                            selectCard(card);
                        }, 600);
                        return;
                    }
                } catch(err) {}
            }

            var err = 'Upload failed.';
            try {
                var errObj = JSON.parse(xhr.responseText);
                if (errObj.message) err = errObj.message;
            } catch(e) {}

            modalStatusMsg.style.color = 'var(--admin-danger-text)';
            modalStatusMsg.textContent = err;
        };

        xhr.onerror = function() {
            modalStatusMsg.style.color = 'var(--admin-danger-text)';
            modalStatusMsg.textContent = 'Network error occurred.';
        };

        xhr.send(formData);
    }

    modalFileInput.addEventListener('change', function() {
        if (this.files.length > 0) handleModalUpload(this.files[0]);
    });

    modalUploadZone.addEventListener('dragover', function(e) {
        e.preventDefault();
        this.style.borderColor = 'var(--wp-blue)';
        this.style.background = 'var(--admin-info-bg)';
    });

    modalUploadZone.addEventListener('dragleave', function() {
        this.style.borderColor = 'var(--admin-border)';
        this.style.background = 'var(--admin-surface)';
    });

    modalUploadZone.addEventListener('drop', function(e) {
        e.preventDefault();
        this.style.borderColor = 'var(--admin-border)';
        this.style.background = 'var(--admin-surface)';
        if (e.dataTransfer.files.length > 0) {
            handleModalUpload(e.dataTransfer.files[0]);
        }
    });

    // Confirm Modal Selection (Featured Image or Content Insert)
    confirmMediaBtn.addEventListener('click', function() {
        if (!selectedMedia) return;

        if (modalTarget === 'featured') {
            setFeaturedImage(selectedMedia.id, selectedMedia.url, selectedMedia.name);
        } else {
            // Build HTML for Content Insertion
            var align = document.getElementById('insert-align-select').value;
            var size  = document.getElementById('insert-size-select').value;
            var alt   = document.getElementById('insert-alt-text').value || selectedMedia.name;
            var mediaHtml = '';

            var alignClass = (align !== 'none') ? ' class="align-' + align + '"' : '';
            var styleAttr = '';
            if (size === 'medium') styleAttr = ' style="max-width: 600px;"';
            else if (size === 'thumbnail') styleAttr = ' style="max-width: 250px;"';

            if (selectedMedia.cat === 'image') {
                mediaHtml = '<p><img src="' + selectedMedia.url + '" alt="' + alt + '"' + alignClass + styleAttr + '></p>\n';
            } else if (selectedMedia.cat === 'video') {
                mediaHtml = '<p><video src="' + selectedMedia.url + '" controls style="max-width: 100%; height: auto;"></video></p>\n';
            } else if (selectedMedia.cat === 'audio') {
                mediaHtml = '<p><audio src="' + selectedMedia.url + '" controls></audio></p>\n';
            } else {
                mediaHtml = '<p><a href="' + selectedMedia.url + '" target="_blank" class="download-link">&#128196; Download ' + alt + '</a></p>\n';
            }

            if (currentMode === 'visual') {
                visualEditor.focus();
                document.execCommand('insertHTML', false, mediaHtml);
                updateMetrics();
            } else {
                var start = codeEditor.selectionStart;
                var end   = codeEditor.selectionEnd;
                var val   = codeEditor.value;
                codeEditor.value = val.substring(0, start) + mediaHtml + val.substring(end);
                codeEditor.focus();
                updateCodeGutter();
                updateMetrics();
            }
        }

        closeMediaModal();
    });

    // Remove Featured Image
    var removeFeatBtn = document.getElementById('remove-feat-img-btn');
    if (removeFeatBtn) {
        removeFeatBtn.addEventListener('click', function() {
            removeFeaturedImage();
        });
    }

    // Direct Upload Featured Image
    if (uploadFeatBtn && featFileInput) {
        uploadFeatBtn.addEventListener('click', function() {
            featFileInput.click();
        });

        featFileInput.addEventListener('change', function() {
            if (!this.files.length) return;
            var file = this.files[0];
            clearFeatImgError();

            var formData = new FormData();
            formData.append('file', file);
            formData.append('_token', '<?php echo htmlspecialchars($_SESSION['_token'] ?? '', ENT_QUOTES, 'UTF-8'); ?>');

            uploadFeatBtn.disabled = true;
            uploadFeatBtn.textContent = 'Uploading...';

            var xhr = new XMLHttpRequest();
            xhr.open('POST', <?php echo json_encode(site_path('/admin/media/upload-ajax'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>, true);
            xhr.onload = function() {
                uploadFeatBtn.disabled = false;
                uploadFeatBtn.innerHTML = '&#128229; Upload Image';
                var res = null;
                try { res = JSON.parse(xhr.responseText); } catch (e) {}
                if (xhr.status === 200 && res && res.success && res.media) {
                    if (!res.media.is_image) {
                        showFeatImgError('The uploaded file is not an image.');
                        return;
                    }
                    setFeaturedImage(res.media.id, res.media.url, res.media.filename);
                } else {
                    showFeatImgError((res && res.message) ? res.message : 'Failed to upload image.');
                }
            };
            xhr.onerror = function() {
                uploadFeatBtn.disabled = false;
                uploadFeatBtn.innerHTML = '&#128229; Upload Image';
                showFeatImgError('Network error uploading image.');
            };
            xhr.send(formData);
            featFileInput.value = '';
        });
    }

    // Toggle Image URL Import Box
    if (toggleUrlBtn && featUrlBox) {
        toggleUrlBtn.addEventListener('click', function() {
            var isHidden = featUrlBox.style.display === 'none' || !featUrlBox.style.display;
            featUrlBox.style.display = isHidden ? 'block' : 'none';
            if (isHidden && featUrlInput) {
                featUrlInput.focus();
            }
        });
    }

    // Submit Image URL Import
    if (featUrlSubmit && featUrlInput) {
        function executeUrlImport() {
            var url = featUrlInput.value.trim();
            if (!url) {
                showFeatImgError('Please enter a valid image URL.');
                return;
            }
            clearFeatImgError();
            featUrlSubmit.disabled = true;
            if (featUrlLoading) featUrlLoading.style.display = 'block';

            var formData = new FormData();
            formData.append('url', url);
            formData.append('_token', '<?php echo htmlspecialchars($_SESSION['_token'] ?? '', ENT_QUOTES, 'UTF-8'); ?>');

            var xhr = new XMLHttpRequest();
            xhr.open('POST', <?php echo json_encode(site_path('/admin/media/import-url'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>, true);
            xhr.onload = function() {
                featUrlSubmit.disabled = false;
                if (featUrlLoading) featUrlLoading.style.display = 'none';
                var res = null;
                try { res = JSON.parse(xhr.responseText); } catch (e) {}
                if (xhr.status === 200 && res && res.success && res.media) {
                    setFeaturedImage(res.media.id, res.media.url, res.media.filename);
                } else {
                    showFeatImgError((res && res.message) ? res.message : 'Failed to import image from URL.');
                }
            };
            xhr.onerror = function() {
                featUrlSubmit.disabled = false;
                if (featUrlLoading) featUrlLoading.style.display = 'none';
                showFeatImgError('Network error importing image.');
            };
            xhr.send(formData);
        }

        featUrlSubmit.addEventListener('click', executeUrlImport);

        featUrlInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                executeUrlImport();
            }
        });
    }
});
</script>

<?php $workspaceType = 'post'; $workspaceRecord = $post ?? null; include APP_ROOT . '/resources/views/admin/partials/content-workspace.php'; ?>

<?php if ($builderState): ?><script data-cms-builder-editor-mode><?php include APP_ROOT . '/public/assets/js/builder-content.js'; ?></script><?php endif; ?>
