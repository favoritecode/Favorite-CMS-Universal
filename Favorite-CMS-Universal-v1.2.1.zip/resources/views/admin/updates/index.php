<?php
/**
 * site software — Core Updates Admin View
 *
 * @var string $currentVersion
 * @var array $discovery
 * @var array $extensionUpdates
 * @var array $health
 * @var array $state
 * @var array $logs
 * @var array|null $pendingPackage
 * @var bool $inProgress
 * @var string|null $notice
 * @var string|null $error
 * @var string $csrfToken
 */
$base = (string)($GLOBALS['favorite_cms_base_path'] ?? '');
?>

<div class="wrap cms-core-updates" style="width:100%; max-width:none; min-width:0; margin:0; padding-bottom:40px;">
    <!-- Header -->
    <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 24px; flex-wrap: wrap; gap: 12px;">
        <div>
            <h1 style="font-size: 24px; font-weight: 700; color: var(--admin-text-heading); margin: 0 0 4px 0; display: flex; align-items: center; gap: 10px;">
                🔄 Core Updates
                <span class="badge badge-secondary" style="font-size: 12px; font-weight: 600; text-transform: none;">
                    v<?php echo htmlspecialchars($currentVersion); ?>
                </span>
            </h1>
            <p style="color: var(--admin-text-muted); font-size: 13.5px; margin: 0;">
                Safely upgrade site software without losing posts, pages, plugins, media, or settings.
            </p>
        </div>

        <div>
            <form method="POST" action="<?php echo $base; ?>/admin/updates/check" style="display: inline;">
                <input type="hidden" name="_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                <button type="submit" class="btn btn-secondary" style="display: inline-flex; align-items: center; gap: 6px;">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>
                    Check for Updates
                </button>
            </form>
        </div>
    </div>

    <!-- Flash Notices -->
    <?php if (!empty($notice)): ?>
        <div class="notice notice-success">
            <strong>Success:</strong> <?php echo htmlspecialchars($notice); ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($error)): ?>
        <div class="notice notice-error">
            <strong>Error:</strong> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <!-- In Progress Alert -->
    <?php if (($state['state'] ?? '') === 'RECOVERY_REQUIRED'): ?>
        <div class="notice notice-error"><strong>Recovery required:</strong> Maintenance stays active until the previous files and database are restored and verified. Keep the pre-update backup. <?php echo htmlspecialchars((string)($state['database_recovery_note'] ?? $state['rollback_error'] ?? $state['error'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></div>
    <?php elseif ($inProgress): ?>
        <div class="notice notice-warning" style="display: flex; align-items: center; gap: 12px;">
            <div class="spinner" style="width: 16px; height: 16px; border: 2px solid var(--admin-warning-border); border-top-color: var(--admin-warning-border); border-radius: 50%; animation: spin 0.8s linear infinite;"></div>
            <div>
                <strong>Update Operation in Progress:</strong> A Core update is currently executing on this server. Maintenance mode is active. Please do not close or refresh this page.
            </div>
        </div>
    <?php endif; ?>

    <!-- Pending Uploaded Package Card -->
    <?php if ($pendingPackage): ?>
        <div class="card" style="border: 2px solid var(--admin-info-border); background: var(--admin-info-bg); margin-bottom: 24px;">
            <div class="card-header" style="background: var(--admin-info-bg); border-bottom: 1px solid var(--admin-info-border);">
                <h5 style="color: var(--admin-info-text); font-size: 15px; font-weight: 700; display: flex; align-items: center; gap: 8px;">
                    📦 Staged Update Package Ready for Installation
                </h5>
            </div>
            <div class="card-body">
                <p style="margin-bottom: 16px; font-size: 14px; color: var(--admin-info-text);">
                    A manual update package was uploaded and passed all security and structure validations:
                </p>

                <div style="background: var(--admin-surface); border: 1px solid var(--admin-info-border); border-radius: 6px; padding: 14px; margin-bottom: 20px;">
                    <div class="row">
                        <div class="col-md-6" style="margin-bottom: 8px;">
                            <strong>Package File:</strong> <code><?php echo htmlspecialchars((string)$pendingPackage['filename']); ?></code>
                        </div>
                        <div class="col-md-6" style="margin-bottom: 8px;">
                            <strong>Target Version:</strong> <span class="badge badge-primary">v<?php echo htmlspecialchars((string)$pendingPackage['version']); ?></span>
                        </div>
                        <div class="col-md-6" style="margin-bottom: 8px;">
                            <strong>Package Size:</strong> <?php echo round(((int)$pendingPackage['size']) / 1024 / 1024, 2); ?> MB
                        </div>
                        <div class="col-md-6" style="margin-bottom: 8px;">
                            <strong>SHA-256:</strong> <code style="font-size: 11px; word-break: break-all;"><?php echo htmlspecialchars((string)$pendingPackage['sha256']); ?></code>
                        </div>
                    </div>
                </div>

                <div style="background: var(--admin-warning-bg); border-left: 4px solid var(--admin-warning-border); padding: 12px 14px; border-radius: 4px; margin-bottom: 20px; font-size: 13px; color: var(--admin-warning-text);">
                    <strong>🛡️ Automatic Safety Guarantee:</strong> Before files are replaced, an automatic full backup of your website (database, uploads, themes, and plugins) will be created. Your existing database tables, media, and <code>.env</code> credentials will be preserved.
                </div>

                <div style="display: flex; gap: 12px; align-items: center;">
                    <form method="POST" action="<?php echo $base; ?>/admin/updates/apply" onsubmit="return confirm('Are you sure you want to proceed with installing this Core update? A full automatic backup will be created first.');">
                        <input type="hidden" name="_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                        <input type="hidden" name="source" value="manual">
                        <button type="submit" class="btn btn-primary" style="padding: 9px 20px; font-weight: 600; font-size: 14px;">
                            🚀 Install Update Now
                        </button>
                    </form>

                    <form method="POST" action="<?php echo $base; ?>/admin/updates/cancel-upload">
                        <input type="hidden" name="_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                        <button type="submit" class="btn btn-secondary">Cancel Upload</button>
                    </form>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <div class="row">
        <!-- Left Column: Update Sources & Actions -->
        <div class="col-md-7">
            <!-- Remote Update Card -->
            <div class="card">
                <div class="card-header">
                    <h5>Official GitHub Releases</h5>
                    <span class="text-muted" style="font-size: 12px;">
                        Channel: <strong>Stable Core</strong>
                    </span>
                </div>
                <div class="card-body">
                    <?php if (!empty($discovery['error'])): ?>
                        <div class="alert alert-warning" style="margin-bottom: 16px; font-size: 13px;">
                            <?php echo htmlspecialchars((string)$discovery['error']); ?>
                        </div>
                    <?php elseif (!empty($discovery['update_available']) || !empty($discovery['repair_available'])): ?>
                        <?php if (empty($discovery['sha256'])): ?>
                            <div class="notice notice-warning">This release does not provide a readable SHA-256 checksum. The archive structure will be checked, but its bytes cannot be compared with a published checksum.</div>
                        <?php endif; ?>
                        <div style="background: var(--admin-success-bg); border: 1px solid var(--admin-success-border); border-radius: 8px; padding: 16px; margin-bottom: 18px;">
                            <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px;">
                                <h4 style="margin: 0; color: var(--admin-success-text); font-size: 16px; font-weight: 700;">
                                    <?php if (!empty($discovery['repair_available']) && empty($discovery['update_available'])): ?>
                                    🛠️ Core Repair Available: v<?php echo htmlspecialchars((string)$discovery['latest_version']); ?>
                                <?php else: ?>
                                    🎉 New Version Available: v<?php echo htmlspecialchars((string)$discovery['latest_version']); ?>
                                <?php endif; ?>
                                </h4>
                                <span class="badge badge-success">
                                    <?php echo (!empty($discovery['repair_available']) && empty($discovery['update_available'])) ? 'Repair Available' : 'Update Available'; ?>
                                </span>
                            </div>

                            <p style="font-size: 13px; color: var(--admin-success-text); margin-bottom: 12px;">
                                <?php if (!empty($discovery['repair_available']) && empty($discovery['update_available'])): ?>
                                The current Core package can be re-applied to restore <?php echo count((array)($discovery['missing_core_files'] ?? [])); ?> missing Core file(s).
                            <?php else: ?>
                                A newer version of site software is ready. Published on <?php echo htmlspecialchars(date('M j, Y', strtotime((string)$discovery['published_at']))); ?>.
                            <?php endif; ?>
                            </p>

                            <?php if (!empty($discovery['release_notes'])): ?>
                                <details style="background: var(--admin-surface); border: 1px solid var(--admin-success-border); border-radius: 6px; padding: 10px; margin-bottom: 16px; font-size: 12.5px;">
                                    <summary style="cursor: pointer; font-weight: 600; color: var(--admin-success-text);">View Release Notes</summary>
                                    <pre style="white-space: pre-wrap; font-family: monospace; font-size: 11.5px; color: var(--admin-text); margin-top: 10px;"><?php echo htmlspecialchars((string)$discovery['release_notes']); ?></pre>
                                </details>
                            <?php endif; ?>

                            <form method="POST" action="<?php echo $base; ?>/admin/updates/apply" onsubmit="return confirm('<?php echo (!empty($discovery['repair_available']) && empty($discovery['update_available'])) ? 'Download and repair Core v' : 'Download and install Core update v'; ?><?php echo htmlspecialchars((string)$discovery['latest_version']); ?>? An automatic full backup will be created first.');">
                                <input type="hidden" name="_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                                <input type="hidden" name="source" value="remote">
                                <button type="submit" class="btn btn-success" style="padding: 9px 20px; font-weight: 600;">
                                    <?php echo (!empty($discovery['repair_available']) && empty($discovery['update_available'])) ? '🛠️ Repair Core Automatically' : '⚡ Download &amp; Update Automatically'; ?>
                                </button>
                            </form>
                        </div>
                    <?php else: ?>
                        <?php if (!empty($discovery['repair_inspection_error'])): ?>
                            <div class="notice notice-warning">Missing-file inspection could not be completed. Retry the check or upload the official Core ZIP to repair files.</div>
                        <?php endif; ?>
                        <div style="text-align: center; padding: 24px 16px;">
                            <div style="font-size: 36px; margin-bottom: 10px;">✅</div>
                            <h4 style="margin: 0 0 6px 0; color: var(--admin-text-heading); font-size: 16px;">No Newer Core Release Found</h4>
                            <p style="color: var(--admin-text-muted); font-size: 13px; margin: 0;">
                                Installed version: site software v<?php echo htmlspecialchars($currentVersion); ?>.
                            </p>
                        </div>
                    <?php endif; ?>

                    <div style="font-size: 12px; color: var(--admin-text-muted); border-top: 1px solid var(--admin-border); padding-top: 12px; display: flex; justify-content: space-between;">
                        <span>Last checked: <?php echo !empty($discovery['checked_at']) ? htmlspecialchars(date('Y-m-d H:i:s', strtotime((string)$discovery['checked_at']))) : 'Just now'; ?></span>
                        <a href="<?php echo htmlspecialchars((string)$discovery['release_url']); ?>" target="_blank" rel="noopener" style="color: var(--wp-blue);">GitHub Releases &rarr;</a>
                    </div>
                </div>
            </div>

            <!-- Installed Extension Updates Card (shown only if updates are available for installed extensions) -->
            <?php if (!empty($extensionUpdates)): ?>
                <div class="card" style="border: 1px solid var(--admin-purple-border); background: var(--admin-purple-bg); margin-bottom: 24px;">
                    <div class="card-header" style="background: var(--admin-purple-bg); border-bottom: 1px solid var(--admin-purple-border); display: flex; align-items: center; justify-content: space-between;">
                        <h5 style="color: var(--admin-purple-text); font-size: 15px; font-weight: 700; margin: 0; display: flex; align-items: center; gap: 8px;">
                            🧩 Installed Extension Updates
                        </h5>
                        <span class="badge" style="background: var(--admin-purple-solid); color: #ffffff; font-size: 11px;">
                            <?php echo count($extensionUpdates); ?> Available
                        </span>
                    </div>
                    <div class="card-body" style="padding: 16px;">
                        <p style="font-size: 13px; color: var(--admin-purple-text); margin-bottom: 14px;">
                            New versions are available for installed extensions from the official distribution repository:
                        </p>

                        <?php foreach ($extensionUpdates as $ext): ?>
                            <div style="background: var(--admin-surface); border: 1px solid var(--admin-purple-border); border-radius: 6px; padding: 14px; margin-bottom: 12px;">
                                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px;">
                                    <div>
                                        <strong style="font-size: 14px; color: var(--admin-purple-text);"><?php echo htmlspecialchars((string)$ext['name']); ?></strong>
                                        <span class="badge badge-secondary" style="font-size: 11px; margin-left: 6px; text-transform: uppercase;">
                                            <?php echo htmlspecialchars((string)$ext['type']); ?>
                                        </span>
                                    </div>
                                    <div style="font-size: 12.5px;">
                                        <span class="text-muted">v<?php echo htmlspecialchars((string)$ext['installed_version']); ?></span>
                                        &rarr;
                                        <span class="badge badge-success" style="font-weight: 600;">v<?php echo htmlspecialchars((string)$ext['available_version']); ?></span>
                                    </div>
                                </div>

                                <?php if (!empty($ext['release_notes'])): ?>
                                    <details style="font-size: 12px; color: var(--admin-text-muted); margin-bottom: 10px;">
                                        <summary style="cursor: pointer; color: var(--admin-purple-text);">View release highlights</summary>
                                        <div style="margin-top: 6px; white-space: pre-wrap; font-family: monospace; font-size: 11px; background: var(--admin-purple-bg); padding: 8px; border-radius: 4px;"><?php echo htmlspecialchars((string)$ext['release_notes']); ?></div>
                                    </details>
                                <?php endif; ?>

                                <form method="POST" action="<?php echo $base; ?>/admin/updates/apply-extension" onsubmit="return confirm('Update <?php echo htmlspecialchars((string)$ext['name']); ?> to version <?php echo htmlspecialchars((string)$ext['available_version']); ?>?');">
                                    <input type="hidden" name="_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                                    <input type="hidden" name="type" value="<?php echo htmlspecialchars((string)$ext['type']); ?>">
                                    <input type="hidden" name="id" value="<?php echo htmlspecialchars((string)$ext['id']); ?>">
                                    <input type="hidden" name="version" value="<?php echo htmlspecialchars((string)$ext['available_version']); ?>">
                                    <input type="hidden" name="download_url" value="<?php echo htmlspecialchars((string)$ext['download_url']); ?>">
                                    <input type="hidden" name="sha256" value="<?php echo htmlspecialchars((string)$ext['sha256']); ?>">
                                    <button type="submit" class="btn btn-primary" style="background: var(--admin-purple-solid); border-color: var(--admin-purple-border); padding: 6px 14px; font-size: 12.5px; font-weight: 600;">
                                        ⚡ Update <?php echo ucfirst((string)$ext['type']); ?> Now
                                    </button>
                                </form>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Manual ZIP Upload Card -->
            <div class="card">
                <div class="card-header">
                    <h5>Manual Package Upload</h5>
                    <span class="text-muted" style="font-size: 12px;">Shared Hosting &amp; Offline</span>
                </div>
                <div class="card-body">
                    <p style="font-size: 13px; color: var(--admin-text-muted); margin-bottom: 16px;">
                        If your server has outgoing network restrictions or you downloaded <code>Favorite-CMS-Universal.zip</code> manually, you can upload the release archive directly.
                    </p>

                    <form method="POST" action="<?php echo $base; ?>/admin/updates/upload" enctype="multipart/form-data">
                        <input type="hidden" name="_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                        <div style="margin-bottom: 16px;">
                            <label style="display: block; font-weight: 600; font-size: 13px; margin-bottom: 6px; color: var(--admin-text);">
                                Select Core Update Package (.zip):
                            </label>
                            <input type="file" name="update_package" accept=".zip" required class="form-control" style="font-size: 13px; padding: 8px;">
                        </div>

                        <button type="submit" class="btn btn-secondary" style="font-weight: 500;">
                            📤 Upload &amp; Validate Package
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Right Column: System Readiness & Pre-Update Health -->
        <div class="col-md-5">
            <div class="card">
                <div class="card-header">
                    <h5>System Readiness Check</h5>
                    <?php if ($health['passed']): ?>
                        <span class="badge badge-success">Ready</span>
                    <?php else: ?>
                        <span class="badge badge-danger">Attention Needed</span>
                    <?php endif; ?>
                </div>
                <div class="card-body" style="padding: 12px 16px;">
                    <ul style="list-style: none; padding: 0; margin: 0; font-size: 13px;">
                        <?php foreach ($health['checks'] as $key => $check): ?>
                            <li style="padding: 10px 0; border-bottom: 1px solid var(--admin-border); display: flex; align-items: flex-start; justify-content: space-between; gap: 8px;">
                                <div>
                                    <div style="font-weight: 600; color: var(--admin-text-heading);">
                                        <?php echo htmlspecialchars((string)$check['title']); ?>
                                    </div>
                                    <div style="font-size: 11.5px; color: var(--admin-text-muted);">
                                        <?php echo htmlspecialchars((string)$check['message']); ?>
                                    </div>
                                </div>
                                <div>
                                    <?php if ($check['passed']): ?>
                                        <span style="color: var(--admin-success-text); font-weight: 700; font-size: 14px;">✔</span>
                                    <?php else: ?>
                                        <span style="color: var(--admin-danger-text); font-weight: 700; font-size: 14px;">✖</span>
                                    <?php endif; ?>
                                </div>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>

            <!-- Data Preservation Card -->
            <div class="card" style="background: var(--admin-surface-subtle);">
                <div class="card-header">
                    <h5>Data Preservation Architecture</h5>
                </div>
                <div class="card-body" style="font-size: 12.5px; color: var(--admin-text-muted); line-height: 1.6;">
                    <p style="margin-bottom: 10px;">
                        site software uses a strict allowlist/denylist boundary:
                    </p>
                    <ul style="padding-left: 18px; margin-bottom: 12px;">
                        <li><strong>Database:</strong> Preserved completely; only non-destructive additive migrations are run.</li>
                        <li><strong>Media:</strong> <code>public/uploads/</code> is strictly protected and never modified.</li>
                        <li><strong>Plugins:</strong> Installed plugins in <code>plugins/</code> are never touched.</li>
                        <li><strong>Custom Themes:</strong> Preserved completely.</li>
                        <li><strong>Configuration:</strong> <code>.env</code> is never overwritten or deleted.</li>
                    </ul>
                    <p style="margin-bottom: 0; font-size: 12px; color: var(--admin-text-muted);">
                        See <a href="<?php echo $base; ?>/admin/tools" style="color: var(--wp-blue);">Tools &amp; Backup Manager</a> to manage manual backups.
                    </p>
                </div>
            </div>

            <!-- Recent Update Logs -->
            <?php if (!empty($logs)): ?>
                <div class="card">
                    <div class="card-header">
                        <h5>Recent Update Activity</h5>
                    </div>
                    <div class="card-body" style="padding: 10px; max-height: 220px; overflow-y: auto; background: var(--admin-code-bg); color: var(--admin-code-text); border-radius: 0 0 6px 6px; font-family: monospace; font-size: 11px;">
                        <?php foreach ($logs as $logLine): ?>
                            <div style="line-height: 1.5;"><?php echo htmlspecialchars($logLine); ?></div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

