<?php

declare(strict_types=1);

namespace FavoriteCMS\Http\Controllers;

use FavoriteCMS\Core\Application;
use FavoriteCMS\Core\Database;
use FavoriteCMS\Core\Request;
use FavoriteCMS\Core\Response;
use FavoriteCMS\Models\Post;
use FavoriteCMS\Models\Page;
use FavoriteCMS\Models\Taxonomy;
use FavoriteCMS\Models\Comment;
use FavoriteCMS\Models\Setting;
use FavoriteCMS\Rendering\Engine;

class FrontendController
{
    /** Upper bound for the posts-per-page reading setting so listings always stay bounded. */
    protected const MAX_POSTS_PER_PAGE = 100;

    protected Application $app;
    protected Engine $engine;

    public function __construct(Application $app)
    {
        $this->app = $app;
        $this->engine = new Engine($app);
    }

    public function home(Request $request): Response
    {
        $frontPageType = Setting::get('reading', 'front_page_type', 'posts');
        $frontPageId   = (int)Setting::get('reading', 'front_page_id', 0);

        if ($frontPageType === 'page' && $frontPageId > 0) {
            $page = Page::find($frontPageId);
            if ($page && $page->status === 'published') {
                return $this->renderPage($page);
            }
        }

        // Show latest posts with pagination
        $perPage     = $this->postsPerPage('home');
        $currentPage = $this->currentPage($request);
        $totalPosts  = (int)(Post::countByStatus()['published'] ?? 0);
        $totalPages  = max(1, (int)ceil($totalPosts / $perPage));
        $offset      = ($currentPage - 1) * $perPage;

        $posts = Post::published($perPage, $offset);
        Post::preloadListData($posts);

        $data = [
            'posts'        => $posts,
            'archiveTitle' => null,
            'isHome'       => true,
            'currentPage'  => $currentPage,
            'totalPages'   => $totalPages,
            'totalPosts'   => $totalPosts,
        ];

        if ($currentPage > 1) {
            $data['metaTitle'] = $this->pagedTitle($this->siteTitle(), $currentPage);
        }

        $html = $this->engine->render('index', $data);

        return Response::make($html, 200);
    }

    public function post(Request $request, string $slug): Response
    {
        $post = Post::findBySlug($slug);
        if (!$post || $post->status !== 'published') {
            return \FavoriteCMS\Services\SeoRedirects::resolve('post', $slug) ?? $this->notFound();
        }

        $seo = $post->getSeoMeta();
        $siteTitle = Setting::get('general', 'site_name', 'Website');
        $sep = Setting::get('seo', 'title_separator', '—');
        $metaTitle = ($seo && $seo->meta_title) ? $seo->meta_title : "{$post->title} {$sep} {$siteTitle}";
        $metaDesc = ($seo && $seo->meta_description) ? $seo->meta_description : $post->excerpt;

        $commentNotice = $request->get('comment') === 'submitted'
            ? 'Thank you! Your comment has been submitted.'
            : null;

        $previousPost = $post->getPrevious();
        $nextPost = $post->getNext();

        $html = $this->engine->render('single', [
            'post'            => $post,
            'previousPost'    => $previousPost,
            'nextPost'        => $nextPost,
            'metaTitle'       => $metaTitle,
            'metaDescription' => $metaDesc,
            'commentNotice'   => $commentNotice,
        ]);

        return Response::make($html, 200);
    }

    public function page(Request $request, string $slug): Response
    {
        $page = Page::findBySlug($slug);
        if (!$page || $page->status !== 'published') {
            return \FavoriteCMS\Services\SeoRedirects::resolve('page', $slug) ?? $this->notFound();
        }

        return $this->renderPage($page);
    }

    protected function renderPage(Page $page): Response
    {
        $seo = $page->getSeoMeta();
        $siteTitle = Setting::get('general', 'site_name', 'Website');
        $sep = Setting::get('seo', 'title_separator', '—');
        $metaTitle = ($seo && $seo->meta_title) ? $seo->meta_title : "{$page->title} {$sep} {$siteTitle}";
        $metaDesc = ($seo && $seo->meta_description) ? $seo->meta_description : '';

        $html = $this->engine->render('page', [
            'page'            => $page,
            'metaTitle'       => $metaTitle,
            'metaDescription' => $metaDesc,
        ]);

        return Response::make($html, 200);
    }

    public function category(Request $request, string $slug): Response
    {
        $cat = Taxonomy::findBySlug($slug, 'category');
        if (!$cat) {
            return $this->notFound();
        }

        return $this->renderTermArchive($request, $cat, 'category', "Category: {$cat->name}");
    }

    public function tag(Request $request, string $slug): Response
    {
        $tag = Taxonomy::findBySlug($slug, 'tag');
        if (!$tag) {
            return $this->notFound();
        }

        return $this->renderTermArchive($request, $tag, 'tag', "Tag: #{$tag->name}");
    }

    /**
     * Render a bounded, paginated archive for a category or tag.
     */
    protected function renderTermArchive(Request $request, Taxonomy $term, string $type, string $archiveTitle): Response
    {
        $perPage     = $this->postsPerPage('archive');
        $currentPage = $this->currentPage($request);
        $totalPosts  = $term->countPublishedPosts();
        $totalPages  = max(1, (int)ceil($totalPosts / $perPage));

        $posts = $term->getPosts($perPage, ($currentPage - 1) * $perPage);
        Post::preloadListData($posts);

        $description = trim((string)($term->description ?? ''));

        $html = $this->engine->render('archive', [
            'posts'              => $posts,
            'archiveTitle'       => $archiveTitle,
            'archiveDescription' => $term->description,
            'archiveType'        => $type,
            'archiveTerm'        => $term,
            'currentPage'        => $currentPage,
            'totalPages'         => $totalPages,
            'totalPosts'         => $totalPosts,
            'metaTitle'          => $this->pagedTitle($archiveTitle . ' ' . $this->titleSeparator() . ' ' . $this->siteTitle(), $currentPage),
            'metaDescription'    => $description !== '' ? $description : null,
        ]);

        return Response::make($html, 200);
    }

    public function search(Request $request): Response
    {
        $rawQuery = $request->get('q', '');
        $query = is_string($rawQuery) ? trim($rawQuery) : '';

        $perPage     = $this->postsPerPage('search');
        $currentPage = $this->currentPage($request);
        $totalPosts  = $query !== '' ? Post::countSearchPublished($query) : 0;
        $totalPages  = max(1, (int)ceil($totalPosts / $perPage));

        $posts = $query !== '' ? Post::searchPublished($query, $perPage, ($currentPage - 1) * $perPage) : [];
        Post::preloadListData($posts);

        $baseTitle = $query !== '' ? 'Search results for "' . $query . '"' : 'Search';

        $html = $this->engine->render('search', [
            'posts'       => $posts,
            'searchQuery' => $query,
            'currentPage' => $currentPage,
            'totalPages'  => $totalPages,
            'totalPosts'  => $totalPosts,
            'metaTitle'   => $this->pagedTitle($baseTitle . ' ' . $this->titleSeparator() . ' ' . $this->siteTitle(), $currentPage),
        ]);

        return Response::make($html, 200);
    }

    public function submitComment(Request $request, ?string $slug = null): Response
    {
        // 1. Resolve target Post
        $post = null;
        if ($slug !== null && trim($slug) !== '') {
            $post = Post::findBySlug(trim($slug));
        }

        if (!$post) {
            $postId = (int)$request->post('post_id', 0);
            if ($postId > 0) {
                $post = Post::find($postId);
            }
        }

        if (!$post) {
            $postSlug = trim((string)$request->post('post_slug', ''));
            if ($postSlug !== '') {
                $post = Post::findBySlug($postSlug);
            }
        }

        if (!$post || $post->status !== 'published') {
            return Response::redirect('/');
        }

        $canonicalUrl = method_exists($post, 'url') ? $post->url() : ('/post/' . $post->slug);

        // 2. Require an authenticated account: logged-out visitors cannot comment
        $currentUser = current_user();
        if (!$currentUser) {
            $_SESSION['comment_error'] = 'Please log in to comment.';
            return Response::redirect($canonicalUrl . '#comments');
        }

        // 3. Strict CSRF validation: a missing session token or submitted token always fails
        $sessionToken = (string)($_SESSION['_token'] ?? '');
        $token = (string)$request->post('_token', '');
        if ($sessionToken === '' || $token === '' || !hash_equals($sessionToken, $token)) {
            $_SESSION['comment_error'] = 'Security verification failed. Please refresh the page and try again.';
            return Response::redirect($canonicalUrl . '#comments');
        }

        // 4. Check Suspended Status
        if (!$currentUser->canSubmitComments()) {
            $_SESSION['comment_error'] = 'Your account is suspended and cannot submit comments.';
            return Response::redirect($canonicalUrl . '#comments');
        }

        // 5. Validate Input Data (identity always comes from the account, never from the request)
        $text = trim((string)$request->post('content', ''));
        if ($text === '') {
            $_SESSION['comment_error'] = 'Please write a comment before submitting.';
            return Response::redirect($canonicalUrl . '#comments');
        }

        $authorName = trim((string)($currentUser->name ?? ''));
        if ($authorName === '') {
            $authorName = (string)$currentUser->username;
        }

        // 6. Insert Comment
        $db = $this->app->make(Database::class);
        $now = date('Y-m-d H:i:s');
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';

        $db->insert('comments', [
            'post_id'      => (int)$post->id,
            'user_id'      => (int)$currentUser->id,
            'author_name'  => $authorName,
            'author_email' => (string)$currentUser->email,
            'author_ip'    => $ip,
            'content'      => $text,
            'status'       => 'approved', // auto-approve default comment for smooth workflow
            'created_at'   => $now,
            'updated_at'   => $now,
        ]);

        $_SESSION['flash_comment_success'] = 'Thank you! Your comment has been submitted.';
        $_SESSION['comment_success']       = 'Thank you! Your comment has been submitted.';

        return Response::redirect($canonicalUrl . '?comment=submitted#comments');
    }

    public function sitemap(Request $request): Response
    {
        return \FavoriteCMS\Services\SeoSitemap::render($request);
    }

    public function robots(Request $request): Response
    {
        $siteUrlSetting = (string)Setting::get('general', 'site_url', '');
        $basePath = $request->basePath();
        if ($siteUrlSetting !== '' && !str_contains($siteUrlSetting, 'favorite-cms.local') && !str_contains($siteUrlSetting, 'localhost')) {
            $baseUrl = rtrim($siteUrlSetting, '/');
            $parsedPath = parse_url($siteUrlSetting, PHP_URL_PATH) ?: '';
            if ($basePath === '' && $parsedPath !== '' && $parsedPath !== '/') {
                $basePath = rtrim($parsedPath, '/');
            }
        } else {
            $server = $request->server();
            $scheme = (!empty($server['HTTPS']) && strtolower((string)$server['HTTPS']) !== 'off') || (($server['SERVER_PORT'] ?? null) === '443') ? 'https' : 'http';
            $host = (string)($server['HTTP_HOST'] ?? $server['SERVER_NAME'] ?? 'localhost');
            $baseUrl = rtrim($scheme . '://' . $host . $basePath, '/');
            if ($baseUrl === '' || $baseUrl === 'http://localhost') {
                $baseUrl = rtrim((string)config('app.url', 'http://favorite-cms.local'), '/');
            }
        }

        $adminPath = $basePath !== '' ? rtrim($basePath, '/') . '/admin/' : '/admin/';
        $default = "User-agent: *\nAllow: /\nDisallow: {$adminPath}\nSitemap: {$baseUrl}/sitemap.xml\n";
        $content = Setting::get('seo', 'robots_txt', $default);
        $content = trim((string)$content);
        if ($content === '') {
            $content = trim($default);
        } elseif (!str_contains($content, 'Sitemap:')) {
            $content .= "\nSitemap: {$baseUrl}/sitemap.xml";
        }
        $content .= "\n";

        $res = Response::make($content, 200);
        $res->header('Content-Type', 'text/plain; charset=utf-8');
        return $res;
    }

    protected function notFound(): Response
    {
        try {
            $html = $this->engine->render('404');
            return Response::make($html, 404);
        } catch (\Throwable) {
            return Response::make('<h1>404 Not Found</h1>', 404);
        }
    }

    protected function postsPerPage(string $context = 'home'): int
    {
        $fallback = (int)Setting::get('reading', 'posts_per_page', 10);
        $override = in_array($context, ['home','archive','search'], true) ? (int)Setting::get('reading', $context . '_posts_per_page', 0) : 0;
        return max(1, min(self::MAX_POSTS_PER_PAGE, $override > 0 ? $override : $fallback));
    }

    protected function currentPage(Request $request): int
    {
        $raw = $request->get('page', 1);
        return is_scalar($raw) ? max(1, (int)$raw) : 1;
    }

    protected function siteTitle(): string
    {
        return (string)Setting::get('general', 'site_name', 'Website');
    }

    protected function titleSeparator(): string
    {
        return (string)Setting::get('seo', 'title_separator', '—');
    }

    /**
     * Append a page indicator to titles of paginated listing pages (page 2 and later).
     */
    protected function pagedTitle(string $title, int $currentPage): string
    {
        return $currentPage > 1 ? $title . ' ' . $this->titleSeparator() . ' Page ' . $currentPage : $title;
    }
}
