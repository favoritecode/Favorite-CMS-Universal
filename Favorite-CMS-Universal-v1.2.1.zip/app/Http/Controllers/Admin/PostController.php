<?php

declare(strict_types=1);

namespace FavoriteCMS\Http\Controllers\Admin;

use FavoriteCMS\Core\Application;
use FavoriteCMS\Core\Database;
use FavoriteCMS\Core\Request;
use FavoriteCMS\Core\Response;
use FavoriteCMS\Models\Post;
use FavoriteCMS\Models\Taxonomy;
use FavoriteCMS\Models\Media;
use FavoriteCMS\Models\User;
use FavoriteCMS\Services\ContentSanitizer;
use FavoriteCMS\Services\ContentRevision;

class PostController
{
    protected Application $app;

    public function __construct(Application $app)
    {
        $this->app = $app;
    }

    public function index(Request $request): Response
    {
        $db = $this->app->make(Database::class);
        $status = $request->get('status', 'all');
        $search = trim((string)$request->get('s', ''));
        $page = max(1, (int)$request->get('p', 1));
        $perPage = 15;
        $offset = ($page - 1) * $perPage;

        $whereClause = "WHERE `type` = 'post'";
        $params = [];

        if ($status !== 'all') {
            $whereClause .= " AND `status` = ?";
            $params[] = $status;
        } else {
            $whereClause .= " AND `status` != 'trash'";
        }

        if ($search !== '') {
            $whereClause .= " AND (`title` LIKE ? OR `content` LIKE ?)";
            $params[] = "%{$search}%";
            $params[] = "%{$search}%";
        }

        // Count total for pagination
        $countSql = "SELECT COUNT(*) as cnt FROM `posts` {$whereClause}";
        $totalRow = $db->selectOne($countSql, $params);
        $totalItems = (int)($totalRow->cnt ?? 0);
        $totalPages = max(1, (int)ceil($totalItems / $perPage));

        // Fetch paginated posts
        $query = "SELECT * FROM `posts` {$whereClause} ORDER BY `created_at` DESC LIMIT ? OFFSET ?";
        $queryParams = array_merge($params, [$perPage, $offset]);
        $posts = array_map(fn($row) => new Post((array)$row), $db->select($query, $queryParams));
        $counts = Post::countByStatus();
        $currentUser = isset($_SESSION['auth_user_id']) ? User::find((int)$_SESSION['auth_user_id']) : null;

        $viewData = [
            'pageTitle'    => 'Posts',
            'activeMenu'   => 'posts',
            'posts'        => $posts,
            'counts'       => $counts,
            'status'       => $status,
            'search'       => $search,
            'currentPage'  => $page,
            'totalPages'   => $totalPages,
            'totalItems'   => $totalItems,
            'currentUser'  => $currentUser,
            'contentView'  => APP_ROOT . '/resources/views/admin/posts/index.php',
        ];

        extract($viewData, EXTR_SKIP);
        ob_start();
        include APP_ROOT . '/resources/views/admin/layout.php';
        return Response::make((string)ob_get_clean(), 200);
    }

    public function create(Request $request): Response
    {
        $currentUser = isset($_SESSION['auth_user_id']) ? User::find((int)$_SESSION['auth_user_id']) : null;
        if (!$currentUser || !$currentUser->canCreatePosts()) {
            $_SESSION['flash_error'] = 'Your account is suspended and cannot create new posts.';
            return Response::redirect('/admin/posts');
        }

        $categories = Taxonomy::getByTaxonomy('category');
        $mediaItems = Media::filtered('all', '', MediaController::PICKER_BATCH);

        $viewData = [
            'pageTitle'    => 'Add New Post',
            'activeMenu'   => 'posts-new',
            'post'         => null,
            'categories'   => $categories,
            'selectedCats' => [],
            'tagsString'   => '',
            'mediaItems'   => $mediaItems,
            'mediaTotal'   => Media::countFiltered(),
            'mediaBatchSize' => MediaController::PICKER_BATCH,
            'seo'          => null,
            'currentUser'  => $currentUser,
            'contentView'  => APP_ROOT . '/resources/views/admin/posts/edit.php',
        ];

        extract($viewData, EXTR_SKIP);
        ob_start();
        include APP_ROOT . '/resources/views/admin/layout.php';
        return Response::make((string)ob_get_clean(), 200);
    }

    public function store(Request $request): Response
    {
        return $this->saveContent($request, false);
    }

    public function update(Request $request): Response
    {
        return $this->saveContent($request, true);
    }

    private function saveContent(Request $request, bool $editing): Response
    {
        $db = $this->app->make(Database::class);
        $sessionBefore = $_SESSION ?? [];
        try {
            return \FavoriteCMS\Services\BuilderContent::run(fn() => $db->transaction(function () use ($request, $editing): Response {
                return $editing ? $this->updateContent($request) : $this->storeContent($request);
            }));
        } catch (\Throwable $error) {
            // Do not acknowledge browser drafts or consume revision tokens after a failed save.
            $_SESSION = $sessionBefore;
            unset($_SESSION['flash_success']);
            $_SESSION['flash_error'] = 'Content could not be saved. Your previous content and drafts have been preserved.';
            error_log('Favorite CMS post save failed: ' . $error->getMessage());
            return Response::redirect($editing ? '/admin/posts/edit?id=' . (int)$request->post('id', 0) : '/admin/posts/new');
        }
    }

    private function storeContent(Request $request): Response
    {
        $currentUser = isset($_SESSION['auth_user_id']) ? User::find((int)$_SESSION['auth_user_id']) : null;
        if (!$currentUser || !$currentUser->canCreatePosts()) {
            $_SESSION['flash_error'] = 'Your account is suspended and cannot create new posts.';
            return Response::redirect('/admin/posts');
        }

        $title       = trim((string)$request->post('title', ''));
        $content     = (string)$request->post('content', '');
        $excerpt     = trim((string)$request->post('excerpt', ''));
        $status      = (string)$request->post('status', 'draft');
        $actionType  = (string)$request->post('action_type', '');
        $slug        = trim((string)$request->post('slug', ''));
        $featImg     = (int)$request->post('featured_image_id', 0);
        $catIds      = (array)$request->post('categories', []);
        $tagsStr     = trim((string)$request->post('tags', ''));

        try {
            $publication=\FavoriteCMS\Services\ScheduledPublication::choice($request,$currentUser,null,'post');
            $status=$publication['status'];
        } catch(\RuntimeException $error) {
            $_SESSION['flash_error']=$error->getMessage();return Response::redirect('/admin/posts/new');
        }

        if ($title === '') {
            $_SESSION['flash_error'] = 'Post title cannot be empty.';
            return Response::redirect('/admin/posts/new');
        }

        $postModel = new Post();
        $finalSlug = $postModel->generateSlug($slug !== '' ? $slug : $title);

        $now = date('Y-m-d H:i:s');

        $authorId = (int)$currentUser->id;
        $content = ContentSanitizer::clean($content, $authorId);

        $db = $this->app->make(Database::class);
        $postId = $db->insert('posts', [
            'title'             => $title,
            'slug'              => $finalSlug,
            'content'           => $content,
            'excerpt'           => $excerpt,
            'status'            => $status,
            'type'              => 'post',
            'author_id'         => $authorId,
            'featured_image_id' => $featImg > 0 ? $featImg : null,
            'published_at'      => $publication['published_at'],
            'scheduled_at'      => $publication['scheduled_at'],
            'scheduled_by'      => $publication['scheduled_by'],
            'created_at'        => $now,
            'updated_at'        => $now,
        ]);

        $post = Post::find($postId);
        \FavoriteCMS\Services\ContentLayout::save($request, 'post', (int)$post->id);
        ContentRevision::record(Post::find((int)$post->id), 'post');
        \FavoriteCMS\Services\ContentWorkspace::capture(Post::find((int)$post->id), 'post');
        \FavoriteCMS\Services\ContentWorkspace::acknowledge($request, 'post');
        $post->syncTaxonomies($catIds, 'category');
        if ($tagsStr !== '') {
            $post->syncTags($tagsStr);
        }

        if ($currentUser->canEditContentSeo($post)) {
            $post->saveSeoMeta([
                'meta_title'       => trim((string)$request->post('meta_title', '')),
                'meta_description' => trim((string)$request->post('meta_description', '')),
                'og_title'         => trim((string)$request->post('og_title', '')),
                'og_description'   => trim((string)$request->post('og_description', '')),
                'og_image_url' => \FavoriteCMS\Services\SeoMetadata::httpUrl((string)$request->post('og_image_url', '')),
                'canonical_url'    => trim((string)$request->post('canonical_url', '')),
                'robots'           => trim((string)$request->post('robots', 'index,follow')),
            ]);
        }

        if ($status === 'pending') {
            $_SESSION['flash_success'] = 'Post submitted successfully and is awaiting review by a moderator.';
        } elseif ($status === 'scheduled') {
            $_SESSION['flash_success'] = 'Scheduled for ' . format_date($publication['scheduled_at'], 'M j, Y g:i a') . ' (' . \FavoriteCMS\Core\DateTime::getTimezone() . ').';
        } elseif ($status === 'published') {
            $_SESSION['flash_success'] = 'Post published successfully!';
        } else {
            $_SESSION['flash_success'] = 'Draft saved successfully.';
        }
        \FavoriteCMS\Services\DraftReceipt::saved($request, $currentUser);
        return Response::redirect('/admin/posts/edit?id=' . $postId);
    }

    public function edit(Request $request): Response
    {
        $currentUser = isset($_SESSION['auth_user_id']) ? User::find((int)$_SESSION['auth_user_id']) : null;
        if (!$currentUser || !$currentUser->isActive()) {
            $_SESSION['flash_error'] = 'Your account is inactive or suspended.';
            return Response::redirect('/admin/posts');
        }

        $id = (int)$request->get('id', 0);
        $post = Post::find($id);
        if (!$post) {
            $_SESSION['flash_error'] = 'Post not found.';
            return Response::redirect('/admin/posts');
        }

        if (!$currentUser->canEditPost($post)) {
            $_SESSION['flash_error'] = 'You do not have permission to edit this post.';
            return Response::redirect('/admin/posts');
        }

        $categories = Taxonomy::getByTaxonomy('category');
        $mediaItems = Media::filtered('all', '', MediaController::PICKER_BATCH);
        $mediaTotal = Media::countFiltered();
        $seo = $post->getSeoMeta();

        $selectedCats = array_map(fn($c) => (int)$c->id, $post->getTaxonomies('category'));
        $tagObjects = $post->getTaxonomies('tag');
        $tagsString = implode(', ', array_map(fn($t) => $t->name, $tagObjects));

        $viewData = [
            'pageTitle'    => 'Edit Post',
            'activeMenu'   => 'posts',
            'post'         => $post,
            'categories'   => $categories,
            'selectedCats' => $selectedCats,
            'tagsString'   => $tagsString,
            'mediaItems'   => $mediaItems,
            'mediaTotal'   => $mediaTotal,
            'mediaBatchSize' => MediaController::PICKER_BATCH,
            'seo'          => $seo,
            'currentUser'  => $currentUser,
            'contentView'  => APP_ROOT . '/resources/views/admin/posts/edit.php',
        ];

        extract($viewData, EXTR_SKIP);
        ob_start();
        include APP_ROOT . '/resources/views/admin/layout.php';
        return Response::make((string)ob_get_clean(), 200);
    }

    private function updateContent(Request $request): Response
    {
        $currentUser = isset($_SESSION['auth_user_id']) ? User::find((int)$_SESSION['auth_user_id']) : null;
        if (!$currentUser || !$currentUser->isActive()) {
            $_SESSION['flash_error'] = 'Your account is inactive or suspended.';
            return Response::redirect('/admin/posts');
        }

        $id = (int)$request->post('id', 0);
        $post = Post::find($id);
        if (!$post) {
            $_SESSION['flash_error'] = 'Post not found.';
            return Response::redirect('/admin/posts');
        }

        if (!$currentUser->canEditPost($post)) {
            $_SESSION['flash_error'] = 'You do not have permission to edit this post.';
            return Response::redirect('/admin/posts');
        }

        $title      = trim((string)$request->post('title', ''));
        $content    = (string)$request->post('content', '');
        $excerpt    = trim((string)$request->post('excerpt', ''));
        $status     = (string)$request->post('status', 'draft');
        $actionType = (string)$request->post('action_type', '');
        $slug       = trim((string)$request->post('slug', ''));
        $featImg    = (int)$request->post('featured_image_id', 0);
        $catIds     = (array)$request->post('categories', []);
        $tagsStr    = trim((string)$request->post('tags', ''));

        try {
            $publication=\FavoriteCMS\Services\ScheduledPublication::choice($request,$currentUser,$post,'post');
            $status=$publication['status'];
        } catch(\RuntimeException $error) {
            $_SESSION['flash_error']=$error->getMessage();return Response::redirect('/admin/posts/edit?id=' . $id);
        }

        if ($title === '') {
            $_SESSION['flash_error'] = 'Post title cannot be empty.';
            return Response::redirect('/admin/posts/edit?id=' . $id);
        }

        $finalSlug = $post->generateSlug($slug !== '' ? $slug : $title, $id);
        $now = date('Y-m-d H:i:s');
        $actor = User::find((int)($_SESSION['auth_user_id'] ?? 0));
        try {
            $content = ContentRevision::clean($content, $post, 'post', $actor, (string)$request->post('_content_revision', ''));
        } catch (\RuntimeException $error) {
            $_SESSION['flash_error'] = $error->getMessage();
            return Response::redirect('/admin/posts/edit?id=' . $id);
        }

        $baseline = (string)$request->post('_workspace_baseline', '');
        if ($baseline !== '' && !hash_equals(\FavoriteCMS\Services\ContentWorkspace::fingerprint($post), $baseline)) {
            $_SESSION['flash_error'] = 'This content changed in another tab or account. Your draft is preserved; reopen the editor before saving.';
            return Response::redirect('/admin/posts/edit?id=' . $id);
        }
        try {
            $layoutBaseline = $request->post('_layout_baseline', null);
            if ($layoutBaseline !== null && $layoutBaseline !== \FavoriteCMS\Services\ContentLayout::get('post', (int)$post->id)) throw new \RuntimeException('The content layout changed in another tab. Reopen the editor before saving.');
            $content = \FavoriteCMS\Services\BuilderContent::content($request, 'post', $post, $content);
        } catch (\RuntimeException $error) {
            $_SESSION['flash_error'] = $error->getMessage();
            return Response::redirect('/admin/posts/edit?id=' . $id);
        }
        \FavoriteCMS\Services\ContentWorkspace::capture($post, 'post');
        $post->update([
            'title'             => $title,
            'slug'              => $finalSlug,
            'content'           => $content,
            'excerpt'           => $excerpt,
            'status'            => $status,
            'featured_image_id' => $featImg > 0 ? $featImg : null,
            'published_at'      => $publication['published_at'],
            'scheduled_at'      => $publication['scheduled_at'],
            'scheduled_by'      => $publication['scheduled_by'],
            'updated_at'        => $now,
        ]);

        \FavoriteCMS\Services\ContentLayout::save($request, 'post', (int)$post->id);
        ContentRevision::record(Post::find((int)$post->id), 'post');
        \FavoriteCMS\Services\ContentWorkspace::capture(Post::find((int)$post->id), 'post');
        \FavoriteCMS\Services\ContentWorkspace::acknowledge($request, 'post');
        $post->syncTaxonomies($catIds, 'category');
        $post->syncTags($tagsStr);

        if ($currentUser->canEditContentSeo($post)) {
            $post->saveSeoMeta([
                'meta_title'       => trim((string)$request->post('meta_title', '')),
                'meta_description' => trim((string)$request->post('meta_description', '')),
                'og_title'         => trim((string)$request->post('og_title', '')),
                'og_description'   => trim((string)$request->post('og_description', '')),
                'og_image_url' => \FavoriteCMS\Services\SeoMetadata::httpUrl((string)$request->post('og_image_url', '')),
                'canonical_url'    => trim((string)$request->post('canonical_url', '')),
                'robots'           => trim((string)$request->post('robots', 'index,follow')),
            ]);
        }

        if ($status === 'pending') {
            $_SESSION['flash_success'] = 'Post submitted successfully and is awaiting review by a moderator.';
        } elseif ($status === 'scheduled') {
            $_SESSION['flash_success'] = 'Scheduled for ' . format_date($publication['scheduled_at'], 'M j, Y g:i a') . ' (' . \FavoriteCMS\Core\DateTime::getTimezone() . ').';
        } elseif ($status === 'published') {
            $_SESSION['flash_success'] = 'Post published successfully!';
        } else {
            $_SESSION['flash_success'] = 'Post updated successfully.';
        }
        \FavoriteCMS\Services\DraftReceipt::saved($request, $currentUser);
        return Response::redirect('/admin/posts/edit?id=' . $id);
    }

    public function approve(Request $request): Response
    {
        $currentUser = isset($_SESSION['auth_user_id']) ? User::find((int)$_SESSION['auth_user_id']) : null;
        if (!$currentUser || !$currentUser->canModeratePosts()) {
            $_SESSION['flash_error'] = 'You do not have permission to approve posts.';
            return Response::redirect('/admin/posts');
        }

        $id = (int)$request->get('id', $request->post('id', 0));
        $post = Post::find($id);
        if (!$post) {
            $_SESSION['flash_error'] = 'Post not found.';
            return Response::redirect('/admin/posts');
        }

        $post->approve();
        $_SESSION['flash_success'] = 'Post "' . htmlspecialchars($post->title, ENT_QUOTES, 'UTF-8') . '" approved and published successfully!';
        return Response::redirect('/admin/posts?status=pending');
    }

    public function reject(Request $request): Response
    {
        $currentUser = isset($_SESSION['auth_user_id']) ? User::find((int)$_SESSION['auth_user_id']) : null;
        if (!$currentUser || !$currentUser->canModeratePosts()) {
            $_SESSION['flash_error'] = 'You do not have permission to reject posts.';
            return Response::redirect('/admin/posts');
        }

        $id = (int)$request->get('id', $request->post('id', 0));
        $post = Post::find($id);
        if (!$post) {
            $_SESSION['flash_error'] = 'Post not found.';
            return Response::redirect('/admin/posts');
        }

        $post->reject();
        $_SESSION['flash_success'] = 'Post "' . htmlspecialchars($post->title, ENT_QUOTES, 'UTF-8') . '" has been rejected.';
        return Response::redirect('/admin/posts?status=pending');
    }

    public function preview(Request $request): Response
    {
        $title   = trim((string)$request->post('title', 'Untitled Preview'));
        $content = (string)$request->post('content', '');
        $featImgId = (int)$request->post('featured_image_id', 0);
        $featImg = $featImgId > 0 ? Media::find($featImgId) : null;

        $authorId = (int)($_SESSION['auth_user_id'] ?? 1);
        $actor = User::find($authorId);
        $originalId = (int)$request->post('id', 0);
        $original = $originalId > 0 ? Post::find($originalId) : null;
        if (!$actor || !$actor->canCreatePosts() || ($original && !$actor->canEditPost($original)) || ($originalId > 0 && !$original)) {
            return Response::make('You do not have permission to preview this content.', 403);
        }
        try {
            $cleanedContent = ContentRevision::clean($content, $original, 'post', $actor, (string)$request->post('_content_revision', ''));
        } catch (\RuntimeException $error) {
            return Response::make(htmlspecialchars($error->getMessage(), ENT_QUOTES, 'UTF-8'), 409);
        }

        $fakePost = new Post([
            '_preview_content_verified' => true,
            '_preview_sidebar_layout' => $request->post('sidebar_layout', 'right'),
            'id'                => 0,
            'title'             => $title ?: 'Preview',
            'slug'              => 'preview',
            'content'           => $cleanedContent,
            'excerpt'           => '',
            'status'            => 'draft',
            'type'              => 'post',
            'author_id'         => $authorId,
            'featured_image_id' => $featImgId > 0 ? $featImgId : null,
            'published_at'      => date('Y-m-d H:i:s'),
            'created_at'        => date('Y-m-d H:i:s'),
        ]);

        $engine = new \FavoriteCMS\Rendering\Engine($this->app);
        $html = $engine->render('single', [
            'post'            => $fakePost,
            'previousPost'    => null,
            'nextPost'        => null,
            'metaTitle'       => 'Preview: ' . $title,
            'metaDescription' => '',
            'commentNotice'   => null,
            'isPreview'       => true,
        ]);

        return Response::make($html, 200);
    }

    public function trash(Request $request): Response
    {
        $currentUser = isset($_SESSION['auth_user_id']) ? User::find((int)$_SESSION['auth_user_id']) : null;
        $id = (int)$request->get('id', $request->post('id', 0));
        $post = Post::find($id);
        if ($post) {
            if (!$currentUser || !$currentUser->canDeletePost($post)) {
                $_SESSION['flash_error'] = 'You do not have permission to modify this post.';
                return Response::redirect('/admin/posts');
            }
            $post->update(['status' => 'trash', 'updated_at' => date('Y-m-d H:i:s')]);
            $_SESSION['flash_success'] = 'Post moved to trash.';
        }
        return Response::redirect('/admin/posts');
    }

    public function restore(Request $request): Response
    {
        $currentUser = isset($_SESSION['auth_user_id']) ? User::find((int)$_SESSION['auth_user_id']) : null;
        $id = (int)$request->get('id', $request->post('id', 0));
        $post = Post::find($id);
        if ($post) {
            if (!$currentUser || !$currentUser->canRestorePost($post)) {
                $_SESSION['flash_error'] = 'You do not have permission to modify this post.';
                return Response::redirect('/admin/posts');
            }
            $post->update(['status' => 'draft', 'updated_at' => date('Y-m-d H:i:s')]);
            $_SESSION['flash_success'] = 'Post restored from trash.';
        }
        return Response::redirect('/admin/posts?status=trash');
    }

    public function delete(Request $request): Response
    {
        $currentUser = isset($_SESSION['auth_user_id']) ? User::find((int)$_SESSION['auth_user_id']) : null;
        $id = (int)$request->get('id', $request->post('id', 0));
        $post = Post::find($id);
        if ($post) {
            if (!$currentUser || !$currentUser->canDeletePost($post)) {
                $_SESSION['flash_error'] = 'You do not have permission to delete this post.';
                return Response::redirect('/admin/posts');
            }
            $db = $this->app->make(Database::class);
            $db->execute("DELETE FROM `post_taxonomies` WHERE `post_id` = ?", [$id]);
            $db->execute("DELETE FROM `seo_meta` WHERE `object_type` = 'post' AND `object_id` = ?", [$id]);
            $db->execute("DELETE FROM `comments` WHERE `post_id` = ?", [$id]);
            $post->delete();
            $_SESSION['flash_success'] = 'Post permanently deleted.';
        }
        return Response::redirect('/admin/posts?status=trash');
    }

    public function quickDraft(Request $request): Response
    {
        $currentUser = isset($_SESSION['auth_user_id']) ? User::find((int)$_SESSION['auth_user_id']) : null;
        if (!$currentUser || !$currentUser->canCreatePosts()) {
            $_SESSION['flash_error'] = 'Your account is suspended and cannot create posts.';
            return Response::redirect('/admin');
        }

        $title = trim((string)$request->post('title', ''));
        $content = (string)$request->post('content', '');

        if ($title !== '') {
            $postModel = new Post();
            $slug = $postModel->generateSlug($title);
            $authorId = (int)$currentUser->id;
            $content = ContentSanitizer::clean($content, $currentUser);

            $db = $this->app->make(Database::class);
            $draftId = $db->insert('posts', [
                'title'      => $title,
                'slug'       => $slug,
                'content'    => $content,
                'status'     => 'draft',
                'type'       => 'post',
                'author_id'  => $authorId,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ]);
            ContentRevision::record(Post::find($draftId), 'post');
            $_SESSION['flash_success'] = 'Draft saved successfully.';
        }

        return Response::redirect('/admin');
    }

    public function bulkAction(Request $request): Response
    {
        $token = (string)$request->post('_token', '');
        if (empty($_SESSION['_token']) || !hash_equals($_SESSION['_token'], $token)) {
            $_SESSION['flash_error'] = 'Security verification failed (invalid CSRF token).';
            return Response::redirect('/admin/posts');
        }

        $currentUser = isset($_SESSION['auth_user_id']) ? User::find((int)$_SESSION['auth_user_id']) : null;
        if (!$currentUser || !$currentUser->isActive()) {
            $_SESSION['flash_error'] = 'Your account is inactive or suspended.';
            return Response::redirect('/admin/posts');
        }

        $action = trim((string)$request->post('bulk_action', ''));
        $rawIds = (array)$request->post('ids', []);
        $ids = array_filter(array_map('intval', $rawIds), fn($id) => $id > 0);
        $redirectStatus = trim((string)$request->post('status', ''));
        $redirectUrl = '/admin/posts' . ($redirectStatus !== '' ? '?status=' . urlencode($redirectStatus) : '');

        if (empty($action) || empty($ids)) {
            $_SESSION['flash_error'] = 'Please select at least one post and a bulk action.';
            return Response::redirect($redirectUrl);
        }

        if (in_array($action, ['approve', 'reject'], true) && !$currentUser->canModeratePosts()) {
            $_SESSION['flash_error'] = 'You do not have permission to approve or reject posts.';
            return Response::redirect($redirectUrl);
        }

        $db = $this->app->make(Database::class);
        $count = 0;
        $deniedCount = 0;

        foreach ($ids as $id) {
            $post = Post::find($id);
            if (!$post) {
                continue;
            }

            if (in_array($action, ['trash', 'delete'], true)) {
                if (!$currentUser->canDeletePost($post)) {
                    $deniedCount++;
                    continue;
                }
            } elseif ($action === 'restore') {
                if (!$currentUser->canRestorePost($post)) {
                    $deniedCount++;
                    continue;
                }
            } elseif (in_array($action, ['approve', 'reject'], true)) {
                if (!$currentUser->canModeratePosts()) {
                    $deniedCount++;
                    continue;
                }
            } else {
                continue;
            }

            switch ($action) {
                case 'trash':
                    $post->update(['status' => 'trash', 'updated_at' => date('Y-m-d H:i:s')]);
                    $count++;
                    break;
                case 'restore':
                    $post->update(['status' => 'draft', 'updated_at' => date('Y-m-d H:i:s')]);
                    $count++;
                    break;
                case 'delete':
                    $db->execute("DELETE FROM `post_taxonomies` WHERE `post_id` = ?", [$id]);
                    $db->execute("DELETE FROM `seo_meta` WHERE `object_type` = 'post' AND `object_id` = ?", [$id]);
                    $db->execute("DELETE FROM `comments` WHERE `post_id` = ?", [$id]);
                    $post->delete();
                    $count++;
                    break;
                case 'approve':
                    $post->approve();
                    $count++;
                    break;
                case 'reject':
                    $post->reject();
                    $count++;
                    break;
            }
        }

        if ($count > 0) {
            $label = match ($action) {
                'trash'   => 'moved to trash',
                'restore' => 'restored from trash',
                'delete'  => 'permanently deleted',
                'approve' => 'approved and published',
                'reject'  => 'rejected',
                default   => 'processed',
            };
            $msg = "{$count} post(s) successfully {$label}.";
            if ($deniedCount > 0) {
                $msg .= " {$deniedCount} post(s) skipped due to insufficient permissions.";
            }
            $_SESSION['flash_success'] = $msg;
        } else {
            if ($deniedCount > 0) {
                $_SESSION['flash_error'] = "No posts were updated. {$deniedCount} post(s) skipped due to insufficient permissions.";
            } else {
                $_SESSION['flash_error'] = 'No posts were updated.';
            }
        }

        return Response::redirect($redirectUrl);
    }
}

