<?php

declare(strict_types=1);

namespace FavoriteCMS\Http\Controllers\Admin;

use FavoriteCMS\Core\Application;
use FavoriteCMS\Core\Database;
use FavoriteCMS\Core\Request;
use FavoriteCMS\Core\Response;
use FavoriteCMS\Models\Page;
use FavoriteCMS\Models\Media;
use FavoriteCMS\Models\User;
use FavoriteCMS\Services\ContentSanitizer;
use FavoriteCMS\Services\ContentRevision;

class PageController
{
    protected Application $app;

    /** Rows shown per Pages list page. */
    protected const PER_PAGE = 12;

    public function __construct(Application $app)
    {
        $this->app = $app;
    }

    public function index(Request $request): Response
    {
        $db = $this->app->make(Database::class);
        $status = $request->get('status', 'all');
        $search = trim((string)$request->get('s', ''));

        $where = "WHERE 1=1";
        $params = [];

        if ($status !== 'all') {
            $where .= " AND `status` = ?";
            $params[] = $status;
        } else {
            $where .= " AND `status` != 'trash'";
        }

        if ($search !== '') {
            $where .= " AND (`title` LIKE ? OR `content` LIKE ?)";
            $params[] = "%{$search}%";
            $params[] = "%{$search}%";
        }

        // Bounded page of rows; the total is counted separately
        $totalItems  = (int)($db->selectOne("SELECT COUNT(*) AS cnt FROM `pages` {$where}", $params)->cnt ?? 0);
        $totalPages  = max(1, (int)ceil($totalItems / self::PER_PAGE));
        $currentPage = min(max(1, (int)$request->get('p', 1)), $totalPages);

        $query = "SELECT * FROM `pages` {$where} ORDER BY `menu_order` ASC, `created_at` DESC, `id` DESC LIMIT ? OFFSET ?";
        $rows = $db->select($query, array_merge($params, [self::PER_PAGE, ($currentPage - 1) * self::PER_PAGE]));
        $pages = array_map(fn($row) => new Page((array)$row), $rows);
        $counts = Page::countByStatus();

        $viewData = [
            'pageTitle'   => 'Pages',
            'activeMenu'  => 'pages',
            'pages'       => $pages,
            'counts'      => $counts,
            'status'      => $status,
            'search'      => $search,
            'currentPage' => $currentPage,
            'totalPages'  => $totalPages,
            'totalItems'  => $totalItems,
            'contentView' => APP_ROOT . '/resources/views/admin/pages/index.php',
        ];

        extract($viewData, EXTR_SKIP);
        ob_start();
        include APP_ROOT . '/resources/views/admin/layout.php';
        return Response::make((string)ob_get_clean(), 200);
    }

    public function create(Request $request): Response
    {
        $allPages = Page::summaries();
        $mediaItems = Media::filtered('all', '', MediaController::PICKER_BATCH);

        $viewData = [
            'pageTitle'   => 'Add New Page',
            'activeMenu'  => 'pages-new',
            'page'        => null,
            'allPages'    => $allPages,
            'mediaItems'  => $mediaItems,
            'mediaTotal'  => Media::countFiltered(),
            'mediaBatchSize' => MediaController::PICKER_BATCH,
            'selectedMedia'  => null,
            'seo'         => null,
            'contentView' => APP_ROOT . '/resources/views/admin/pages/edit.php',
        ];

        extract($viewData, EXTR_SKIP);
        ob_start();
        include APP_ROOT . '/resources/views/admin/layout.php';
        return Response::make((string)ob_get_clean(), 200);
    }

    public function store(Request $request): Response
    {
        return $this->saveContent($request, false);
    }

    public function update(Request $request): Response
    {
        return $this->saveContent($request, true);
    }

    private function saveContent(Request $request, bool $editing): Response
    {
        $db = $this->app->make(Database::class);
        $sessionBefore = $_SESSION ?? [];
        try {
            return \FavoriteCMS\Services\BuilderContent::run(fn() => $db->transaction(function () use ($request, $editing): Response {
                return $editing ? $this->updateContent($request) : $this->storeContent($request);
            }));
        } catch (\Throwable $error) {
            // Do not acknowledge browser drafts or consume revision tokens after a failed save.
            $_SESSION = $sessionBefore;
            unset($_SESSION['flash_success']);
            $_SESSION['flash_error'] = 'Content could not be saved. Your previous content and drafts have been preserved.';
            error_log('Favorite CMS page save failed: ' . $error->getMessage());
            return Response::redirect($editing ? '/admin/pages/edit?id=' . (int)$request->post('id', 0) : '/admin/pages/new');
        }
    }

    private function storeContent(Request $request): Response
    {
        $title    = trim((string)$request->post('title', ''));
        $content  = (string)$request->post('content', '');
        $status   = (string)$request->post('status', 'draft');
        $slug     = trim((string)$request->post('slug', ''));
        $parentId = (int)$request->post('parent_id', 0);
        if (!Page::isValidParent($parentId, 0)) {
            $_SESSION['flash_error'] = 'Choose an existing parent page that does not create a cycle.';
            return Response::redirect('/admin/pages/new');
        }
        $featImg  = (int)$request->post('featured_image_id', 0);
        $order    = (int)$request->post('menu_order', 0);

        try {
            $publication=\FavoriteCMS\Services\ScheduledPublication::choice($request,User::find((int)($_SESSION['auth_user_id'] ?? 0)),null,'page');
            $status=$publication['status'];
        } catch(\RuntimeException $error) {
            $_SESSION['flash_error']=$error->getMessage();return Response::redirect('/admin/pages/new');
        }

        if ($title === '') {
            $_SESSION['flash_error'] = 'Page title cannot be empty.';
            return Response::redirect('/admin/pages/new');
        }

        $pageModel = new Page();
        $finalSlug = $pageModel->generateSlug($slug !== '' ? $slug : $title);
        $authorId = (int)($_SESSION['auth_user_id'] ?? 1);
        $content  = ContentSanitizer::clean($content, $authorId);

        $db = $this->app->make(Database::class);
        $pageId = $db->insert('pages', [
            'title'             => $title,
            'slug'              => $finalSlug,
            'content'           => $content,
            'status'            => $status,
            'published_at'      => $publication['published_at'],
            'scheduled_at'      => $publication['scheduled_at'],
            'scheduled_by'      => $publication['scheduled_by'],
            'parent_id'         => $parentId > 0 ? $parentId : null,
            'featured_image_id' => $featImg > 0 ? $featImg : null,
            'author_id'         => $authorId,
            'menu_order'        => $order,
            'created_at'        => date('Y-m-d H:i:s'),
            'updated_at'        => date('Y-m-d H:i:s'),
        ]);

        $page = Page::find($pageId);
        \FavoriteCMS\Services\ContentLayout::save($request, 'page', (int)$page->id);
        ContentRevision::record(Page::find((int)$page->id), 'page');
        \FavoriteCMS\Services\ContentWorkspace::capture(Page::find((int)$page->id), 'page');
        \FavoriteCMS\Services\ContentWorkspace::acknowledge($request, 'page');
        $page->saveSeoMeta([
            'meta_title'       => trim((string)$request->post('meta_title', '')),
            'meta_description' => trim((string)$request->post('meta_description', '')),
            'og_title'         => trim((string)$request->post('og_title', '')),
            'og_description'   => trim((string)$request->post('og_description', '')),
                'og_image_url' => \FavoriteCMS\Services\SeoMetadata::httpUrl((string)$request->post('og_image_url', '')),
            'canonical_url'    => trim((string)$request->post('canonical_url', '')),
            'robots'           => trim((string)$request->post('robots', 'index,follow')),
        ]);

        $_SESSION['flash_success'] = 'Page created successfully.';
        return Response::redirect('/admin/pages/edit?id=' . $pageId);
    }

    public function edit(Request $request): Response
    {
        $id = (int)$request->get('id', 0);
        $page = Page::find($id);
        if (!$page) {
            $_SESSION['flash_error'] = 'Page not found.';
            return Response::redirect('/admin/pages');
        }

        $allPages = Page::summaries();
        $mediaItems = Media::filtered('all', '', MediaController::PICKER_BATCH);
        $seo = $page->getSeoMeta();

        $viewData = [
            'pageTitle'   => 'Edit Page',
            'activeMenu'  => 'pages',
            'page'        => $page,
            'allPages'    => $allPages,
            'mediaItems'  => $mediaItems,
            'mediaTotal'  => Media::countFiltered(),
            'mediaBatchSize' => MediaController::PICKER_BATCH,
            'selectedMedia'  => !empty($page->featured_image_id) ? Media::find((int)$page->featured_image_id) : null,
            'seo'         => $seo,
            'contentView' => APP_ROOT . '/resources/views/admin/pages/edit.php',
        ];

        extract($viewData, EXTR_SKIP);
        ob_start();
        include APP_ROOT . '/resources/views/admin/layout.php';
        return Response::make((string)ob_get_clean(), 200);
    }

    private function updateContent(Request $request): Response
    {
        $id = (int)$request->post('id', 0);
        $page = Page::find($id);
        if (!$page) {
            $_SESSION['flash_error'] = 'Page not found.';
            return Response::redirect('/admin/pages');
        }

        $title    = trim((string)$request->post('title', ''));
        $content  = (string)$request->post('content', '');
        $status   = (string)$request->post('status', 'draft');
        $slug     = trim((string)$request->post('slug', ''));
        $parentId = (int)$request->post('parent_id', 0);
        if (!Page::isValidParent($parentId, $id)) {
            $_SESSION['flash_error'] = 'Choose an existing parent page that does not create a cycle.';
            return Response::redirect('/admin/pages/edit?id=' . $id);
        }
        $featImg  = (int)$request->post('featured_image_id', 0);
        $order    = (int)$request->post('menu_order', 0);

        try {
            $publication=\FavoriteCMS\Services\ScheduledPublication::choice($request,User::find((int)($_SESSION['auth_user_id'] ?? 0)),$page,'page');
            $status=$publication['status'];
        } catch(\RuntimeException $error) {
            $_SESSION['flash_error']=$error->getMessage();return Response::redirect('/admin/pages/edit?id=' . $id);
        }

        if ($title === '') {
            $_SESSION['flash_error'] = 'Page title cannot be empty.';
            return Response::redirect('/admin/pages/edit?id=' . $id);
        }

        $finalSlug = $slug !== '' ? str_slug($slug) : $page->slug;
        $actor = User::find((int)($_SESSION['auth_user_id'] ?? 0));
        try {
            $content = ContentRevision::clean($content, $page, 'page', $actor, (string)$request->post('_content_revision', ''));
        } catch (\RuntimeException $error) {
            $_SESSION['flash_error'] = $error->getMessage();
            return Response::redirect('/admin/pages/edit?id=' . $id);
        }

        $baseline = (string)$request->post('_workspace_baseline', '');
        if ($baseline !== '' && !hash_equals(\FavoriteCMS\Services\ContentWorkspace::fingerprint($page), $baseline)) {
            $_SESSION['flash_error'] = 'This content changed in another tab or account. Your draft is preserved; reopen the editor before saving.';
            return Response::redirect('/admin/pages/edit?id=' . $id);
        }
        try {
            $layoutBaseline = $request->post('_layout_baseline', null);
            if ($layoutBaseline !== null && $layoutBaseline !== \FavoriteCMS\Services\ContentLayout::get('page', (int)$page->id)) throw new \RuntimeException('The content layout changed in another tab. Reopen the editor before saving.');
            $content = \FavoriteCMS\Services\BuilderContent::content($request, 'page', $page, $content);
        } catch (\RuntimeException $error) {
            $_SESSION['flash_error'] = $error->getMessage();
            return Response::redirect('/admin/pages/edit?id=' . $id);
        }
        \FavoriteCMS\Services\ContentWorkspace::capture($page, 'page');
        $page->update([
            'title'             => $title,
            'slug'              => $finalSlug,
            'content'           => $content,
            'status'            => $status,
            'published_at'      => $publication['published_at'],
            'scheduled_at'      => $publication['scheduled_at'],
            'scheduled_by'      => $publication['scheduled_by'],
            'parent_id'         => $parentId > 0 && $parentId !== $id ? $parentId : null,
            'featured_image_id' => $featImg > 0 ? $featImg : null,
            'menu_order'        => $order,
            'updated_at'        => date('Y-m-d H:i:s'),
        ]);

        \FavoriteCMS\Services\ContentLayout::save($request, 'page', (int)$page->id);
        ContentRevision::record(Page::find((int)$page->id), 'page');
        \FavoriteCMS\Services\ContentWorkspace::capture(Page::find((int)$page->id), 'page');
        \FavoriteCMS\Services\ContentWorkspace::acknowledge($request, 'page');
        $page->saveSeoMeta([
            'meta_title'       => trim((string)$request->post('meta_title', '')),
            'meta_description' => trim((string)$request->post('meta_description', '')),
            'og_title'         => trim((string)$request->post('og_title', '')),
            'og_description'   => trim((string)$request->post('og_description', '')),
                'og_image_url' => \FavoriteCMS\Services\SeoMetadata::httpUrl((string)$request->post('og_image_url', '')),
            'canonical_url'    => trim((string)$request->post('canonical_url', '')),
            'robots'           => trim((string)$request->post('robots', 'index,follow')),
        ]);

        $_SESSION['flash_success'] = 'Page updated successfully.';
        return Response::redirect('/admin/pages/edit?id=' . $id);
    }

    public function preview(Request $request): Response
    {
        $title   = trim((string)$request->post('title', 'Untitled Preview'));
        $content = (string)$request->post('content', '');
        $featImgId = (int)$request->post('featured_image_id', 0);

        $authorId = (int)($_SESSION['auth_user_id'] ?? 1);
        $actor = User::find($authorId);
        $originalId = (int)$request->post('id', 0);
        $original = $originalId > 0 ? Page::find($originalId) : null;
        if (!$actor || !$actor->canManagePages() || ($originalId > 0 && !$original)) {
            return Response::make('You do not have permission to preview this content.', 403);
        }
        try {
            $cleanedContent = ContentRevision::clean($content, $original, 'page', $actor, (string)$request->post('_content_revision', ''));
        } catch (\RuntimeException $error) {
            return Response::make(htmlspecialchars($error->getMessage(), ENT_QUOTES, 'UTF-8'), 409);
        }

        $fakePage = new Page([
            '_preview_content_verified' => true,
            '_preview_sidebar_layout' => $request->post('sidebar_layout', 'right'),
            'id'                => 0,
            'title'             => $title ?: 'Preview',
            'slug'              => 'preview',
            'content'           => $cleanedContent,
            'status'            => 'draft',
            'author_id'         => $authorId,
            'featured_image_id' => $featImgId > 0 ? $featImgId : null,
            'created_at'        => date('Y-m-d H:i:s'),
        ]);

        $engine = new \FavoriteCMS\Rendering\Engine($this->app);
        $html = $engine->render('page', [
            'page'            => $fakePage,
            'metaTitle'       => 'Preview: ' . $title,
            'metaDescription' => '',
            'isPreview'       => true,
        ]);

        return Response::make($html, 200);
    }

    public function trash(Request $request): Response
    {
        $id = (int)$request->get('id', 0);
        $page = Page::find($id);
        if ($page) {
            $page->update(['status' => 'trash', 'updated_at' => date('Y-m-d H:i:s')]);
            $_SESSION['flash_success'] = 'Page moved to trash.';
        }
        return Response::redirect('/admin/pages');
    }

    public function restore(Request $request): Response
    {
        $id = (int)$request->get('id', 0);
        $page = Page::find($id);
        if ($page) {
            $page->update(['status' => 'draft', 'updated_at' => date('Y-m-d H:i:s')]);
            $_SESSION['flash_success'] = 'Page restored from trash.';
        }
        return Response::redirect('/admin/pages?status=trash');
    }

    public function delete(Request $request): Response
    {
        $id = (int)$request->get('id', 0);
        $page = Page::find($id);
        if ($page) {
            $db = $this->app->make(Database::class);
            $db->execute("DELETE FROM `seo_meta` WHERE `object_type` = 'page' AND `object_id` = ?", [$id]);
            $page->delete();
            $_SESSION['flash_success'] = 'Page permanently deleted.';
        }
        return Response::redirect('/admin/pages?status=trash');
    }

    public function bulkAction(Request $request): Response
    {
        $token = (string)$request->post('_token', '');
        if (empty($_SESSION['_token']) || !hash_equals($_SESSION['_token'], $token)) {
            $_SESSION['flash_error'] = 'Security verification failed (invalid CSRF token).';
            return Response::redirect('/admin/pages');
        }

        $currentUser = isset($_SESSION['auth_user_id']) ? User::find((int)$_SESSION['auth_user_id']) : null;
        if (!$currentUser || !$currentUser->isActive()) {
            $_SESSION['flash_error'] = 'Your account is inactive or suspended.';
            return Response::redirect('/admin/pages');
        }

        if (!$currentUser->canManagePages()) {
            $_SESSION['flash_error'] = 'You do not have permission to manage pages.';
            return Response::redirect('/admin/pages');
        }

        $action = trim((string)$request->post('bulk_action', ''));
        $rawIds = (array)$request->post('ids', []);
        $ids = array_filter(array_map('intval', $rawIds), fn($id) => $id > 0);
        $redirectStatus = trim((string)$request->post('status', ''));
        $redirectUrl = '/admin/pages' . ($redirectStatus !== '' ? '?status=' . urlencode($redirectStatus) : '');

        if (empty($action) || empty($ids)) {
            $_SESSION['flash_error'] = 'Please select at least one page and a bulk action.';
            return Response::redirect($redirectUrl);
        }

        $db = $this->app->make(Database::class);
        $count = 0;

        foreach ($ids as $id) {
            $page = Page::find($id);
            if (!$page) {
                continue;
            }

            switch ($action) {
                case 'trash':
                    $page->update(['status' => 'trash', 'updated_at' => date('Y-m-d H:i:s')]);
                    $count++;
                    break;
                case 'restore':
                    $page->update(['status' => 'draft', 'updated_at' => date('Y-m-d H:i:s')]);
                    $count++;
                    break;
                case 'delete':
                    $db->execute("DELETE FROM `seo_meta` WHERE `object_type` = 'page' AND `object_id` = ?", [$id]);
                    $page->delete();
                    $count++;
                    break;
            }
        }

        if ($count > 0) {
            $label = match ($action) {
                'trash'   => 'moved to trash',
                'restore' => 'restored from trash',
                'delete'  => 'permanently deleted',
                default   => 'processed',
            };
            $_SESSION['flash_success'] = "{$count} page(s) successfully {$label}.";
        } else {
            $_SESSION['flash_error'] = 'No pages were updated.';
        }

        return Response::redirect($redirectUrl);
    }
}

