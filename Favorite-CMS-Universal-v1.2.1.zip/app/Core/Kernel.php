<?php

declare(strict_types=1);

namespace FavoriteCMS\Core;

use FavoriteCMS\Installer\InstallerController;
use FavoriteCMS\Installer\InstallerSession;
use FavoriteCMS\Installer\UrlResolver;
use FavoriteCMS\Plugins\PluginManager;
use FavoriteCMS\Http\Controllers\FrontendController;
use FavoriteCMS\Http\Controllers\Admin\DashboardController;
use FavoriteCMS\Http\Controllers\Admin\PostController;
use FavoriteCMS\Http\Controllers\Admin\PageController;
use FavoriteCMS\Http\Controllers\Admin\TaxonomyController;
use FavoriteCMS\Http\Controllers\Admin\MediaController;
use FavoriteCMS\Http\Controllers\Admin\CommentController;
use FavoriteCMS\Http\Controllers\Admin\UserController;
use FavoriteCMS\Http\Controllers\Admin\MenuController;
use FavoriteCMS\Http\Controllers\Admin\ThemeController;
use FavoriteCMS\Http\Controllers\Admin\WidgetController;
use FavoriteCMS\Http\Controllers\Admin\CustomizeController;
use FavoriteCMS\Http\Controllers\Admin\PluginController;
use FavoriteCMS\Http\Controllers\Admin\SettingController;
use FavoriteCMS\Http\Controllers\Admin\SeoController;
use FavoriteCMS\Http\Controllers\Admin\ToolController;
use FavoriteCMS\Http\Controllers\Admin\UpdateController;
use FavoriteCMS\Models\Setting;
use FavoriteCMS\Models\User;
use FavoriteCMS\Rendering\Engine;
use FavoriteCMS\Services\AuthRateLimiter;
use FavoriteCMS\Services\EmailVerificationService;
use FavoriteCMS\Services\PasswordHasher;
use FavoriteCMS\Services\PasswordResetService;
use FavoriteCMS\Services\Update\MaintenanceMode;

class Kernel
{
    protected Application $app;

    public function __construct(Application $app)
    {
        $this->app = $app;
    }

    public function handle(Request $request): Response
    {
        try {
            $urls = new UrlResolver();
            $request->setBasePath($urls->basePath($request));
            $GLOBALS['favorite_cms_base_path'] = $request->basePath();
            $path = $request->path();
            $GLOBALS['favorite_cms_repair_mode'] = false;

            // Private gateway endpoints retain their own OAuth/HMAC protocol and no CMS session dependency.
            $centralServer = APP_ROOT . '/favorite-server-license/bootstrap.php';
            if (is_file($centralServer)) {
                require_once $centralServer;
                // Optional private server package supplies its own fixed handlers.
                // No files need to be installed inside the CMS public directory.
                if (class_exists(\FavoriteCentral\Endpoints::class)) {
                    $centralResponse = \FavoriteCentral\Endpoints::response($request, $this->app);
                    if ($centralResponse !== null) return $centralResponse;
                }
                try {
                    $oauthResponse = \FavoriteCentral\OAuthGateway::response($request, APP_ROOT);
                    if ($oauthResponse !== null) return $oauthResponse;
                } catch (\Throwable $e) {
                    if (str_starts_with($path, '/favorite-central-oauth')) return Response::json(['error'=>'gateway_unavailable'],503);
                }
            }

            (new InstallerSession($urls))->start($request);

            // 1. Installer: If not installed, handle installation
            if (!$this->app->isInstalled()) {
                $installer = new InstallerController($this->app);
                return $installer->handle($request);
            }

            // If already installed and visiting /install, redirect to /
            if ($path === '/install') {
                return Response::redirect('/');
            }

            // Maintenance mode check
            $maintenance = new MaintenanceMode();
            if ($maintenance->isActive() && !$maintenance->isBypassed($request)) {
                return $maintenance->renderResponse($request);
            }

            // Dynamic ownership proof fallback for hosts that deny direct .well-known files.
            // It exposes only the short-lived public registration challenge, never stored credentials.
            if ($path === '/favorite-central-verify' && $request->isGet()) {
                $file = APP_ROOT . '/public/.well-known/favorite-central.json';
                $body = is_file($file) ? @file_get_contents($file) : false;
                if (is_string($body) && strlen($body) <= 4096 && is_array(json_decode($body, true))) {
                    return Response::make($body, 200, [
                        'Content-Type' => 'application/json; charset=utf-8',
                        'Cache-Control' => 'no-store, private',
                        'X-Robots-Tag' => 'noindex, nofollow',
                    ]);
                }
                return Response::json(['error' => 'verification_not_pending'], 404)->header('Cache-Control', 'no-store');
            }

            // Public challenge for an owner-initiated Central identity check. No credentials exposed.
            // Supports both /.well-known/favorite-central-live and non-dotfile /favorite-central-live fallback.
            if (($path === '/.well-known/favorite-central-live' || $path === '/favorite-central-live') && $request->isGet()) {
                $challenge=(string)$request->get('challenge','');
                $proof=(new \FavoriteCMS\Central\Client())->identityChallenge($challenge);
                return Response::json($proof,isset($proof['error'])?400:200)
                    ->header('Cache-Control','no-store, private')
                    ->header('X-Robots-Tag','noindex, nofollow');
            }

            $repairRoute = \FavoriteCMS\Central\Bridge::recoveryAllowed($path);
            if ($repairRoute && ($path === '/admin/connection-status' || $request->get('safe_repair') === '1')) $_SESSION['_favorite_safe_repair'] = true;
            if ($repairRoute && $request->get('safe_repair') === '0') unset($_SESSION['_favorite_safe_repair']);
            $repairOnly = $repairRoute && (!empty($_SESSION['_favorite_safe_repair']) || $maintenance->isActive() || \FavoriteCMS\Central\Bridge::repairMode());
            $GLOBALS['favorite_cms_repair_mode'] = $repairOnly;
            \FavoriteCMS\Central\Bridge::boot(\FavoriteCMS\Security\CoreIntegrity::report(APP_ROOT)['status'] === 'verified');
            // Keep normal authentication, two-step, role and CSRF checks, but do not
            // boot themes/plugins, publication jobs or content redirects during repair.
            if ($repairOnly) return $this->dispatch($request);
            $centralRestriction = \FavoriteCMS\Central\Bridge::policyResponse($request);
            if ($centralRestriction !== null) return $centralRestriction;

            // Run due publications before plugins resolve linked content routes.
            \FavoriteCMS\Services\ScheduledPublication::runDue($this->app->make(Database::class));

            \FavoriteCMS\Services\NotificationService::boot();

            // Boot active plugins safely
            (new PluginManager($this->app))->bootActivePlugins();

            // Load active theme functions.php if available
            try {
                $activeTheme = (new \FavoriteCMS\Themes\ThemeManager($this->app))->getActiveTheme();
                $themeFunctions = APP_ROOT . '/themes/' . $activeTheme . '/functions.php';
                if (file_exists($themeFunctions)) {
                    include_once $themeFunctions;
                }
            } catch (\Throwable) {}

            // Boot widget registry and allow plugins/themes to register widgets via widgets_init
            \FavoriteCMS\Widgets\WidgetRegistry::getInstance()->ensureBooted();

            // Fire core init hook
            \FavoriteCMS\Core\Hook::doAction('init', $this->app);

            // PHP leaves form arrays empty for JSON as well as oversized forms.
            $postLimit = \FavoriteCMS\Services\UploadCapabilityService::parseByteString((string)ini_get('post_max_size'));
            $contentType = strtolower(trim(explode(';', (string)($_SERVER['CONTENT_TYPE'] ?? ''))[0]));
            if (
                strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET')) === 'POST' &&
                in_array($contentType, ['application/x-www-form-urlencoded', 'multipart/form-data'], true) &&
                $postLimit > 0 && (int)($_SERVER['CONTENT_LENGTH'] ?? 0) > $postLimit &&
                empty($_POST) && empty($_FILES)
            ) {
                $postMax = ini_get('post_max_size') ?: 'unknown';
                $length = (int)($_SERVER['CONTENT_LENGTH'] ?? 0);
                $formattedLen = \FavoriteCMS\Services\UploadCapabilityService::formatBytes($length);
                return Response::make(
                    "<!DOCTYPE html><html><head><title>413 Payload Too Large</title><style>body{font-family:sans-serif;padding:40px;line-height:1.6;max-width:600px;margin:auto;color:#334155;}h1{color:#e11d48;}</style></head><body><h1>413 Payload Too Large</h1><p>The submitted request payload ({$formattedLen}) exceeded the server's <code>post_max_size</code> setting ({$postMax}).</p><p>To prevent data loss, the request was rejected rather than silently truncated. Please increase <code>post_max_size</code> in PHP or submit smaller content.</p><p><a href='javascript:history.back()'>&larr; Go Back</a></p></body></html>",
                    413
                );
            }

            // 2. Dispatch request
            $specificRedirect = \FavoriteCMS\Services\UrlRedirects::resolve($request);
            if ($specificRedirect) return $specificRedirect;
            $response = $this->dispatch($request);
            if ($response->getStatusCode() === 404 && !str_contains(strtolower((string)$response->getHeader('Content-Type')), 'json')) {
                return \FavoriteCMS\Services\NotFoundRedirect::resolve($request) ?? $response;
            }
            return $response;

        } catch (\Throwable $e) {
            return $this->handleException($e);
        }
    }

    protected function dispatch(Request $request): Response
    {
        $path   = $request->path();
        $method = $request->method();

        if (!empty($_SESSION['auth_user_id'])) {
            $sessionUser = User::find((int)$_SESSION['auth_user_id']);
            if ($sessionUser && (int)($_SESSION['auth_version'] ?? 0) !== (int)($sessionUser->auth_version ?? 0)) {
                $_SESSION = [];
                (new InstallerSession(new UrlResolver()))->regenerate();
                return Response::redirect('/admin/login');
            }
            if ($sessionUser) {
                $factor=\FavoriteCMS\Services\AccountSecurity::state((int)$sessionUser->id);
                if ($factor->method!=='off' && ($_SESSION['auth_two_step']??'')!==($sessionUser->id.':'.$factor->revision)) {
                    $_SESSION=[];(new InstallerSession(new UrlResolver()))->regenerate();
                    $_SESSION['login_flash']='Please sign in and verify your two-step code.';
                    return Response::redirect('/admin/login');
                }
            }

        }

        if (in_array($path, ['/forgot-password', '/reset-password'], true)) {
            return $this->passwordRecovery($request, $path === '/reset-password');
        }

        // Immediately invalidate session if authenticated user was banned
        if (!empty($_SESSION['auth_user_id'])) {
            $checkUser = User::find((int)$_SESSION['auth_user_id']);
            if (!$checkUser || $checkUser->isBanned()) {
                unset(
                    $_SESSION['auth_user_id'],
                    $_SESSION['auth_user_name'],
                    $_SESSION['auth_user_email'],
                    $_SESSION['auth_user_role']
                );
                $_SESSION['login_flash'] = 'Your account has been permanently banned.';
                $_SESSION['flash_error'] = 'Your account has been permanently banned.';
                if (str_starts_with($path, '/admin')) {
                    return Response::redirect('/admin/login');
                }
            }
        }

        // ---------------------------------------------------------------------
        // Public Auth & Registration Routes
        // ---------------------------------------------------------------------
        if ($path === '/register' || $path === '/signup' || $path === '/admin/register') {
            return $method === 'POST' ? $this->processRegister($request) : $this->showRegister($request);
        }

        if ($path === '/login') {
            $loginRedirect = SafeRedirect::localPath($request->get('redirect'));
            return Response::redirect('/admin/login' . ($loginRedirect !== null ? '?redirect=' . rawurlencode($loginRedirect) : ''));
        }

        if ($path === '/verify-email') {
            return $this->handleEmailVerification($request);
        }

        if ($path === '/resend-verification') {
            return $method === 'POST' ? $this->processResendVerification($request) : $this->showResendVerification($request);
        }

        // ---------------------------------------------------------------------
        // Plugin Admin API Routes
        // ---------------------------------------------------------------------
        // Dispatch plugin /admin/api/* routes through the shared Router before
        // the Core admin-page dispatcher. Plugin API controllers enforce their
        // own authentication, capability checks, and API-specific CSRF rules.
        if (str_starts_with($path, '/admin/api/')) {
            $dynamicResp = \FavoriteCMS\Core\Router::dispatch($request);
            if ($dynamicResp !== null) {
                return $dynamicResp;
            }
        }

        // ---------------------------------------------------------------------
        // Admin Routes
        // ---------------------------------------------------------------------
        if (str_starts_with($path, '/admin')) {
            return $this->dispatchAdmin($request, $path, $method);
        }

        // ---------------------------------------------------------------------
        // Static Theme & Plugin Assets
        // ---------------------------------------------------------------------
        if (str_starts_with($path, '/themes/') || str_starts_with($path, '/plugins/')) {
            $assetResponse = $this->serveStaticAsset($path);
            if ($assetResponse !== null) {
                return $assetResponse;
            }
        }

        // ---------------------------------------------------------------------
        // Dynamic Plugin Frontend Routes
        // ---------------------------------------------------------------------
        $dynamicResp = \FavoriteCMS\Core\Router::dispatch($request);
        if ($dynamicResp !== null) {
            return $dynamicResp;
        }

        // ---------------------------------------------------------------------
        // Public Frontend Routes
        // ---------------------------------------------------------------------
        if (preg_match('#^/media-download/([1-9][0-9]*)$#D', $path, $download)) {
            return \FavoriteCMS\Services\DownloadMedia::response($request, (int)$download[1]);
        }
        $fileAlias = \FavoriteCMS\Services\MediaFileUrls::response($request);
        if ($fileAlias !== null) return $fileAlias;
        $frontend = new FrontendController($this->app);

        if ($path === '/' || $path === '') {
            return $frontend->home($request);
        }

        if ($path === '/logout') {
            return $this->processLogout($request);
        }

        if ($path === '/search') {
            return $frontend->search($request);
        }

        // Comment submission endpoints
        if (preg_match('#^/post/([a-zA-Z0-9_\-]+)/comment/?$#', $path, $m) && $method === 'POST') {
            return $frontend->submitComment($request, $m[1]);
        }

        if (($path === '/comment/submit' || $path === '/comments/submit') && $method === 'POST') {
            return $frontend->submitComment($request);
        }

        if (preg_match('#^/sitemap-([0-9]+)\.xml$#', $path, $sitemap)) return \FavoriteCMS\Services\SeoSitemap::render($request, (int)$sitemap[1]);

        if ($path === '/sitemap.xml') {
            return $frontend->sitemap($request);
        }

        if ($path === '/robots.txt') {
            return $frontend->robots($request);
        }

        // Legacy /post/{slug} URLs remain supported even when the canonical base is /blog/.
        if (preg_match('#^/post/([a-zA-Z0-9_\-]+)/?$#', $path, $m)) {
            if ($method === 'POST') {
                return $frontend->submitComment($request, $m[1]);
            }
            $post = \FavoriteCMS\Models\Post::findBySlug($m[1]);
            if ($post && $post->status === 'published' && $post->url() !== $path) {
                return Response::redirect($post->url(), 301);
            }
            return $frontend->post($request, $m[1]);
        }

        // Alternate configurable /blog/{slug} post permalink.
        if (preg_match('#^/blog/([a-zA-Z0-9_\-]+)/?$#', $path, $m)) {
            if ($method === 'POST') {
                return $frontend->submitComment($request, $m[1]);
            }
            $post = \FavoriteCMS\Models\Post::findBySlug($m[1]);
            if ($post && $post->status === 'published') {
                if ($post->url() !== $path) { return Response::redirect($post->url(), 301); }
                return $frontend->post($request, $m[1]);
            }
        }

        // Legacy /page/{slug} URLs remain supported when root-level pages are enabled.
        if (preg_match('#^/page/([a-zA-Z0-9_\-]+)/?$#', $path, $m)) {
            $page = \FavoriteCMS\Models\Page::findBySlug($m[1]);
            if ($page && $page->status === 'published' && $page->url() !== $path) {
                return Response::redirect($page->url(), 301);
            }
            return $frontend->page($request, $m[1]);
        }

        // /category/{slug}
        if (preg_match('#^/category/([a-zA-Z0-9_\-]+)$#', $path, $m)) {
            return $frontend->category($request, $m[1]);
        }

        // /tag/{slug}
        if (preg_match('#^/tag/([a-zA-Z0-9_\-]+)$#', $path, $m)) {
            return $frontend->tag($request, $m[1]);
        }

        // Fallback check for single page by direct slug e.g. /about
        $pageSlug = trim($path, '/');
        if (!empty($pageSlug)) {
            $rootPage = \FavoriteCMS\Models\Page::findBySlug($pageSlug);
            if ($rootPage && $rootPage->status === 'published' && $rootPage->url() !== $path) {
                return Response::redirect($rootPage->url(), 301);
            }
            $resp = $frontend->page($request, $pageSlug);
            if (in_array($resp->getStatusCode(), [200,301], true)) {
                return $resp;
            }
        }

        return $this->notFound($request);
    }

    protected function dispatchAdmin(Request $request, string $path, string $method): Response
    {
        // Auth routes
        if ($path === '/admin/two-step') return $this->twoStep($request);
        if ($path === '/admin/login') {
            return $method === 'POST' ? $this->processLogin($request) : $this->showLogin($request);
        }

        if ($path === '/admin/logout') {
            return $this->processLogout($request);
        }

        // Require authentication for all other /admin routes
        if (empty($_SESSION['auth_user_id'])) {
            return Response::redirect('/admin/login');
        }

        $currentUser = User::find((int)$_SESSION['auth_user_id']);
        if (!$currentUser || $currentUser->isBanned()) {
            unset(
                $_SESSION['auth_user_id'],
                $_SESSION['auth_user_name'],
                $_SESSION['auth_user_email'],
                $_SESSION['auth_user_role']
            );
            $_SESSION['login_flash'] = 'Your account has been permanently banned.';
            $_SESSION['flash_error'] = 'Your account has been permanently banned.';
            return Response::redirect('/admin/login');
        }

        // Always synchronize session role with database authoritative state
        $_SESSION['auth_user_role'] = $currentUser->getPrimaryRoleSlug();

        // Enforce suspended restrictions: suspended users can view profile/settings and logout
        if ($currentUser->isSuspended()) {
            $allowedForSuspended = [
                '/admin',
                '/admin/',
                '/admin/users/profile',
                '/admin/users/profile/update',
                '/admin/account/security',
                '/admin/logout',
            ];
            if (!in_array($path, $allowedForSuspended, true)) {
                if ($path === '/admin/posts' && $method === 'GET') {
                    // Allowed read-only posts index
                } else {
                    $_SESSION['flash_error'] = 'Your account is currently suspended. Protected site activities, content creation, and modifications are restricted.';
                    return Response::redirect('/admin/users/profile');
                }
            }
        }

        // Module 1: Dashboard
        $mutation = preg_match('#^/admin/(posts|pages|taxonomies|media|comments|users|menus|themes|widgets|customize|plugins|settings|seo|tools|updates)/(?:.*/)?(store|update|approve|reject|trash|restore|delete|bulk|quick-draft|unapprove|spam|create|add|location|activate|deactivate|upload|upload-ajax|reorder|move|duplicate|reset|save|delete-account|apply|rollback|cancel-upload|process|blogger|verify|test-email)$#', $path) === 1
            || in_array($path, ['/admin/users/status', '/admin/users/role', '/admin/users/verify', '/admin/settings/test-email', '/admin/settings/test-smtp', '/admin/settings/google-auth', '/admin/settings/google-disconnect', '/admin/settings/test-google'], true);
        if ($mutation && $method !== 'POST') {
            return Response::make('Method not allowed.', 405)->header('Allow', 'POST');
        }
        if ($method !== 'GET' && $method !== 'HEAD') {
            $submitted = $request->post('_token', '');
            if ($submitted === '') {
                $rawBody = (string)file_get_contents('php://input');
                $json = json_decode($rawBody, true);
                if (is_array($json) && !empty($json['_token'])) {
                    $submitted = (string)$json['_token'];
                }
            }
            $stored = $_SESSION['_token'] ?? '';
            if (!is_string($submitted) || !is_string($stored) || $stored === '' || !hash_equals($stored, $submitted)) {
                return Response::make('Invalid security token.', 403);
            }
        }

        if ($path === '/admin/connection-status' || (!empty($GLOBALS['favorite_cms_repair_mode']) && in_array($path, ['/admin', '/admin/', '/admin/tools'], true))) {
            return \FavoriteCMS\Central\Recovery::response($request);
        }

        if ($path === '/admin/account/security') return (new \FavoriteCMS\Http\Controllers\Admin\AccountSecurityController())->handle($request);

        // Private content workspace: central authentication, suspension and CSRF checks apply first.
        if (preg_match('#^/admin/(posts|pages)/(autosave|workspace|snapshot)$#', $path, $workspace)) {
            return (new \FavoriteCMS\Http\Controllers\Admin\ContentWorkspaceController())->handle($request, $workspace[1] === 'posts' ? 'post' : 'page', $workspace[2], $method);
        }

        // Admin Appearance Toggle (Authenticated user, CSRF validated, self-preference only)
        if ($path === '/admin/appearance/toggle') {
            if ($method !== 'POST') {
                return Response::make('Method not allowed.', 405)->header('Allow', 'POST');
            }
            if (!$currentUser || !$currentUser->isActive()) {
                return Response::make('Unauthorized.', 403);
            }
            $rawTheme = (string)$request->post('theme', '');
            if ($rawTheme === '') {
                $json = json_decode((string)file_get_contents('php://input'), true);
                if (is_array($json) && !empty($json['theme'])) {
                    $rawTheme = (string)$json['theme'];
                }
            }
            $theme = $rawTheme === 'dark' ? 'dark' : 'light';
            \FavoriteCMS\Models\Setting::set('admin_appearance', 'user_' . $currentUser->id, $theme, 'string');
            $_SESSION['admin_theme'] = $theme;
            return Response::json(['success' => true, 'theme' => $theme]);
        }

        if ($path === '/admin/dashboard/preferences') {
            if($method!=='POST')return Response::make('Method not allowed.',405)->header('Allow','POST');
            return (new DashboardController($this->app))->index($request);
        }

        if ($path === '/admin' || $path === '/admin/') {
            return (new DashboardController($this->app))->index($request);
        }

        // Page Builder registered endpoints use the authenticated admin router.
        // Dispatch only this plugin namespace here, after existing session, role,
        // suspension and CSRF guards. The normal CMS admin-page fallback stays intact
        // when Favorite Page Builder is disabled or no route is registered.
        if (str_starts_with($path, '/admin/page/favorite-page-builder-')) {
            $builderResponse = \FavoriteCMS\Core\Router::dispatch($request);
            if ($builderResponse !== null) {
                return $builderResponse;
            }
        }

        // Dynamic Plugin Admin Pages: /admin/page/{slug}
        if (preg_match('#^/admin/page/([a-zA-Z0-9_\-]+)$#', $path, $m)) {
            return $this->dispatchPluginAdminPage($request, $m[1]);
        }

        // Module 2: Posts
        if (str_starts_with($path, '/admin/posts')) {
            if ($path !== '/admin/posts' && !$currentUser->canCreatePosts() && !$currentUser->canUpdatePosts() && !$currentUser->canModeratePosts()) {
                return Response::make('<h1>403 Access Denied</h1><p>You do not have permission to access posts.</p>', 403);
            }

            $ctrl = new PostController($this->app);
            return match ($path) {
                '/admin/posts'             => $ctrl->index($request),
                '/admin/posts/new'         => $ctrl->create($request),
                '/admin/posts/store'       => $ctrl->store($request),
                '/admin/posts/edit'        => $ctrl->edit($request),
                '/admin/posts/update'      => $ctrl->update($request),
                '/admin/posts/preview'     => $ctrl->preview($request),
                '/admin/posts/approve'     => $ctrl->approve($request),
                '/admin/posts/reject'      => $ctrl->reject($request),
                '/admin/posts/trash'       => $ctrl->trash($request),
                '/admin/posts/restore'     => $ctrl->restore($request),
                '/admin/posts/delete'      => $ctrl->delete($request),
                '/admin/posts/bulk'        => $ctrl->bulkAction($request),
                '/admin/posts/quick-draft' => $ctrl->quickDraft($request),
                default                    => Response::redirect('/admin/posts'),
            };
        }

        // Module 3: Pages
        if (str_starts_with($path, '/admin/pages')) {
            if (!$currentUser->canManagePages()) {
                return Response::make('<h1>403 Access Denied</h1><p>You do not have permission to manage pages.</p>', 403);
            }

            $ctrl = new PageController($this->app);
            return match ($path) {
                '/admin/pages'         => $ctrl->index($request),
                '/admin/pages/new'     => $ctrl->create($request),
                '/admin/pages/store'   => $ctrl->store($request),
                '/admin/pages/edit'    => $ctrl->edit($request),
                '/admin/pages/update'  => $ctrl->update($request),
                '/admin/pages/preview' => $ctrl->preview($request),
                '/admin/pages/trash'   => $ctrl->trash($request),
                '/admin/pages/restore' => $ctrl->restore($request),
                '/admin/pages/delete'  => $ctrl->delete($request),
                '/admin/pages/bulk'    => $ctrl->bulkAction($request),
                default                => Response::redirect('/admin/pages'),
            };
        }

        // Module 4: Taxonomies
        if (str_starts_with($path, '/admin/taxonomies')) {
            if (!$currentUser->canManageTaxonomies()) {
                return Response::make('<h1>403 Access Denied</h1><p>You do not have permission to manage categories and tags.</p>', 403);
            }

            $ctrl = new TaxonomyController($this->app);
            return match ($path) {
                '/admin/taxonomies/categories' => $ctrl->categories($request),
                '/admin/taxonomies/tags'       => $ctrl->tags($request),
                '/admin/taxonomies/store'      => $ctrl->store($request),
                '/admin/taxonomies/delete'     => $ctrl->delete($request),
                default                        => Response::redirect('/admin/taxonomies/categories'),
            };
        }

        // Module 5: Media
        if (str_starts_with($path, '/admin/media')) {
            $manageRoutes = ['/admin/media', '/admin/media/update', '/admin/media/delete', '/admin/media/bulk-delete'];
            if (in_array($path, $manageRoutes, true)) {
                if (!$currentUser->canManageMedia()) {
                    return Response::make('<h1>403 Access Denied</h1><p>You do not have permission to manage media.</p>', 403);
                }
            } else {
                if (!$currentUser->canUploadMedia()) {
                    return Response::make('<h1>403 Access Denied</h1><p>You do not have permission to access media.</p>', 403);
                }
            }

            $ctrl = new MediaController($this->app);
            return match ($path) {
                '/admin/media'              => $ctrl->index($request),
                '/admin/media/upload'       => $ctrl->upload($request),
                '/admin/media/upload-ajax'  => $ctrl->uploadAjax($request),
                '/admin/media/import-url'   => $ctrl->importUrl($request),
                '/admin/media/capabilities' => $ctrl->capabilities($request),
                '/admin/media/library'      => $ctrl->library($request),
                '/admin/media/update'       => $ctrl->update($request),
                '/admin/media/delete'       => $ctrl->delete($request),
                '/admin/media/bulk-delete'  => $ctrl->bulkDelete($request),
                default                     => Response::redirect('/admin/media'),
            };
        }

        // Module 6: Comments
        if (str_starts_with($path, '/admin/comments')) {
            if (!$currentUser->canModerateComments()) {
                return Response::make('<h1>403 Access Denied</h1><p>You do not have permission to moderate comments.</p>', 403);
            }

            $ctrl = new CommentController($this->app);
            return match ($path) {
                '/admin/comments'           => $ctrl->index($request),
                '/admin/comments/approve'   => $ctrl->approve($request),
                '/admin/comments/unapprove' => $ctrl->unapprove($request),
                '/admin/comments/spam'      => $ctrl->spam($request),
                '/admin/comments/trash'     => $ctrl->trash($request),
                '/admin/comments/delete'    => $ctrl->delete($request),
                '/admin/comments/bulk'      => $ctrl->bulkAction($request),
                default                     => Response::redirect('/admin/comments'),
            };
        }

        // Module 7: Users & Profile
        if (str_starts_with($path, '/admin/users')) {
            $ctrl = new UserController($this->app);
            if ($path === '/admin/users/profile' || $path === '/admin/users/profile/update') {
                return $method === 'POST' ? $ctrl->updateProfile($request) : $ctrl->profile($request);
            }
            if ($path === '/admin/users/profile/delete-account' && $method === 'POST') {
                return $ctrl->deleteOwnAccount($request);
            }
            if ($path === '/admin/users/profile/recover-super-admin' && $method === 'POST') {
                return $ctrl->recoverSuperAdmin($request);
            }

            if (!$currentUser->canManageUsers()) {
                return Response::make('<h1>403 Access Denied</h1><p>You do not have permission to manage users.</p>', 403);
            }

            return match ($path) {
                '/admin/users'                => $ctrl->index($request),
                '/admin/users/new'            => $ctrl->create($request),
                '/admin/users/store'          => $ctrl->store($request),
                '/admin/users/edit'           => $ctrl->edit($request),
                '/admin/users/update'         => $ctrl->update($request),
                '/admin/users/status'         => $ctrl->changeStatus($request),
                '/admin/users/role'           => $ctrl->changeRole($request),
                '/admin/users/verify'         => $ctrl->verifyUser($request),
                '/admin/users/delete'         => $ctrl->delete($request),
                '/admin/users/bulk'           => $ctrl->bulkAction($request),
                default                       => Response::redirect('/admin/users'),
            };
        }

        // Admin-only modules protection (Themes, Plugins, Widgets, Customize, Settings, Tools)
        $isAdmin = $currentUser->hasRole('admin') || $currentUser->hasRole('super-admin') || $currentUser->isSuperAdmin();

        // Module 8: Menus
        if (str_starts_with($path, '/admin/menus')) {
            if (!$currentUser->canManageMenus()) {
                return Response::make('<h1>403 Access Denied</h1><p>You do not have permission to manage menus.</p>', 403);
            }
            $ctrl = new MenuController($this->app);
            return match ($path) {
                '/admin/menus'             => $ctrl->index($request),
                '/admin/menus/create'      => $ctrl->createMenu($request),
                '/admin/menus/item/add'    => $ctrl->addItem($request),
                '/admin/menus/item/delete' => $ctrl->deleteItem($request),
                '/admin/menus/location'    => $ctrl->saveLocation($request),
                '/admin/menus/save'        => $ctrl->saveMenu($request),
                '/admin/menus/delete'      => $ctrl->deleteMenu($request),
                default                    => Response::redirect('/admin/menus'),
            };
        }

        // Module 9: Themes
        if (str_starts_with($path, '/admin/themes')) {
            if (!$isAdmin) {
                return Response::make('<h1>403 Access Denied</h1><p>You do not have permission to manage themes.</p>', 403);
            }
            $ctrl = new ThemeController($this->app);
            return match ($path) {
                '/admin/themes'          => $ctrl->index($request),
                '/admin/themes/activate' => $ctrl->activate($request),
                '/admin/themes/upload'   => $ctrl->upload($request),
                '/admin/themes/delete'   => $ctrl->delete($request),
                default                  => Response::redirect('/admin/themes'),
            };
        }

        // Module 9b: Widgets
        if (str_starts_with($path, '/admin/widgets')) {
            if (!$isAdmin) {
                return Response::make('<h1>403 Access Denied</h1><p>You do not have permission to manage widgets.</p>', 403);
            }
            $ctrl = new WidgetController($this->app);
            return match ($path) {
                '/admin/widgets'           => $ctrl->index($request),
                '/admin/widgets/store'     => $ctrl->store($request),
                '/admin/widgets/update'    => $ctrl->update($request),
                '/admin/widgets/delete'    => $ctrl->delete($request),
                '/admin/widgets/reorder'   => $ctrl->reorder($request),
                '/admin/widgets/move'      => $ctrl->move($request),
                '/admin/widgets/duplicate' => $ctrl->duplicate($request),
                '/admin/widgets/reset'     => $ctrl->reset($request),
                default                    => Response::redirect('/admin/widgets'),
            };
        }

        // Module 9c: Customize Theme
        if (str_starts_with($path, '/admin/customize')) {
            if (!$isAdmin) {
                return Response::make('<h1>403 Access Denied</h1><p>You do not have permission to customize themes.</p>', 403);
            }
            $ctrl = new CustomizeController($this->app);
            return match ($path) {
                '/admin/customize'                  => $ctrl->index($request),
                '/admin/customize/preview'           => $method === 'POST' ? $ctrl->preview($request) : Response::make('Method not allowed.', 405)->header('Allow','POST'),
                '/admin/customize/save'             => $ctrl->save($request),
                '/admin/customize/sections/reorder' => $ctrl->reorderSections($request),
                '/admin/customize/reset'            => $ctrl->reset($request),
                '/admin/customize/templates'        => $ctrl->getTemplates($request),
                '/admin/customize/templates/save'   => $ctrl->saveTemplate($request),
                '/admin/customize/templates/delete' => $ctrl->deleteTemplate($request),
                default                             => Response::redirect('/admin/customize'),
            };
        }

        // Module 10: Plugins
        if (str_starts_with($path, '/admin/plugins')) {
            if (!$currentUser->canManagePlugins()) {
                return Response::make('<h1>403 Access Denied</h1><p>You do not have permission to manage plugins.</p>', 403);
            }
            $ctrl = new PluginController($this->app);
            return match ($path) {
                '/admin/plugins'            => $ctrl->index($request),
                '/admin/plugins/activate'   => $ctrl->activate($request),
                '/admin/plugins/deactivate' => $ctrl->deactivate($request),
                '/admin/plugins/upload'     => $ctrl->upload($request),
                '/admin/plugins/delete'     => $ctrl->delete($request),
                '/admin/plugins/bulk'       => $ctrl->bulkAction($request),
                default                     => Response::redirect('/admin/plugins'),
            };
        }

        // Module 11: Settings
        if (str_starts_with($path, '/admin/settings')) {
            if (!$currentUser->canManageSettings()) {
                return Response::make('<h1>403 Access Denied</h1><p>You do not have permission to access settings.</p>', 403);
            }
            if (preg_match('#^/admin/settings/redirects(?:/(new|edit|store|update|toggle|delete))?$#D', $path, $redirectRoute)) {
                return (new \FavoriteCMS\Http\Controllers\Admin\RedirectController($this->app))->handle($request, $redirectRoute[1] ?? 'index');
            }
            $ctrl = new SettingController($this->app);
            return match ($path) {
                '/admin/settings'                   => $ctrl->index($request),
                '/admin/settings/seo'                => (new SeoController($this->app))->index($request),
                '/admin/settings/seo/update'         => (new SeoController($this->app))->update($request),
                '/admin/settings/seo/export'         => (new SeoController($this->app))->export($request),
                '/admin/settings/seo/preview'        => (new SeoController($this->app))->preview($request),
                '/admin/settings/seo/apply'          => (new SeoController($this->app))->apply($request),
                '/admin/settings/update'            => $ctrl->update($request),
                '/admin/settings/test-email'        => $ctrl->sendTestEmail($request),
                '/admin/settings/test-smtp'         => $ctrl->testSmtpConnection($request),
                '/admin/settings/google-auth'        => $ctrl->startGoogleAuth($request),
                '/admin/settings/google-callback'    => $ctrl->handleGoogleCallback($request),
                '/admin/settings/google-disconnect'  => $ctrl->disconnectGoogle($request),
                '/admin/settings/test-google'        => $ctrl->testGoogleConnection($request),
                default                             => Response::redirect('/admin/settings'),
            };
        }

        // Module 12: SEO
        if (str_starts_with($path, '/admin/seo')) {
            if (!$isAdmin) {
                return Response::make('<h1>403 Access Denied</h1><p>You do not have permission to access SEO settings.</p>', 403);
            }
            $ctrl = new SeoController($this->app);
            return match ($path) {
                '/admin/seo'        => $ctrl->index($request),
                '/admin/seo/update' => $ctrl->update($request),
                '/admin/seo/export' => $ctrl->export($request),
                '/admin/seo/preview' => $ctrl->preview($request),
                '/admin/seo/apply' => $ctrl->apply($request),
                default             => Response::redirect('/admin/seo'),
            };
        }

        // Module 13: Tools & Backup
        if (str_starts_with($path, '/admin/tools')) {
            if (!$isAdmin) {
                return Response::make('<h1>403 Access Denied</h1><p>You do not have permission to access tools.</p>', 403);
            }
            $ctrl = new ToolController($this->app);
            return match ($path) {
                '/admin/tools'                 => $ctrl->index($request),
                '/admin/tools/export'          => $ctrl->export($request),
                '/admin/tools/backup/create'   => $ctrl->createBackup($request),
                '/admin/tools/backup/download'        => $ctrl->downloadBackup($request),
                '/admin/tools/backup/delete'          => $ctrl->deleteBackup($request),
                '/admin/tools/restore'                => $ctrl->restoreBackup($request),
                '/admin/tools/import'                 => $ctrl->importIndex($request),
                '/admin/tools/import/preview'         => $ctrl->importPreview($request),
                '/admin/tools/import/process'         => $ctrl->importProcess($request),
                '/admin/tools/import/blogger/preview' => $ctrl->bloggerImportPreview($request),
                '/admin/tools/import/blogger'         => $ctrl->bloggerImportProcess($request),
                default                               => Response::redirect('/admin/tools'),
            };
        }

        // Module 14: Core Updates
        if (str_starts_with($path, '/admin/updates')) {
            if (!$isAdmin) {
                return Response::make('<h1>403 Access Denied</h1><p>You do not have permission to access Core Updates.</p>', 403);
            }
            $ctrl = new UpdateController($this->app);
            return match ($path) {
                '/admin/updates'               => $ctrl->index($request),
                '/admin/updates/check'         => $ctrl->check($request),
                '/admin/updates/upload'        => $ctrl->upload($request),
                '/admin/updates/apply'         => $ctrl->apply($request),
                '/admin/updates/apply-extension' => $ctrl->applyExtension($request),
                '/admin/updates/cancel-upload' => $ctrl->cancelUpload($request),
                '/admin/updates/status'        => $ctrl->status($request),
                default                        => Response::redirect('/admin/updates'),
            };
        }

        return Response::redirect('/admin');
    }

    // -------------------------------------------------------------------------
    // Login & Logout
    // -------------------------------------------------------------------------
    protected function showLogin(Request $request, string $error = ''): Response
    {
        // Explicit, validated return targets always take precedence. On the initial
        // GET only, recover the originating same-site page when a login-required
        // tool (or an ordinary login link) did not include ?redirect=.
        // The login form already carries this path through password/remembered
        // login and two-step verification; no persistent session redirect needed.
        $redirect = $this->requestedRedirect($request);
        if ($redirect === null && $request->isGet()) {
            $redirect = $this->sameSiteLoginReferrer($request);
        }

        if (!empty($_SESSION['auth_user_id'])) {
            return Response::redirect($redirect ?? '/admin');
        }

        $siteName = 'Favorite CMS';
        try {
            $db = $this->app->make(Database::class);
            $setting = $db->selectOne("SELECT value FROM `settings` WHERE `group_name` = 'general' AND `setting_key` = 'site_name' LIMIT 1");
            if ($setting && $setting->value) {
                $siteName = $setting->value;
            }
        } catch (\Throwable) {
        }

        if (empty($_SESSION['_token'])) {
            $_SESSION['_token'] = bin2hex(random_bytes(32));
        }

        $flashMsg = $_SESSION['login_flash'] ?? '';
        unset($_SESSION['login_flash']);

        $registrationEnabled = true;
        try {
            $registrationEnabled = (bool)(int)Setting::get('general', 'allow_registration', 1);
        } catch (\Throwable) {
        }

        return $this->renderAuthPage($request, 'login', [
            'siteName'            => (string)$siteName,
            'token'               => (string)$_SESSION['_token'],
            'redirect'            => $redirect,
            'error'               => $error,
            'flash'               => $error === '' ? (string)$flashMsg : '',
            'oldLogin'            => trim((string)$request->post('login', '')),
            'registrationEnabled' => $registrationEnabled,
            'rememberedUser' => \FavoriteCMS\Services\RememberedLogin::candidate(),
            'rememberEnabled' => \FavoriteCMS\Services\RememberedLogin::enabled(),
        ]);
    }

    /**
     * Render an authentication screen inside the shared auth layout.
     * Links and form actions are built from the request base path so subdirectory installs work.
     */
    protected function renderAuthPage(Request $request, string $view, array $data = [], int $status = 200): Response
    {
        ['e' => $e, 'field' => $field] = require APP_ROOT . '/resources/views/partials/standalone/view-helpers.php';
        $basePath = $request->basePath();
        $url = static fn (string $path): string => $basePath . $path;
        $siteName = (string)($data['siteName'] ?? 'Favorite CMS');
        $pageTitle = $siteName;

        extract($data, EXTR_SKIP);

        ob_start();
        include APP_ROOT . '/resources/views/auth/' . $view . '.php';
        $content = (string)ob_get_clean();

        ob_start();
        include APP_ROOT . '/resources/views/auth/layout.php';

        return Response::make((string)ob_get_clean(), $status)->header('Cache-Control','no-store')->header('Referrer-Policy','no-referrer');
    }

    protected function processLogin(Request $request): Response
    {
        if(!empty($_SESSION['auth_user_id']))return $this->showLogin($request);
        $token  = (string)$request->post('_token', '');
        $stored = (string)($_SESSION['_token'] ?? '');
        if ($stored === '' || !hash_equals($stored, $token)) {
            return $this->showLogin($request, 'Invalid security token. Please try again.');
        }

        unset($_SESSION['remember_choice'],$_SESSION['remember_expires']);
        if($request->post('action')==='remembered'){
            $limiter=new \FavoriteCMS\Services\AuthRateLimiter();
            if(!$limiter->allow('remember-login:'.(string)($request->server()['REMOTE_ADDR']??'unknown'),30))return $this->showLogin($request,'Too many attempts. Please try again later.');
            $remembered=\FavoriteCMS\Services\RememberedLogin::candidate(true);
            if(!$remembered)return $this->showLogin($request,'This saved sign-in has expired. Please enter your password.');
            return $this->startVerifiedPasswordLogin($request,$remembered);
        }
        \FavoriteCMS\Services\RememberedLogin::forget();

        $login    = trim((string)$request->post('login', ''));
        $password = (string)$request->post('password', '');

        if ($login === '' || $password === '') {
            return $this->showLogin($request, 'Please enter both your username/email and password.');
        }

        $limiter = new \FavoriteCMS\Services\AuthRateLimiter();
        $ip = (string)($request->server()['REMOTE_ADDR'] ?? 'unknown');
        if (!$limiter->allow('login-ip:' . $ip, 300)
            || !$limiter->allow('login:' . $ip . ':' . strtolower($login), 30)) {
            return $this->showLogin($request, 'Too many login attempts. Please try again in 15 minutes.');
        }

        try {
            $db = $this->app->make(Database::class);
            $user = $db->selectOne(
                "SELECT * FROM `users` WHERE `email` = ? OR `username` = ? LIMIT 1",
                [$login, $login]
            );

            if (!$user || !PasswordHasher::verify($password, (string)$user->password)) {
                if ($user) \FavoriteCMS\Services\NotificationService::security((int)$user->id,'Failed sign-in attempt','A sign-in attempt with an incorrect password was detected. IP: '.$ip,true);
                return $this->showLogin($request, 'Error: The password you entered for the username or email is incorrect.');
            }

            // Transparent rehash if needed (e.g. migrating from bcrypt to argon2id or upgraded cost)
            if (PasswordHasher::needsRehash((string)$user->password)) {
                $newHash = PasswordHasher::hash($password);
                $db->execute("UPDATE `users` SET `password` = ?, `updated_at` = ? WHERE `id` = ?", [
                    $newHash,
                    date('Y-m-d H:i:s'),
                    $user->id,
                ]);
                $user->password = $newHash;
            }

            if ($user->status === 'banned') {
                return $this->showLogin($request, 'Your account has been permanently banned.');
            }

            if ($user->status === 'inactive') {
                return $this->showLogin($request, 'Your account is currently inactive.');
            }

            if (EmailVerificationService::isRequired() && empty($user->email_verified_at)) {
                return $this->showLogin($request, 'Your email address is not yet verified. Please check your inbox or resend verification link.');
            }

            $_SESSION['remember_choice']=$request->post('remember')==='1'&&\FavoriteCMS\Services\RememberedLogin::enabled();
            return $this->startVerifiedPasswordLogin($request,User::find((int)$user->id));

        } catch (\Throwable $e) {
            return $this->showLogin($request, 'Authentication is temporarily unavailable. Please try again later.');
        }
    }

    /** Reused only after password validation or one-use remembered credential validation. */
    protected function startVerifiedPasswordLogin(Request $request, User $user): Response
    {
        $security=\FavoriteCMS\Services\AccountSecurity::state((int)$user->id);
        if($security->method!=='off'){
            (new InstallerSession(new UrlResolver()))->regenerate();
            $_SESSION['two_step_redirect']=$this->requestedRedirect($request);
            try{\FavoriteCMS\Services\AccountSecurity::begin($user);}catch(\Throwable $error){$_SESSION['two_step_error']=$error->getMessage();}
            return Response::redirect('/admin/two-step')->header('Cache-Control','no-store');
        }
        return $this->completeLogin($request,$user);
    }

    protected function completeLogin(Request $request, object $user, ?string $returnPath=null): Response
    {
        $factor=\FavoriteCMS\Services\AccountSecurity::state((int)$user->id);
        $proof=$_SESSION['two_step']??[];
        if($factor->method!=='off' && (empty($proof['verified']) || ($proof['purpose']??'')!=='login' || (int)($proof['user_id']??0)!==(int)$user->id || (int)($proof['revision']??-1)!==(int)$factor->revision))return Response::redirect('/admin/login');
        if($factor->method!=='off')$_SESSION['auth_two_step']=$user->id.':'.$factor->revision;else unset($_SESSION['auth_two_step']);
        $db=$this->app->make(Database::class);
        unset($_SESSION['two_step'],$_SESSION['two_step_redirect'],$_SESSION['two_step_error']);
            (new InstallerSession(new UrlResolver()))->regenerate();
            $_SESSION['auth_version']    = (int)($user->auth_version ?? 0);
            $_SESSION['auth_user_id']    = $user->id;
            $_SESSION['auth_user_name']  = $user->name ?? $user->username ?? 'User';
            $_SESSION['auth_user_email'] = $user->email;

            $userModel = User::find((int)$user->id);
            if ($userModel) {
                $_SESSION['auth_user_role'] = $userModel->getPrimaryRoleSlug();
            }

            // Restore authoritative admin appearance preference
            $savedAdminTheme = \FavoriteCMS\Models\Setting::get('admin_appearance', 'user_' . $user->id, null);
            if ($savedAdminTheme === 'dark' || $savedAdminTheme === 'light') {
                $_SESSION['admin_theme'] = $savedAdminTheme;
            }

            \FavoriteCMS\Services\NotificationService::security((int)$user->id,'Successful sign-in','IP: '.(string)($request->server()['REMOTE_ADDR']??'unknown'));
            $db->execute("UPDATE `users` SET `last_login_at` = ? WHERE `id` = ?", [date('Y-m-d H:i:s'), $user->id]);

            if(!empty($_SESSION['remember_choice']))\FavoriteCMS\Services\RememberedLogin::issue($userModel);
            unset($_SESSION['remember_choice'],$_SESSION['remember_expires']);
            if ($user->status === 'suspended') {
                $_SESSION['flash_error'] = 'Your account is currently suspended. Site activity and content creation are restricted.';
                return Response::redirect('/admin/users/profile');
            }

            if (!empty($GLOBALS['favorite_cms_repair_mode'])) $returnPath = $this->requestedRedirect($request);
            return Response::redirect($returnPath ?? $this->requestedRedirect($request) ?? '/admin');

    }

    protected function twoStep(Request $request): Response
    {
        if(!empty($_SESSION['auth_user_id']))return Response::redirect('/admin/account/security');
        $c=$_SESSION['two_step']??[];
        if(($c['purpose']??'')!=='login'||($c['expires']??0)<time()||($c['tries']??0)>=6){unset($_SESSION['two_step']);$_SESSION['login_flash']='Verification expired. Please sign in again.';return Response::redirect('/admin/login');}
        $error=(string)($_SESSION['two_step_error']??'');unset($_SESSION['two_step_error']);
        if($request->method()==='POST'){
            $token=(string)$request->post('_token','');
            if(empty($_SESSION['_token'])||!hash_equals($_SESSION['_token'],$token))return Response::make('Invalid security token.',403);
            try{
                $action=(string)$request->post('action','');
                if($action==='cancel'){\FavoriteCMS\Services\RememberedLogin::forget();unset($_SESSION['two_step'],$_SESSION['two_step_redirect']);return Response::redirect('/admin/login');}
                if($action==='resend'){$user=User::find((int)$c['user_id']);if(!$user)throw new \RuntimeException('Please sign in again.');\FavoriteCMS\Services\AccountSecurity::sendCode($user);$error='A new code has been sent.';}
                else {
                    $user=\FavoriteCMS\Services\AccountSecurity::verify((string)$request->post('code',''));
                    if($user){$target=SafeRedirect::localPath($_SESSION['two_step_redirect']??null);return $this->completeLogin($request,$user,$target);}
                    \FavoriteCMS\Services\NotificationService::security((int)$c['user_id'],'Two-step verification failed','An incorrect or expired code was submitted.',true);
                    $error='The code is invalid, already used, or expired.';
                }
            }catch(\Throwable $exception){$error=$exception->getMessage();}
        }
        return $this->renderAuthPage($request,'two-step',['token'=>$_SESSION['_token']??'', 'method'=>$c['method'],'error'=>$error])->header('Cache-Control','no-store')->header('Referrer-Policy','no-referrer');
    }

    protected function showRegister(Request $request, ?string $error = null, array $old = []): Response
    {
        $regEnabled = (int)Setting::get('general', 'allow_registration', 1);
        if (!$regEnabled && $error === null) {
            $error = 'Public registration is currently disabled by the site administrator.';
        }

        if (empty($_SESSION['_token'])) {
            $_SESSION['_token'] = bin2hex(random_bytes(32));
        }

        return $this->renderAuthPage($request, 'register', [
            'siteName'            => (string)Setting::get('general', 'site_name', 'Favorite CMS'),
            'token'               => (string)$_SESSION['_token'],
            'redirect'            => $this->requestedRedirect($request),
            'error'               => $error,
            'old'                 => $old,
            'registrationEnabled' => (bool)$regEnabled,
        ]);
    }

    protected function processRegister(Request $request): Response
    {
        $token  = (string)$request->post('_token', '');
        $stored = (string)($_SESSION['_token'] ?? '');
        if ($stored === '' || !hash_equals($stored, $token)) {
            return $this->showRegister($request, 'Invalid security token. Please try again.');
        }

        $regEnabled = (int)Setting::get('general', 'allow_registration', 1);
        if (!$regEnabled) {
            return $this->showRegister($request, 'Public registration is currently disabled by the site administrator.');
        }

        $username = trim((string)$request->post('username', ''));
        $name     = trim((string)$request->post('name', ''));
        $email    = trim((string)$request->post('email', ''));
        $password = (string)$request->post('password', '');
        $passwordConfirm = (string)$request->post('password_confirmation', '');

        $old = ['username' => $username, 'name' => $name, 'email' => $email];

        $limiter = new AuthRateLimiter();
        $ip = (string)($request->server()['REMOTE_ADDR'] ?? 'unknown');
        if (!$limiter->allow('register-ip:' . $ip, 20, 3600)) {
            return $this->showRegister($request, 'Too many registration attempts. Please try again later.', $old);
        }

        if ($username === '' || $email === '' || $password === '') {
            return $this->showRegister($request, 'Please complete all required fields.', $old);
        }

        if (!preg_match('/^[a-zA-Z0-9_\-\.]{3,30}$/', $username)) {
            return $this->showRegister($request, 'Username must be 3-30 alphanumeric characters, dots, dashes, or underscores.', $old);
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return $this->showRegister($request, 'Please enter a valid email address.', $old);
        }

        if (strlen($password) < 8) {
            return $this->showRegister($request, 'Password must be at least 8 characters long.', $old);
        }

        if ($password !== $passwordConfirm) {
            return $this->showRegister($request, 'Passwords do not match.', $old);
        }

        try {
            $db = $this->app->make(Database::class);

            // Anti-ban / Anti-suspension bypass check: reject recycling suspended/banned accounts
            $statusCheck = $db->selectOne(
                "SELECT `status` FROM `users` WHERE `email` = ? OR `username` = ? LIMIT 1",
                [$email, $username]
            );
            if ($statusCheck && in_array($statusCheck->status, ['suspended', 'banned'], true)) {
                return $this->showRegister($request, 'This email address or username is unavailable for registration. Please contact site support.', $old);
            }

            if ($statusCheck) {
                return $this->showRegister($request, 'A user with this username or email already exists.', $old);
            }

            $now = date('Y-m-d H:i:s');
            $hash = PasswordHasher::hash($password);
            $requiresVerification = EmailVerificationService::isRequired();

            $userId = $db->insert('users', [
                'username'          => $username,
                'name'              => $name !== '' ? $name : $username,
                'email'             => $email,
                'password'          => $hash,
                'status'            => 'active',
                'email_verified_at' => $requiresVerification ? null : $now,
                'created_at'        => $now,
                'updated_at'        => $now,
            ]);

            // Assign Normal User role ('subscriber')
            $role = $db->selectOne("SELECT id FROM `roles` WHERE `slug` = 'subscriber' LIMIT 1");
            if ($role) {
                $db->execute("INSERT INTO `user_roles` (`user_id`, `role_id`) VALUES (?, ?)", [$userId, $role->id]);
            }

            if ($requiresVerification) {
                $user = User::find($userId);
                if ($user) {
                    $verifService = new EmailVerificationService($db);
                    $token = $verifService->createVerificationToken($user, $email);
                    $verifService->sendVerificationEmail($user, $email, $token, false);
                }

                $_SESSION['login_flash'] = 'Registration successful! A verification email has been sent. Please check your inbox and verify your email to log in.';
                $_SESSION['flash_info']  = 'Registration successful! A verification email has been sent. Please check your inbox and verify your email to log in.';
                $returnPath = $this->requestedRedirect($request);
                return Response::redirect('/admin/login' . ($returnPath !== null ? '?redirect=' . rawurlencode($returnPath) : ''));
            }

            // Automatically authenticate user if email verification is not required
            (new InstallerSession(new UrlResolver()))->regenerate();
            $_SESSION['auth_version']    = 0;
            $_SESSION['auth_user_id']    = $userId;
            $_SESSION['auth_user_name']  = $name !== '' ? $name : $username;
            $_SESSION['auth_user_email'] = $email;

            $_SESSION['flash_success'] = 'Welcome, ' . htmlspecialchars($username) . '! Your account has been registered successfully.';
            return Response::redirect($this->requestedRedirect($request) ?? '/admin');

        } catch (\Throwable $e) {
            return $this->showRegister($request, 'Registration is temporarily unavailable. Please try again later.', $old);
        }
    }

    /**
     * Recover a same-origin return page for login links that lack a redirect
     * parameter. Never trust a Referrer as an external destination. This is a
     * graceful fallback only: browsers can legitimately omit the header.
     */
    protected function sameSiteLoginReferrer(Request $request): ?string
    {
        $referrer = trim($request->header('Referer'));
        $hostHeader = trim((string)($request->server()['HTTP_HOST'] ?? $request->server()['SERVER_NAME'] ?? ''));
        if ($referrer === '' || $hostHeader === '') {
            return null;
        }

        $ref = parse_url($referrer);
        $site = parse_url('https://' . $hostHeader);
        if (!is_array($ref) || !is_array($site)
            || !in_array(strtolower((string)($ref['scheme'] ?? '')), ['http', 'https'], true)
            || empty($ref['host']) || empty($site['host'])
            || strcasecmp($ref['host'], $site['host']) !== 0
            || isset($ref['user']) || isset($ref['pass'])
        ) {
            return null;
        }

        // Reject a different explicit port. Do not infer the public-facing
        // port from PHP's HTTPS flag: reverse proxies may terminate TLS.
        if (($ref['port'] ?? null) !== ($site['port'] ?? null)) {
            return null;
        }
        if (in_array(strtolower((string)($request->server()['HTTPS'] ?? '')), ['on', '1'], true)
            && strtolower($ref['scheme']) !== 'https') {
            return null;
        }

        $path = ($ref['path'] ?? '/') . (isset($ref['query']) ? '?' . $ref['query'] : '');
        return SafeRedirect::localPath($path);
    }

    /**
     * Resolve a validated local return path from the request (form field first, then query string).
     */
    protected function requestedRedirect(Request $request): ?string
    {
        $target = SafeRedirect::localPath($request->post('redirect', $request->get('redirect')));
        if (!empty($GLOBALS['favorite_cms_repair_mode'])) {
            $relative = $target ?? ''; $base = (string)($GLOBALS['favorite_cms_base_path'] ?? '');
            if ($base !== '' && str_starts_with($relative, $base . '/')) $relative = substr($relative, strlen($base));
            $route = (string)(parse_url($relative, PHP_URL_PATH) ?? '');
            if ($route === '' || in_array($route, ['/admin', '/admin/', '/admin/login', '/admin/two-step'], true) || !\FavoriteCMS\Central\Bridge::recoveryAllowed($route)) return '/admin/connection-status';
        }
        return $target;
    }

    protected function passwordRecovery(Request $request, bool $reset): Response
    {
        $error = '';
        $notice = '';
        if (!in_array($request->method(), ['GET', 'POST'], true)) {
            return Response::make('Method not allowed.', 405)->header('Allow', 'GET, POST');
        }

        if ($request->method() === 'GET' && $reset) {
            $raw = $request->get('token', '');
            if (is_string($raw) && preg_match('/^[a-f0-9]{64}$/D', $raw)) {
                $db = $this->app->make(Database::class);
                $tokenHash = hash('sha256', $raw);
                $record = $db->selectOne(
                    'SELECT * FROM `password_resets` WHERE `token_hash` = ? AND `expires_at` > ? LIMIT 1',
                    [$tokenHash, gmdate('Y-m-d H:i:s')]
                );
                if ($record) {
                    $_SESSION['_password_reset_token'] = $raw;
                } else {
                    $error = 'This reset link is invalid or expired. Please request a new link.';
                }
            }
        }

        if ($request->method() === 'POST') {
            $submitted = $request->post('_token', '');
            $stored = $_SESSION['_token'] ?? '';
            if (!is_string($submitted) || !is_string($stored) || $stored === '' || !hash_equals($stored, $submitted)) {
                $error = 'Invalid security token. Please try again.';
            } else {
                try {
                    $service = new PasswordResetService($this->app->make(Database::class));
                    $limiter = new AuthRateLimiter();
                    $ip = (string)($request->server()['REMOTE_ADDR'] ?? 'unknown');
                    if ($reset) {
                        $raw = $request->post('reset_token', $_SESSION['_password_reset_token'] ?? '');
                        $raw = is_string($raw) ? $raw : '';
                        if (preg_match('/^[a-f0-9]{64}$/D', $raw)) {
                            $_SESSION['_password_reset_token'] = $raw;
                        }
                        $password = (string)$request->post('password', '');
                        if ($password !== (string)$request->post('password_confirm', '') || strlen($password) < 10
                            || strlen($password) > 72 || !preg_match('/[A-Za-z]/', $password) || !preg_match('/[0-9]/', $password)) {
                            $error = 'Use 10–72 characters including a letter and a number, and enter the same password twice.';
                        } elseif (!$limiter->allow('reset:' . $ip, 5, 900) || !$service->reset($raw, $password)) {
                            unset($_SESSION['_password_reset_token']);
                            $error = 'This reset link is invalid or expired, or too many attempts were made. Please request a new link.';
                        } else {
                            unset($_SESSION['_password_reset_token']);
                            $_SESSION = ['login_flash' => 'Your password has been reset. Please log in.'];
                            (new InstallerSession(new UrlResolver()))->regenerate();
                            return Response::redirect('/admin/login')->header('Cache-Control', 'no-store')->header('Referrer-Policy', 'no-referrer');
                        }
                    } else {
                        $identity = strtolower(trim((string)$request->post('email', '')));
                        $notice = 'If that address belongs to an eligible account, a password reset link will be sent. Please check your inbox.';
                        if ($identity !== '' && $limiter->allow('recovery-ip:' . $ip, 5, 900) && $limiter->allow('recovery-email:' . $identity, 5, 900)) {
                            $service->request($identity);
                        }
                    }
                } catch (\Throwable) {
                    if ($reset) {
                        $error = 'Password reset is temporarily unavailable. Please try again later.';
                    } else {
                        $notice = 'If that address belongs to an eligible account, a password reset link will be sent. Please check your inbox.';
                    }
                }
            }
        }
        return $this->renderAuthPage($request, 'password-recovery', [
            'token' => csrf_token(), 'reset' => $reset, 'error' => $error, 'notice' => $notice,
        ])->header('Cache-Control', 'no-store')->header('Referrer-Policy', 'no-referrer')->header('X-Robots-Tag', 'noindex, nofollow');
    }

    protected function processLogout(Request $request): Response
    {
        if ($request->method() === 'GET') {
            return $this->renderAuthPage($request, 'logout', ['token' => csrf_token(),
                'logoutAction' => $request->path(), 'redirect' => SafeRedirect::localPath($request->get('redirect'))])
                ->header('Cache-Control', 'no-store');
        }
        if ($request->method() !== 'POST') {
            return Response::make('Method not allowed.', 405)->header('Allow', 'GET, POST');
        }
        $token = $request->post('_token', '');
        if (!is_string($token) || empty($_SESSION['_token']) || !hash_equals($_SESSION['_token'], $token)) {
            return Response::make('Invalid security token.', 403);
        }
        \FavoriteCMS\Services\RememberedLogin::forget();
        unset($_SESSION['auth_version'], $_SESSION['auth_user_role'], $_SESSION['_maintenance_bypass_token'], $_SESSION['auth_two_step'], $_SESSION['two_step'], $_SESSION['two_step_redirect']);
        unset($_SESSION['auth_user_id'], $_SESSION['auth_user_name'], $_SESSION['auth_user_email']);
        (new InstallerSession(new UrlResolver()))->regenerate();
        $_SESSION['login_flash'] = 'You have been successfully logged out.';
        $redirect = SafeRedirect::localPath($request->input('redirect'));
        if ($redirect !== null) {
            return Response::redirect($redirect);
        }
        return Response::redirect($request->path() === '/logout' ? '/' : '/admin/login');
    }

    // -------------------------------------------------------------------------
    // Email Verification Endpoints
    // -------------------------------------------------------------------------
    protected function handleEmailVerification(Request $request): Response
    {
        $token = (string)$request->get('token', '');
        $db = $this->app->make(Database::class);
        $service = new EmailVerificationService($db);
        $result = $service->verifyToken($token);

        if ($result['success']) {
            $user = $result['user'];
            if ($result['isEmailChange']) {
                if (!empty($_SESSION['auth_user_id']) && (int)$_SESSION['auth_user_id'] === (int)$user->id) {
                    $_SESSION['auth_user_email'] = $user->email;
                }
                $_SESSION['flash_success'] = 'Your email address has been successfully updated and verified!';
                return Response::redirect(!empty($_SESSION['auth_user_id']) ? '/admin/users/profile' : '/admin/login');
            }

            $_SESSION['login_flash'] = 'Your email has been successfully verified! You may now sign in.';
            $_SESSION['flash_success'] = 'Your email has been successfully verified! You may now sign in.';
            return Response::redirect('/admin/login');
        }

        return $this->showVerificationResult($request, false, $result['error'] ?? 'Verification link is invalid or expired.');
    }

    protected function showVerificationResult(Request $request, bool $success, string $message): Response
    {
        return $this->renderAuthPage($request, 'verification-result', [
            'siteName' => (string)Setting::get('general', 'site_name', 'Favorite CMS'),
            'success'  => $success,
            'message'  => $message,
        ], $success ? 200 : 400);
    }

    protected function showResendVerification(Request $request, ?string $error = null, ?string $success = null): Response
    {
        if (empty($_SESSION['_token'])) {
            $_SESSION['_token'] = bin2hex(random_bytes(32));
        }

        return $this->renderAuthPage($request, 'resend-verification', [
            'siteName' => (string)Setting::get('general', 'site_name', 'Favorite CMS'),
            'token'    => (string)$_SESSION['_token'],
            'error'    => $error,
            'success'  => $success,
            'email'    => trim((string)$request->get('email', $request->post('email', ''))),
        ]);
    }

    protected function processResendVerification(Request $request): Response
    {
        $token  = (string)$request->post('_token', '');
        $stored = (string)($_SESSION['_token'] ?? '');
        if ($stored === '' || !hash_equals($stored, $token)) {
            return $this->showResendVerification($request, 'Invalid security token. Please try again.');
        }

        $email = trim((string)$request->post('email', ''));
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return $this->showResendVerification($request, 'Please enter a valid email address.');
        }

        $limiter = new AuthRateLimiter();
        $ip = (string)($request->server()['REMOTE_ADDR'] ?? 'unknown');
        if (!$limiter->allow('resend-ip:' . $ip, 15, 900) || !$limiter->allow('resend-email:' . strtolower($email), 5, 3600)) {
            return $this->showResendVerification($request, 'Too many verification email requests. Please try again later.');
        }

        $db = $this->app->make(Database::class);
        $service = new EmailVerificationService($db);

        // Enforce rate-limiting cooldown
        if (!$service->canResend($email)) {
            $wait = $service->getSecondsUntilResend($email);
            return $this->showResendVerification($request, "Please wait {$wait} seconds before requesting another verification email.");
        }

        // Generic anti-enumeration response
        $genericMsg = 'If an unverified account associated with this email exists, a new verification link has been sent. Please check your inbox.';

        $user = User::findByEmail($email);
        if ($user && !$user->isEmailVerified() && !in_array($user->status, ['banned', 'suspended'], true)) {
            $newToken = $service->createVerificationToken($user, $email);
            $service->sendVerificationEmail($user, $email, $newToken, false);
        }

        return $this->showResendVerification($request, null, $genericMsg);
    }

    protected function dispatchPluginAdminPage(Request $request, string $slug): Response
    {
        $page = \FavoriteCMS\Core\AdminMenu::findPage($slug);
        if (!$page) {
            return $this->notFound($request);
        }

        $cap = $page['capability'] ?? 'manage_options';
        if (!current_user_can($cap)) {
            return Response::make('<h1>403 Access Denied</h1><p>You do not have permission to access this page.</p>', 403);
        }

        $handler = $page['handler'] ?? null;
        if (!is_callable($handler)) {
            return Response::make('<h1>Error</h1><p>Admin page handler is not callable.</p>', 500);
        }

        $content = call_user_func($handler, $request);
        if ($content instanceof Response) {
            return $content;
        }

        $siteName = \FavoriteCMS\Models\Setting::get('general', 'site_name', 'Favorite CMS');
        $username = $_SESSION['auth_user_name'] ?? 'Admin';
        $activeMenu = $slug;
        $pageTitle = $page['title'] ?? 'Plugin Page';
        $flashSuccess = $_SESSION['flash_success'] ?? null;
        $flashError   = $_SESSION['flash_error'] ?? null;
        unset($_SESSION['flash_success'], $_SESSION['flash_error']);

        // Wrap inside admin layout
        ob_start();
        ?>
        <div class="page-header">
            <h1 class="page-title"><?php echo htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8'); ?></h1>
        </div>
        <div class="plugin-page-card" style="background: #fff; padding: 24px; border: 1px solid #c3c4c7; border-radius: 4px; box-shadow: 0 1px 1px rgba(0,0,0,.04);">
            <?php echo (string)$content; ?>
        </div>
        <?php
        $customHtml = (string)ob_get_clean();

        $viewData = [
            'siteName'     => $siteName,
            'username'     => $username,
            'activeMenu'   => $activeMenu,
            'pageTitle'    => $pageTitle,
            'flashSuccess' => $flashSuccess,
            'flashError'   => $flashError,
            'contentView'  => null,
            'customHtml'   => $customHtml,
        ];
        extract($viewData, EXTR_SKIP);
        ob_start();
        include APP_ROOT . '/resources/views/admin/layout.php';
        return Response::make((string)ob_get_clean(), 200);
    }

    protected function serveStaticAsset(string $path): ?Response
    {
        // Prevent directory traversal
        if (str_contains($path, '..')) {
            return null;
        }

        // Never expose server-side source code or hidden files from theme/plugin directories
        if (preg_match('#(^|/)\.#', $path) === 1 || preg_match('/\.(php\d?|phtml|phar|inc)$/i', $path) === 1) {
            return null;
        }

        $filePath = APP_ROOT . $path;
        if (!file_exists($filePath) || is_dir($filePath)) {
            return null;
        }

        $ext = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
        $mimes = [
            'css'   => 'text/css; charset=utf-8',
            'js'    => 'application/javascript; charset=utf-8',
            'json'  => 'application/json',
            'png'   => 'image/png',
            'jpg'   => 'image/jpeg',
            'jpeg'  => 'image/jpeg',
            'gif'   => 'image/gif',
            'svg'   => 'image/svg+xml',
            'ico'   => 'image/x-icon',
            'webp'  => 'image/webp',
            'woff'  => 'font/woff',
            'woff2' => 'font/woff2',
            'ttf'   => 'font/ttf',
            'eot'   => 'application/vnd.ms-fontobject',
        ];

        $mime = $mimes[$ext] ?? 'application/octet-stream';
        $content = file_get_contents($filePath);
        if ($content === false) {
            return null;
        }

        $res = Response::make($content, 200);
        $res->header('Content-Type', $mime);
        $res->header('Cache-Control', 'public, max-age=86400');
        return $res;
    }

    protected function notFound(Request $request): Response
    {
        try {
            $engine = new Engine($this->app);
            $html = $engine->render('404');
            return Response::make($html, 404);
        } catch (\Throwable) {
            return Response::make('<h1>404 Not Found</h1>', 404);
        }
    }

    protected function handleException(\Throwable $e): Response
    {
        if (env('APP_DEBUG', false)) {
            $msg   = htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');
            $trace = htmlspecialchars($e->getTraceAsString(), ENT_QUOTES, 'UTF-8');
            $class = htmlspecialchars(get_class($e), ENT_QUOTES, 'UTF-8');
            $file  = htmlspecialchars($e->getFile(), ENT_QUOTES, 'UTF-8');
            $line  = $e->getLine();

            $html = '<!DOCTYPE html><html><head><meta charset="UTF-8">'
                  . '<title>Error — Favorite CMS</title>'
                  . '<style>body{font-family:monospace;background:#1e1e2e;color:#cdd6f4;margin:0;padding:2rem}'
                  . 'h1{color:#f38ba8;font-size:1.4rem;margin-bottom:.5rem}'
                  . '.meta{color:#a6e3a1;font-size:.85rem;margin-bottom:1.5rem}'
                  . 'pre{background:#181825;padding:1.5rem;border-radius:8px;overflow-x:auto;font-size:.82rem;line-height:1.6}'
                  . '</style></head><body>'
                  . "<h1>$class</h1>"
                  . "<div class=\"meta\">$file : line $line</div>"
                  . "<pre>$msg\n\n$trace</pre>"
                  . '</body></html>';

            return Response::make($html, 500);
        }

        $html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>500 — Server Error</title></head>'
              . '<body style="font-family:system-ui;text-align:center;padding:4rem">'
              . '<h1>500 — Internal Server Error</h1>'
              . '<p>Something went wrong. Please try again later.</p>'
              . '<a href="/">← Go home</a></body></html>';

        return Response::make($html, 500);
    }
}
