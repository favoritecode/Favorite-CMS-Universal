<?php

declare(strict_types=1);

namespace FavoriteCMS\Models;

use FavoriteCMS\Core\Container;
use FavoriteCMS\Core\Database;

class Page extends BaseModel
{
    protected static string $table = 'pages';

    public static function findBySlug(string $slug): ?self
    {
        $db = Container::getInstance()->get(Database::class);
        $result = $db->selectOne("SELECT * FROM `pages` WHERE `slug` = ?", [$slug]);
        return $result ? new static((array)$result) : null;
    }

    /**
     * Published pages ordered by menu order and title. Pass $limit to fetch a bounded set.
     */
    public static function published(?int $limit = null): array
    {
        $db = Container::getInstance()->get(Database::class);
        $sql = "SELECT * FROM `pages` WHERE `status` = 'published' ORDER BY `menu_order` ASC, `title` ASC";
        $params = [];
        if ($limit !== null) {
            $sql .= ' LIMIT ?';
            $params[] = max(1, $limit);
        }
        $results = $db->select($sql, $params);
        return array_map(fn($row) => new static((array)$row), $results);
    }

    /**
     * Lightweight page rows (no content) for selectors such as parent-page or front-page dropdowns.
     */
    public static function summaries(?string $status = null): array
    {
        $db = Container::getInstance()->get(Database::class);
        $sql = "SELECT `id`, `title`, `slug`, `status`, `parent_id`, `menu_order` FROM `pages`";
        $params = [];
        if ($status !== null) {
            $sql .= " WHERE `status` = ?";
            $params[] = $status;
        }
        $sql .= " ORDER BY `menu_order` ASC, `title` ASC";
        return array_map(fn($row) => new static((array)$row), $db->select($sql, $params));
    }

    public static function countByStatus(): array
    {
        $db = Container::getInstance()->get(Database::class);
        $rows = $db->rememberSelect("SELECT `status`, COUNT(*) as cnt FROM `pages` GROUP BY `status`");
        $counts = ['all' => 0, 'published' => 0, 'draft' => 0, 'trash' => 0];
        foreach ($rows as $row) {
            $counts[$row->status] = (int)$row->cnt;
            if ($row->status !== 'trash') {
                $counts['all'] += (int)$row->cnt;
            }
        }
        return $counts;
    }

    public function getAuthor(): ?User
    {
        if (empty($this->author_id)) {
            return null;
        }
        return User::find((int)$this->author_id);
    }

    public function getFeaturedImage(): ?Media
    {
        if (empty($this->featured_image_id)) return null;
        return Media::find((int)$this->featured_image_id);
    }

    public function getChildren(): array
    {
        $results = $this->db->select("SELECT * FROM `pages` WHERE `parent_id` = ? ORDER BY `menu_order` ASC", [$this->id]);
        return array_map(fn($row) => new static((array)$row), $results);
    }

    public function getParent(): ?self
    {
        if (!$this->parent_id) return null;
        return static::find((int)$this->parent_id);
    }

    public function getBreadcrumb(): array
    {
        $breadcrumb = [$this];
        $seen = [(int)$this->id => true];
        $parent = $this->getParent();
        while ($parent && !isset($seen[(int)$parent->id])) {
            $seen[(int)$parent->id] = true;
            array_unshift($breadcrumb, $parent);
            $parent = $parent->getParent();
        }
        return $breadcrumb;
    }

    public static function isValidParent(int $parentId, int $pageId = 0): bool
    {
        $seen = $pageId > 0 ? [$pageId => true] : [];
        while ($parentId > 0) {
            if (isset($seen[$parentId])) return false;
            $seen[$parentId] = true;
            $parent = static::find($parentId);
            if (!$parent) return false;
            $parentId = (int)$parent->parent_id;
        }
        return true;
    }

    public function getSeoMeta(): ?object
    {
        return $this->db->selectOne(
            "SELECT * FROM `seo_meta` WHERE `object_type` = 'page' AND `object_id` = ? LIMIT 1",
            [$this->id]
        );
    }

    public function saveSeoMeta(array $meta): void
    {
        $existing = $this->getSeoMeta();
        $data = [
            'meta_title'       => $meta['meta_title'] ?? null,
            'meta_description' => $meta['meta_description'] ?? null,
            'og_title'         => $meta['og_title'] ?? null,
            'og_description'   => $meta['og_description'] ?? null,
            'og_image_url'     => $meta['og_image_url'] ?? ($existing->og_image_url ?? null),
            'canonical_url'    => $meta['canonical_url'] ?? null,
            'robots'           => $meta['robots'] ?? 'index,follow',
        ];

        if ($existing) {
            $this->db->update('seo_meta', $data, [
                'object_type' => 'page',
                'object_id'   => $this->id,
            ]);
        } else {
            $data['object_type'] = 'page';
            $data['object_id']   = $this->id;
            $this->db->insert('seo_meta', $data);
        }
    }

    public function update(array $data): bool
    {
        $old = array_key_exists('slug', $data) ? static::find((int)$this->id) : null;
        $saved = parent::update($data);
        if ($saved && $old) \FavoriteCMS\Services\SeoRedirects::remember('page', (int)$this->id, (string)$old->slug, (string)$data['slug']);
        return $saved;
    }

    public function generateSlug(string $title): string
    {
        $baseSlug = str_slug($title);
        if ($baseSlug === '') {
            $baseSlug = 'page';
        }
        $slug = $baseSlug;
        $count = 1;
        while ($this->db->selectOne("SELECT id FROM `pages` WHERE `slug` = ? AND `id` != ?", [$slug, $this->id ?? 0])) {
            $slug = $baseSlug . '-' . $count;
            $count++;
        }
        return $slug;
    }

    public function url(): string
    {
        $base = \FavoriteCMS\Models\Setting::get('permalinks', 'page_base', 'page');
        if ($base === 'root') {
            return '/' . rawurlencode((string)$this->slug);
        }
        return '/page/' . rawurlencode((string)$this->slug);
    }

    public function permalink(): string
    {
        return $this->url();
    }
}
